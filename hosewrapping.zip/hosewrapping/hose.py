import sys
import json
import requests
import urllib.parse
#from urllib import Request, parse
from datetime import datetime, timedelta
import datetime
import time
import paho.mqtt.client as paho
import random
import string
sys.path.insert(0, "..")

from opcua import Client
while True:
    try:
       if __name__ == "__main__":
            client = Client("opc.tcp://192.168.1.10:4840/")
            client.connect()
            while True:
                try:
                    root = client.get_root_node()
                    #date_time
                    currentDT = datetime.datetime.now()
                    currentdt = currentDT.strftime("%Y-%m-%d %H:%M:%S")
                    print(currentdt)

                    #values which are red in color
                    serial_num = client.get_node("ns=2;s=glob/Machine_serial")
                    serial_number = serial_num.get_value()
                    print("serial"+str(serial_number))

                    machine_num = client.get_node("ns=2;s=unit/iot_data.Mc_IOT_number")
                    machine_number = machine_num.get_value()
                    print("machine_no"+str(machine_number))

                    PLC_Time1 = client.get_node("ns=2;s=glob/Time_RTC")
                    PLC_Time = str(PLC_Time1.get_value())
                    print("PLC_time"+str(PLC_Time))

                    stop_hour1 = client.get_node("ns=2;s=unit/time_count_iot.hlyhour[1]")
                    stop_hour = stop_hour1.get_value()
                    stop_min1 = client.get_node("ns=2;s=unit/time_count_iot.hlyminute[1]")
                    stop_min11 = stop_min1.get_value()
                    stop_sec1 = client.get_node("ns=2;s=unit/time_count_iot.hlyseconds[1]")
                    stop_sec = stop_sec1.get_value()
                    stop_time1 = int(stop_hour)*60+int(stop_min11)
                    stop_time2 = round(stop_time1)
                    stop_time = str(stop_time2)
                    print("stop_time"+stop_time)

                    running_hour1 = client.get_node("ns=2;s=unit/time_count_iot.runhour[1]")
                    running_hour = running_hour1.get_value()
                    running_min1 = client.get_node("ns=2;s=unit/time_count_iot.runminute[1]")
                    running_min11 = running_min1.get_value()
                    running_sec1 = client.get_node("ns=2;s=unit/time_count_iot.runseconds[1]")
                    running_sec = running_sec1.get_value()
                    running_time1 = int(running_hour)*60+int(running_min11)
                    running_time2 = round(running_time1)
                    running_time = str(running_time2)
                    print("running_time"+running_time)

                    fault_hour1 = client.get_node("ns=2;s=unit/time_count_iot.faulthour[1]")
                    fault_hour = fault_hour1.get_value()
                    fault_min1 = client.get_node("ns=2;s=unit/time_count_iot.faultminute[1]")
                    fault_min = fault_hour1.get_value()
                    fault_sec1 = client.get_node("ns=2;s=unit/time_count_iot.faultseconds[1]")
                    fault_sec = fault_sec1.get_value()
                    fault_time1 = int(fault_hour)*60+int(fault_min)
                    fault_time2 = round(fault_time1)
                    fault_time = str(fault_time2)
                    print("fault_time"+fault_time)

                    machine_speed1 = client.get_node("ns=2;s=glob/wincc_head_speed")
                    machine_speed = machine_speed1.get_value()
                    print("machine_speed"+str(machine_speed))

                    production_speed1 = client.get_node("ns=2;s=glob/wincc_line_speed1")
                    production_speed = production_speed1.get_value()
                    print("production_speed"+str(production_speed))

                    Actual_Pitch1 = client.get_node("ns=2;s=glob/pitch")
                    Actual_Pitch = Actual_Pitch1.get_value()
                    print("Actual_Pitch"+str(Actual_Pitch))

                    Hose_Diameter1 = client.get_node("ns=2;s=glob/hose_dia")
                    Hose_Diameter = Hose_Diameter1.get_value()
                    print("Hose_Diameter"+str(Hose_Diameter))

                    Tape_Width1 = client.get_node("ns=2;s=glob/tape_width")
                    Tape_Width = Tape_Width1.get_value()
                    print("Hose_Diameter"+str(Hose_Diameter))

                    Tape_Thickness1 = client.get_node("ns=2;s=glob/thickness")
                    Tape_Thickness = Tape_Thickness1.get_value()
                    print("Tape_Thickness"+str(Tape_Thickness))

                    Spool_Tension_Wrap1 = client.get_node("ns=2;s=glob/spool_tension")
                    Spool_Tension_Wrap = Spool_Tension_Wrap1.get_value()
                    print("Spool_Tension_Wrap"+str(Spool_Tension_Wrap))

                    Spool_Tension_Unwrap1 = client.get_node("ns=2;s=glob/spool_tension_unwrap")
                    Spool_Tension_Unwrap = Spool_Tension_Unwrap1.get_value()
                    print("Spool_Tension_Unwrap"+str(Spool_Tension_Unwrap))

                    Brand_Tension_Wrap1 = client.get_node("ns=2;s=glob/tape_force")
                    Brand_Tension_Wrap = Brand_Tension_Wrap1.get_value()
                    print("Brand_Tension_Wrap"+str(Brand_Tension_Wrap))

                    Brand_Tension_Unwrap1 = client.get_node("ns=2;s=glob/tape_force_1")
                    Brand_Tension_Unwrap = Brand_Tension_Unwrap1.get_value()
                    print("Brand_Tension_Unwrap"+str(Brand_Tension_Unwrap))

                    Overlap1 = client.get_node("ns=2;s=glob/overlap_tape")
                    Overlap = Overlap1.get_value()
                    print("Overlap"+str(Overlap))

                    Pitch_Wrap1 = client.get_node("ns=2;s=glob/pitch")
                    Pitch_Wrap = Pitch_Wrap1.get_value()
                    print("Pitch_Wrap"+str(Pitch_Wrap))

                    Pitch_Unwrap1 = client.get_node("ns=2;s=glob/pitch")
                    Pitch_Unwrap = Pitch_Unwrap1.get_value()
                    print("Pitch_Unwrap"+str(Pitch_Unwrap))
                    
                    Wrap_Unwrap1 = client.get_node("ns=2;s=glob/wrap_unwarp")
                    Wrap_Unwrap = Wrap_Unwrap1.get_value()
                    print("Wrap_Unwrap"+str(Wrap_Unwrap))

                    Actual_Dwell_Angle1 = client.get_node("ns=2;s=glob/dwell_angle")
                    Actual_Dwell_Angle = Actual_Dwell_Angle1.get_value()
                    print("Actual_Dwell_Angle"+str(Actual_Dwell_Angle))

                    Jog_Speed1 = client.get_node("ns=2;s=glob/flag_jog")
                    Jog_Speed = Jog_Speed1.get_value()
                    print("Jog_Speed"+str(Jog_Speed))

                    Low_Speed1 = client.get_node("ns=2;s=glob/flag_low")
                    Low_Speed = Low_Speed1.get_value()
                    print("Low_Speed"+str(Low_Speed))

                    Run_Speed1 = client.get_node("ns=2;s=glob/flag_full_ind")
                    Run_Speed = Run_Speed1.get_value()
                    print("Run_Speed"+str(Run_Speed))

                    Stop_Speed1 = client.get_node("ns=2;s=glob/flag_stop")
                    Stop_Speed = Stop_Speed1.get_value()
                    print("Stop_Speed"+str(Stop_Speed))

                    Machine_Stop1 = client.get_node("ns=2;s=glob/flag_mc_stop_ind")
                    Machine_Stop = Machine_Stop1.get_value()
                    print("Machine_Stop"+str(Machine_Stop))

                    Homing_Done1 = client.get_node("ns=2;s=glob/homing_over")
                    Homing_Done = Homing_Done1.get_value()
                    print("Homing_Done"+str(Homing_Done))

                    Set_Jog_Speed1 = client.get_node("ns=2;s=glob/jog_speed")
                    Set_Jog_Speed = Set_Jog_Speed1.get_value()
                    print("Set_Jog_Speed"+str(Set_Jog_Speed))

                    Set_Low_Speed1 = client.get_node("ns=2;s=glob/low_speed")
                    Set_Low_Speed = Set_Low_Speed1.get_value()
                    print("Set_Low_Speed"+str(Set_Low_Speed))

                    Set_Run_Speed1 = client.get_node("ns=2;s=glob/shuttle_speed")
                    Set_Run_Speed = Set_Run_Speed1.get_value()
                    print("Set_Run_Speed"+str(Set_Run_Speed))

                    Set_Stop_Speed1 = client.get_node("ns=2;s=glob/stop_speed")
                    Set_Stop_Speed = Set_Stop_Speed1.get_value()
                    print("Set_Stop_Speed"+str(Set_Stop_Speed))

                    Letoff_On_Off1 = client.get_node("ns=2;s=glob/Letoff_ON_OFF")
                    Letoff_On_Off = Letoff_On_Off1.get_value()
                    print("Letoff_On_Off"+str(Letoff_On_Off))

                    Takeoff_On_Off1 = client.get_node("ns=2;s=glob/Takeup_ON_OFF")
                    Takeoff_On_Off = Takeoff_On_Off1.get_value()
                    print("Takeoff_On_Off"+str(Takeoff_On_Off))

                    Head_Fault_code1 = client.get_node("ns=2;s=io/_direct.cu_head_flt")
                    Head_Fault_code = Head_Fault_code1.get_value()
                    print("Head_Fault_code"+str(Head_Fault_code))

                    Spool_Fault_code1 = client.get_node("ns=2;s=io/_direct.cu_spool_flt")
                    Spool_Fault_code = Spool_Fault_code1.get_value()
                    print("Spool_Fault_code"+str(Spool_Fault_code))

                    CAT_Fault_Code1 = client.get_node("ns=2;s=io/_direct.cu_caterpillar_flt")
                    CAT_Fault_Code = CAT_Fault_Code1.get_value()
                    print("CAT_Fault_Code"+str(CAT_Fault_Code))

                    BLM_Fault_Code1 = client.get_node("ns=2;s=io/_direct.cu_basic_flt")
                    BLM_Fault_Code = BLM_Fault_Code1.get_value()
                    print("BLM_Fault_Code"+str(BLM_Fault_Code))

                    Letoff_Fault_Code1 = client.get_node("ns=2;s=io/_direct.cu_vec_lo_fault")
                    Letoff_Fault_Code = Letoff_Fault_Code1.get_value()
                    print("Letoff_Fault_Code"+str(Letoff_Fault_Code))

                    Takeup_Fault_Code1 = client.get_node("ns=2;s=io/_direct.cu_vec_tu_flt")
                    Takeup_Fault_Code = Takeup_Fault_Code1.get_value()
                    print("Takeup_Fault_Code"+str(Takeup_Fault_Code))

                    Head_Alarm_code1 = client.get_node("ns=2;s=io/_direct.head_Alarm")
                    Head_Alarm_code = Head_Alarm_code1.get_value()
                    print("Head_Alarm_code"+str(Head_Alarm_code))

                    Spool_Alarm_Code1 = client.get_node("ns=2;s=io/_direct.Spool_Alarm")
                    Spool_Alarm_Code = Spool_Alarm_Code1.get_value()
                    print("Spool_Alarm_Code"+str(Spool_Alarm_Code))

                    CAT_Alarm_Code1 = client.get_node("ns=2;s=io/_direct.cat_Alarm")
                    CAT_Alarm_Code = CAT_Alarm_Code1.get_value()
                    print("CAT_Alarm_Code"+str(CAT_Alarm_Code))

                    Letoff_Alarm_code1 = client.get_node("ns=2;s=io/_direct.letoff_alarm")
                    Letoff_Alarm_code = Letoff_Alarm_code1.get_value()
                    print("Letoff_Alarm_code"+str(Letoff_Alarm_code))

                    Takeoff_Alarm_Code1 = client.get_node("ns=2;s=io/_direct.takeup_alarm")
                    Takeoff_Alarm_Code = Takeoff_Alarm_Code1.get_value()
                    print("Takeoff_Alarm_Code"+str(Takeoff_Alarm_Code))

                    Head_Motor_Temp1 = client.get_node("ns=2;s=io/_direct.head_motor_temp")
                    Head_Motor_Temp = Head_Motor_Temp1.get_value()
                    print("Head_Motor_Temp"+str(Head_Motor_Temp))

                    Spool_Motor_Temp1 = client.get_node("ns=2;s=io/_direct.spool_motor_temp")
                    Spool_Motor_Temp = Spool_Motor_Temp1.get_value()
                    print("Spool_Motor_Temp"+str(Spool_Motor_Temp))

                    CAT_Motor_Temp1 = client.get_node("ns=2;s=io/_direct.cat_motor_temp")
                    CAT_Motor_Temp = CAT_Motor_Temp1.get_value()
                    print("CAT_Motor_Temp"+str(CAT_Motor_Temp))

                    CPU_Temperature1 = client.get_node("ns=2;s=var/_cpuData.moduletemperature")
                    CPU_Temperature = CPU_Temperature1.get_value()
                    print("CPU_Temperature"+str(CPU_Temperature))

                    Shift_details1 = client.get_node("ns=2;s=glob/flag_wrap")
                    Shift_details = Shift_details1.get_value()
                    #if(Shift_details)
                    print("shift details"+str(Shift_details))
                    
                    #Values which are not in red
                    Brand_tapecut_ON_OFF1 = client.get_node("ns=2;s=glob/brand_tape_detect_1")
                    Brand_tapecut_ON_OFF = Brand_tapecut_ON_OFF1.get_value()
                    print("Brand_tapecut_ON_OFF"+str(Brand_tapecut_ON_OFF))

                    Spool_Dia_ON_OFF1 = client.get_node("ns=2;s=glob/tape_detection")
                    Spool_Dia_ON_OFF = Spool_Dia_ON_OFF1.get_value()
                    print("Spool_Dia_ON_OFF"+str(Spool_Dia_ON_OFF))

                    Brand_tapecut_ON_OFF1 = client.get_node("ns=2;s=glob/brand_tape_detect_1")
                    Brand_tapecut_ON_OFF = Brand_tapecut_ON_OFF1.get_value()
                    print("Brand_tapecut_ON_OFF"+str(Brand_tapecut_ON_OFF))

                    PLC_Mode1 = client.get_node("ns=2;s=var/modeOfOperation")
                    PLC_Mode = PLC_Mode1.get_value()
                    print("PLC_Mode"+str(PLC_Mode))

                    All_count_Ok1 = client.get_node("ns=2;s=glob/count_all_ok")
                    All_count_Ok = All_count_Ok1.get_value()
                    print("All_count_Ok"+str(All_count_Ok))

                    Count_Left_Sensor1 = client.get_node("ns=2;s=glob/count_left_sensor")
                    Count_Left_Sensor = Count_Left_Sensor1.get_value()
                    print("Count_Left_Sensor"+str(Count_Left_Sensor))

                    Count_Right_Sensor1 = client.get_node("ns=2;s=glob/count_right_sensor")
                    Count_Right_Sensor = Count_Right_Sensor1.get_value()
                    print("Count_Right_Sensor"+str(Count_Right_Sensor))

                    Count_Both_Fail1 = client.get_node("ns=2;s=glob/count_both_eye_failed")
                    Count_Both_Fail = Count_Both_Fail1.get_value()
                    print("Count_Both_Fail"+str(Count_Both_Fail))

                    Cat_Jog_Spd1 = client.get_node("ns=2;s=glob/cat_jog_speed")
                    Cat_Jog_Spd = Cat_Jog_Spd1.get_value()
                    print("Cat_Jog_Spd"+str(Cat_Jog_Spd))

                    Shift1_starttime1 = client.get_node("ns=2;s=glob/shift1_St")
                    Shift1_starttime = Shift1_starttime1.get_value()
                    print("Shift1_starttime"+str(Shift1_starttime))

                    Shift2_starttime1 = client.get_node("ns=2;s=glob/shift2_St")
                    Shift2_starttime = Shift2_starttime1.get_value()
                    print("Shift2_starttime"+str(Shift2_starttime))

                    Shift3_starttime1 = client.get_node("ns=2;s=glob/shift3_St")
                    Shift3_starttime = Shift3_starttime1.get_value()
                    print("Shift3_starttime"+str(Shift3_starttime))

                    Wrap_UpperLimit1 = client.get_node("ns=2;s=glob/wrap_th")
                    Wrap_UpperLimit = Wrap_UpperLimit1.get_value()
                    print("Wrap_UpperLimit"+str(Wrap_UpperLimit))

                    Wrap_LowerLimit1 = client.get_node("ns=2;s=glob/wrap_tl")
                    Wrap_LowerLimit = Wrap_LowerLimit1.get_value()
                    print("Wrap_LowerLimit"+str(Wrap_LowerLimit))

                    Wrap_Acceleration_Torque1 = client.get_node("ns=2;s=glob/spool_acc_torque_from_hmi")
                    Wrap_Acceleration_Torque = Wrap_Acceleration_Torque1.get_value()
                    print("Wrap_Acceleration_Torque"+str(Wrap_Acceleration_Torque))

                    Wrap_deceleration_Torque1 = client.get_node("ns=2;s=glob/spool_wrap_accl_hmi")
                    Wrap_deceleration_Torque = Wrap_deceleration_Torque1.get_value()
                    print("Wrap_deceleration_Torque"+str(Wrap_deceleration_Torque))

                    UnWrap_UpperLimit1 = client.get_node("ns=2;s=glob/unwrap_th")
                    UnWrap_UpperLimit = UnWrap_UpperLimit1.get_value()
                    print("UnWrap_UpperLimit"+str(UnWrap_UpperLimit))

                    UnWrap_LowerLimit1 = client.get_node("ns=2;s=glob/unwrap_tl")
                    UnWrap_LowerLimit = UnWrap_LowerLimit1.get_value()
                    print("UnWrap_LowerLimit"+str(UnWrap_LowerLimit))

                    Shift_A1 = client.get_node("ns=2;s=glob/shft_a")
                    Shift_A = Shift_A1.get_value()
                    print("Shift_A"+str(Shift_A))

                    Shift_B1 = client.get_node("ns=2;s=glob/shft_b")
                    Shift_B = Shift_B1.get_value()
                    print("Shift_B"+str(Shift_B))

                    Shift_C1 = client.get_node("ns=2;s=glob/shft_c")
                    Shift_C = Shift_C1.get_value()
                    print("Shft_C"+str(Shift_C))

                    Aux_Door_Safe_Switch1 = client.get_node("ns=2;s=io/_quality.aux_door_safety_sw")
                    Aux_Door_Safe_Switch = Aux_Door_Safe_Switch1.get_value()
                    print("Aux_Door_Safe_Switch"+str(Aux_Door_Safe_Switch))

                    Air_Cond_Fault_Inp1 = client.get_node("ns=2;s=io/_quality.AC_trip_input")
                    Air_Cond_Fault_Inp = Air_Cond_Fault_Inp1.get_value()
                    print("Air_Cond_Fault_Inp"+str(Air_Cond_Fault_Inp))

                    Air_Press_Switch1 = client.get_node("ns=2;s=io/_quality.air_pressure")
                    Air_Press_Switch = Air_Press_Switch1.get_value()
                    print("Air_Press_Switch"+str(Air_Press_Switch))

                    Brake_ON_OFF_Override1 = client.get_node("ns=2;s=io/_quality.brake_on_off_ovr")
                    Brake_ON_OFF_Override = Brake_ON_OFF_Override1.get_value()
                    print("Brake_ON_OFF_Override"+str(Brake_ON_OFF_Override))

                    CAT_Door_Limit_Switch1 = client.get_node("ns=2;s=io/_quality.cat_door_sw")
                    CAT_Door_Limit_Switch = CAT_Door_Limit_Switch1.get_value()
                    print("CAT_Door_Limit_Switch"+str(CAT_Door_Limit_Switch))

                    Cat_Jog_Left1 = client.get_node("ns=2;s=io/_quality.cat_jog_left")
                    Cat_Jog_Left = Cat_Jog_Left1.get_value()
                    print("Cat_Jog_Left"+str(Cat_Jog_Left))

                    Cat_Jog_Right1 = client.get_node("ns=2;s=io/_quality.cat_jog_right")
                    Cat_Jog_Right = Cat_Jog_Right1.get_value()
                    print("Cat_Jog_Right"+str(Cat_Jog_Right))

                    Fault_Reset1 = client.get_node("ns=2;s=io/_quality.fault_all_reset")
                    Fault_Reset = Fault_Reset1.get_value()
                    print("Fault_Reset"+str(Fault_Reset))

                    Home_Position_Proxy1 = client.get_node("ns=2;s=io/_quality.home_position_proxy")
                    Home_Position_Proxy = Home_Position_Proxy1.get_value()
                    print("Home_Position_Proxy"+str(Home_Position_Proxy))

                    LetOff_HMI_PB_Start1 = client.get_node("ns=2;s=io/_image.Letoff_HMI_start")
                    LetOff_HMI_PB_Start = LetOff_HMI_PB_Start1.get_value()
                    print("LetOff_HMI_PB_Start"+str(LetOff_HMI_PB_Start))

                    LetOff_HMI_PB_Stop1 = client.get_node("ns=2;s=io/_image.Letoff_HMI_stop")
                    LetOff_HMI_PB_Stop = LetOff_HMI_PB_Stop1.get_value()
                    print("LetOff_HMI_PB_Stop"+str(LetOff_HMI_PB_Stop))

                    Main_Contractor1 = client.get_node("ns=2;s=io/_quality.main_contactor_fb")
                    Main_Contractor = Main_Contractor1.get_value()
                    print("Main_Contractor"+str(Main_Contractor))

                    Main_Door_Switch1 = client.get_node("ns=2;s=io/_quality.main_door_sw")
                    Main_Door_Switch = Main_Door_Switch1.get_value()
                    print("Main_Door_Switch"+str(Main_Door_Switch))

                    Rapid_Stop1 = client.get_node("ns=2;s=io/_quality.rapid_stop")
                    Rapid_Stop = Rapid_Stop1.get_value()
                    print("Rapid_Stop"+str(Rapid_Stop))

                    Start_Push_Btn1 = client.get_node("ns=2;s=io/_quality.start_pb")
                    Start_Push_Btn = Start_Push_Btn1.get_value()
                    print("Start_Push_Btn"+str(Start_Push_Btn))

                    Stop_Push_Btn1 = client.get_node("ns=2;s=io/_quality.stop_pb")
                    Stop_Push_Btn = Stop_Push_Btn1.get_value()
                    print("Stop_Push_Btn"+str(Stop_Push_Btn))

                    Takeup_HMI_PB_Start1 = client.get_node("ns=2;s=io/_image.Takeup_HMI_start")
                    Takeup_HMI_PB_Start = Takeup_HMI_PB_Start1.get_value()
                    print("Takeup_HMI_PB_Start"+str(Takeup_HMI_PB_Start))

                    Takeup_HMI_PB_Stop1 = client.get_node("ns=2;s=io/_image.Takeup_HMI_stop")
                    Takeup_HMI_PB_Stop = Takeup_HMI_PB_Stop1.get_value()
                    print("Takeup_HMI_PB_Stop"+str(Takeup_HMI_PB_Stop))

                    Tape_Tracking_Sensor_Left1 = client.get_node("ns=2;s=io/_quality.tape_tracking_sensor_left")
                    Tape_Tracking_Sensor_Left = Tape_Tracking_Sensor_Left1.get_value()
                    print("Tape_Tracking_Sensor_Left"+str(Tape_Tracking_Sensor_Left))

                    Tape_Tracking_Sensor_Right1 = client.get_node("ns=2;s=io/_quality.tape_tracking_sensor_right")
                    Tape_Tracking_Sensor_Right = Tape_Tracking_Sensor_Right1.get_value()
                    print("Tape_Tracking_Sensor_Right"+str(Tape_Tracking_Sensor_Right))

                    Brake_Release_Sol1 = client.get_node("ns=2;s=io/_quality.brake_rel_sol")
                    Brake_Release_Sol = Brake_Release_Sol1.get_value()
                    print("Brake_Release_Sol"+str(Brake_Release_Sol))

                    CAT_down_Sol1 = client.get_node("ns=2;s=io/_quality.caterpillar_down_sol")
                    CAT_down_Sol = CAT_down_Sol1.get_value()
                    print("CAT_down_Sol"+str(CAT_down_Sol))

                    CAT_up_Sol1 = client.get_node("ns=2;s=io/_quality.catepillar_up_sol")
                    CAT_up_Sol = CAT_up_Sol1.get_value()
                    print("CAT_up_Sol"+str(CAT_up_Sol))

                    Door_Close_Sol1 = client.get_node("ns=2;s=io/_quality.door_close_sol")
                    Door_Close_Sol = Door_Close_Sol1.get_value()
                    print("Door_Close_Sol"+str(Door_Close_Sol))

                    Door_Latch_Sol1 = client.get_node("ns=2;s=io/_quality.door_latch_solenoid")
                    Door_Latch_Sol = Door_Latch_Sol1.get_value()
                    print("Door_Latch_Sol"+str(Door_Latch_Sol))

                    Door_Open_Sol1 = client.get_node("ns=2;s=io/_quality.door_open_sol")
                    Door_Open_Sol = Door_Open_Sol1.get_value()
                    print("Door_Open_Sol"+str(Door_Open_Sol))

                    Hooter_alarm1 = client.get_node("ns=2;s=io/_quality.hooter_op")
                    Hooter_alarm = Hooter_alarm1.get_value()
                    print("Hooter_alarm"+str(Hooter_alarm))

                    LASER_ON1 = client.get_node("ns=2;s=io/_quality.laser_on")
                    LASER_ON = LASER_ON1.get_value()
                    print("LASER_ON"+str(LASER_ON))

                    Run_Letoff_Takeup1 = client.get_node("ns=2;s=io/_quality.run_takeup_payoff")
                    Run_Letoff_Takeup = Run_Letoff_Takeup1.get_value()
                    print("Run_Letoff_Takeup"+str(Run_Letoff_Takeup))

                    Shuttle_Contractor1 = client.get_node("ns=2;s=io/_quality.shuttle_contactor_1")
                    Shuttle_Contractor = Shuttle_Contractor1.get_value()
                    print("Shuttle_Contractor"+str(Shuttle_Contractor))
                    
                    Brand_Tape_Spd_Actual1 = client.get_node("ns=2;s=glob/gr32_tape_UP_SPD_Actal")
                    Brand_Tape_Spd_Actual = Brand_Tape_Spd_Actual1.get_value()
                    print("Brand_Tape_Spd_Actual"+str(Brand_Tape_Spd_Actual))

                    Brand_Tape_Spd_Setpoint_op1 = client.get_node("ns=2;s=glob/gr32_tape_up_spd")
                    Brand_Tape_Spd_Setpoint_op = Brand_Tape_Spd_Setpoint_op1.get_value()
                    print("Brand_Tape_Spd_Setpoint_op"+str(Brand_Tape_Spd_Setpoint_op))

                    Brand_Tape_Spd_torque_Setpoint_op1 = client.get_node("ns=2;s=glob/gr32_tape_Up_troq")
                    Brand_Tape_Spd_torque_Setpoint_op = Brand_Tape_Spd_torque_Setpoint_op1.get_value()
                    print("Brand_Tape_Spd_torque_Setpoint_op"+str(Brand_Tape_Spd_torque_Setpoint_op))

                    Set_Diameter1 = client.get_node("ns=2;s=glob/tape_diameter")
                    Set_Diameter = Set_Diameter1.get_value()
                    print("Set_Diameter"+str(Set_Diameter))

                    Actual_Diameter1 = client.get_node("ns=2;s=glob/tape_diameter_3")
                    Actual_Diameter = Actual_Diameter1.get_value()
                    print("Actual_Diameter"+str(Actual_Diameter))

                    Tape_Cut_Old_ON_OFF1 = client.get_node("ns=2;s=glob/tapecut_override")
                    Tape_Cut_Old_ON_OFF = Tape_Cut_Old_ON_OFF1.get_value()
                    print("Tape_Cut_Old_ON_OFF"+str(Tape_Cut_Old_ON_OFF))

                    Tape_Cut_New_ON_OFF1 = client.get_node("ns=2;s=glob/spool_spd_sen_en")
                    Tape_Cut_New_ON_OFF = Tape_Cut_New_ON_OFF1.get_value()
                    print("Tape_Cut_New_ON_OFF"+str(Tape_Cut_New_ON_OFF))

                    Unwrap_Eye_ON_OFF1 = client.get_node("ns=2;s=glob/auto_feed_control")
                    Unwrap_Eye_ON_OFF = Unwrap_Eye_ON_OFF1.get_value()
                    print("Unwrap_Eye_ON_OFF"+str(Unwrap_Eye_ON_OFF))

                    Air_ON_OFF1 = client.get_node("ns=2;s=glob/air_pressure_override")
                    Air_ON_OFF = Air_ON_OFF1.get_value()
                    print("Air_ON_OFF"+str(Air_ON_OFF))

                    Wrap_Factor1 = client.get_node("ns=2;s=glob/wrap_factor")
                    Wrap_Factor = Wrap_Factor1.get_value()
                    print("Wrap_Factor"+str(Wrap_Factor))

                    UnWrap_Factor1 = client.get_node("ns=2;s=glob/unwrap_factor")
                    UnWrap_Factor = UnWrap_Factor1.get_value()
                    print("UnWrap_Factor"+str(UnWrap_Factor))

                    Wrap_Factor_Band1 = client.get_node("ns=2;s=glob/wrap_factor_brand")
                    Wrap_Factor_Band = Wrap_Factor_Band1.get_value()
                    print("Wrap_Factor_Band"+str(Wrap_Factor_Band))

                    UnWrap_Factor_Band1 = client.get_node("ns=2;s=glob/unwrap_factor_brand")
                    UnWrap_Factor_Band = UnWrap_Factor_Band1.get_value()
                    print("UnWrap_Factor_Band"+str(UnWrap_Factor_Band))

                    Spool_Cut_Spd11 = client.get_node("ns=2;s=glob/spool_cut_spd")
                    Spool_Cut_Spd1 = Spool_Cut_Spd11.get_value()
                    print("Spool_Cut_Spd1"+str(Spool_Cut_Spd1))

                    Spool_Cut_Spd22 = client.get_node("ns=2;s=glob/spool_cut_spd1")
                    Spool_Cut_Spd2 = Spool_Cut_Spd22.get_value()
                    print("Spool_Cut_Spd2"+str(Spool_Cut_Spd2))

                    Spool_Cut_Spd33 = client.get_node("ns=2;s=glob/spool_cut_spd2")
                    Spool_Cut_Spd3 = Spool_Cut_Spd33.get_value()
                    print("Spool_Cut_Spd3"+str(Spool_Cut_Spd3))

                    Spool_Dia_Min1 = client.get_node("ns=2;s=glob/no_tape_level_min")
                    Spool_Dia_Min = Spool_Dia_Min1.get_value()
                    print("Spool_Dia_Min"+str(Spool_Dia_Min))

                    Spool_Dia_Max1 = client.get_node("ns=2;s=glob/no_tape_level_max1")
                    Spool_Dia_Max = Spool_Dia_Max1.get_value()
                    print("Spool_Dia_Max"+str(Spool_Dia_Max))

                    Left_Audio_Feed_Crct1 = client.get_node("ns=2;s=glob/high_afc")
                    Left_Audio_Feed_Crct = Left_Audio_Feed_Crct1.get_value()
                    print("Left_Audio_Feed_Crct"+str(Left_Audio_Feed_Crct))

                    Right_Audio_Feed_Crct1 = client.get_node("ns=2;s=glob/low_afc")
                    Right_Audio_Feed_Crct = Right_Audio_Feed_Crct1.get_value()
                    print("Right_Audio_Feed_Crct"+str(Right_Audio_Feed_Crct))
                    
                    Head_mot_curr1 = client.get_node("ns=2;s=io/_direct.head_motor_inertia")
                    Head_mot_curr = Head_mot_curr1.get_value()
                    print("Head_mot_curr"+str(Head_mot_curr))

                    Spool_mot_curr1 = client.get_node("ns=2;s=io/_quality.cu_spool_current")
                    Spool_mot_curr = Spool_mot_curr1.get_value()
                    print("Spool_mot_curr"+str(Spool_mot_curr))

                    Fault_in_Sys1 = client.get_node("ns=2;s=glob/fault_in_system")
                    Fault_in_Sys = Fault_in_Sys1.get_value()
                    print("Fault_in_Sys"+str(Fault_in_Sys))

                    Fault_in_Drive1 = client.get_node("ns=2;s=glob/fault_present_on_drive")
                    Fault_in_Drive = Fault_in_Drive1.get_value()
                    print("Fault_in_Drive"+str(Fault_in_Drive))

                    Spool_Tapecut_Fault1 = client.get_node("ns=2;s=glob/tape_cut")
                    Spool_Tapecut_Fault = Spool_Tapecut_Fault1.get_value()
                    print("Spool_Tapecut_Fault"+str(Spool_Tapecut_Fault))

                    Alarm11 = client.get_node("ns=2;s=unit/IoT_SendReceive.allD[0]")
                    Alarm1 = Alarm11.get_value()
                    print("Alarm1"+str(Alarm1))
                    
                    # Alarm22 = client.get_node("ns=2;s=unit/IoT_SendReceive.alID[0]")
                    # Alarm2 = Alarm22.get_value()
                    # print("Alarm2"+str(Alarm2))
                    
                    # Alarm33 = client.get_node("ns=2;s=unit/IoT_SendReceive.alID[0]")
                    # Alarm3 = Alarm33.get_value()
                    # print("Alarm3"+str(Alarm3))
                    
                    # Alarm44 = client.get_node("ns=2;s=unit/IoT_SendReceive.alID[0]")
                    # Alarm = Alarm44.get_value()
                    # print("Alarm4"+str(Alarm4))
                    
                    # Alarm55 = client.get_node("ns=2;s=unit/IoT_SendReceive.alID[0]")
                    # Alarm5 = Alarm55.get_value()
                    # print("Alarm5"+str(Alarm5))

                    # Brand_Sys_ON_OFF1 = client.get_node("Brand System ON/OFF")
                    # Brand_Sys_ON_OFF = Brand_Sys_ON_OFF1.get_value()
                    # print("Brand_Sys_ON_OFF"+str(Brand_Sys_ON_OFF))

                    # Tension_Contractor1 = client.get_node("ns=2;s=io/_direct.main_contactor_fb")
                    # Tension_Contractor = Tension_Contractor1.get_value()
                    # print("Tension_Contractor"+str(Tension_Contractor))

                    # UnWrap_ON_Sol1 = client.get_node("ns=2;s=io/_direct.unwrap_sol_on")
                    # UnWrap_ON_Sol = UnWrap_ON_Sol1.get_value()
                    # print("UnWrap_ON_Sol"+str(UnWrap_ON_Sol))

                    # Wrap_Left1 = client.get_node("ns=2;s=io/_direct.wrap_left")
                    # Wrap_Left = Wrap_Left1.get_value()
                    # print("Wrap_Left"+str(Wrap_Left))

                    # Wrap_ON_Sol1 = client.get_node("ns=2;s=io/_direct.wrap_sol_on")
                    # Wrap_ON_Sol = Wrap_ON_Sol1.get_value()
                    # print("Wrap_ON_Sol"+str(Wrap_ON_Sol))

                    # Wrap_Right1 = client.get_node("ns=2;s=io/_direct.wrap_right")
                    # Wrap_Right = Wrap_Right1.get_value()
                    # print("Wrap_Right"+str(Wrap_Right))

                    # Brand_Tape_Fault1 = client.get_node("ns=2;s=io/_direct.Tape_UP_Fault")
                    # Brand_Tape_Fault = Brand_Tape_Fault1.get_value()
                    # print("Brand_Tape_Fault"+str(Brand_Tape_Fault))
                    
                    #values which are red
                    # Brand_Fault_inp1 = client.get_node("ns=2;s=io/_direct.Tape_UP_Fault")
                    # Brand_Fault_inp = Brand_Fault_inp1.get_value()
                    # print("Brand_Fault_inp"+str(Brand_Fault_inp))

                    # Brand_Ready_inp1 = client.get_node("ns=2;s=io/_direct.Tape_UP_RDY")
                    # Brand_Ready_inp = Brand_Ready_inp1.get_value()
                    # print("Brand_Ready_inp"+str(Brand_Ready_inp))
                    
                    #variables in Problem
                    #1. Brand_Sys_ON_OFF
                    #2. Tension_Contractor
                    #3. UnWrap_ON_Sol
                    #4. Wrap_Left
                    #5. Wrap_ON_Sol
                    #6. Wrap_Right
                    #7. Brand_Tape_Fault
                    #8. Brand_Fault_inp
                    #9. Brand_Ready_inp
                    #10. TAPE RESET
                    #11.All Alarms
                    time.sleep(10)
                    print("\n\n\n")
                except Exception as ex:
                    print(ex)
                    #client.disconnect()
    except Exception as exep:
        print("outer error:-", exep)
