﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace hosewrapping.Models
{
    public class machinedata
    {
        public DateTime date_time;
        public int stop_time;
        public int run_time;
        public int fault_time;
        public double cumm_run_len;
        public string mac_serial;
        public string mac_num;
        public DateTime PLC_Time;
        public double mac_speed;
        public double prod_speed;
        public double Actual_Pitch;
        public double Hose_Dia;
        public double Tape_Width;
        public double Tape_Thickness;
        public double Spool_Tension_Wrap;
        public double Spool_Tension_Unwrap;
        public double Brand_Tension_Wrap;
        public double Brand_Tension_Unwrap;
        public double Overlap;
        public double Pitch_Wrap;
        public double Pitch_Unwrap;
        public bool Wrap_Unwrap;
        public double Dwell_Angle;
        public bool Jog_Spd;
        public bool Low_Spd;
        public bool Run_Spd;
        public bool Stop_Spd;
        public bool mac_Stop;
        public bool Homing_Done;
        public bool Letoff_On_Off;
        public bool Takeup_On_Off;
        public int Head_Fault_Code;
        public int Spool_Fault_Code;
        public int CAT_Fault_Code;
        public int BLM_Fault_Code;
        public int Letoff_Fault_Code;
        public int Takeup_Fault_Code;
        public int Head_Alarm_Code;
        public int Spool_Alarm_Code;
        public int CAT_Alarm_Code;
        public int Letoff_Alarm_Code;
        public int Takeup_Alarm_Code;
        public int Head_Mot_Curr;
        public int Spool_Mot_Curr;
        public int Head_Motor_Temp;
        public int Spool_Motor_Temp;
        public int CAT_Motor_Temp;
        public int CPU_Temp;
        public bool Fault_in_Sys;
        public bool Fault_in_Drive;
        public bool Spool_Tapecut_Fault;
        public bool Brand_Tape_Fault;
        public bool Brand_Fault_inp;
        public bool Brand_Ready_inp;
        public string alarms;

    }
}
