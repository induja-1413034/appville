﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using hosewrapping.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace hosewrapping.Controllers
{
    public class InsertDataController : Controller
    {
        public IConfiguration Configuration { get; }
        public InsertDataController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        /* public IActionResult InsertData()
         {
             return View();
         }*/
        [HttpPost]
        public IActionResult Create(string Machine_details)
        {
            try
            {
                machinedata machine = new machinedata();
                machine = JsonConvert.DeserializeObject<machinedata>(Machine_details);
                List<string> errorcodes_new = new List<string>();
                int machinedata_id = 0;

                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    MySqlTransaction transaction;
                    transaction = conn.BeginTransaction();
                    try
                    {
                        StringBuilder sb = new StringBuilder();
                        string sql = "";
                        if (machine.run_time == 0 & machine.fault_time == 0 & machine.stop_time == 0 &
                            machine.cumm_run_len == 0)
                        {
                            return Ok(new
                            {
                                message = "Skipped because of 0 values"
                            });
                        }
                        else
                        {
                            if (machine.alarms != null)
                            {
                                errorcodes_new = machine.alarms.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.Trim()).ToList();                                
                                sb.Clear();
                                sb.Append("INSERT INTO machine_data(date_time,stop_time,run_time,fault_time,cumm_run_len,mac_serial,mac_num,PLC_Time,mac_speed,prod_speed,Actual_Pitch,Hose_Dia,Tape_Width,Tape_Thickness,Spool_Tension_Wrap,Spool_Tension_Unwrap,Brand_Tension_Wrap,Brand_Tension_Unwrap,Overlap,Pitch_Wrap,Pitch_Unwrap,Wrap_Unwrap,Dwell_Angle,Jog_Spd,Low_Spd,Run_Spd,Stop_Spd,mac_Stop,Homing_Done,Letoff_On_Off,Takeup_On_Off,Head_Fault_Code,Spool_Fault_Code,CAT_Fault_Code,BLM_Fault_Code,Letoff_Fault_Code,Takeup_Fault_Code,Head_Alarm_Code,Spool_Alarm_Code,CAT_Alarm_code,Letoff_Alarm_code,Takeup_alarm_code,Head_Mot_Curr,Spool_Mot_Curr,Head_Motor_Temp,Spool_Motor_Temp,CAT_Motor_Temp,CPU_Temp,Fault_in_Sys,Fault_in_Drive,Spool_Tapecut_Fault,Brand_Tape_Fault,Brand_Fault_inp,Brand_Ready_inp)");
                                sb.Append(" VALUES(@date_time,@stop_time,@run_time,@fault_time,@cumm_run_len,@mac_serial,@mac_num,@PLC_Time,@mac_speed,@prod_speed,@Actual_Pitch,@Hose_Dia,@Tape_Width,@Tape_Thickness,@Spool_Tension_Wrap,@Spool_Tension_Unwrap,@Brand_Tension_Wrap,@Brand_Tension_Unwrap,@Overlap,@Pitch_Wrap,@Pitch_Unwrap,@Wrap_Unwrap,@Dwell_Angle,@Jog_Spd,@Low_Spd,@Run_Spd,@Stop_Spd,@mac_Stop,@Homing_Done,@Letoff_On_Off,@Takeup_On_Off,@Head_Fault_Code,@Spool_Fault_Code,@CAT_Fault_Code,@BLM_Fault_Code,@Letoff_Fault_Code,@Takeup_Fault_Code,@Head_Alarm_Code,@Spool_Alarm_Code,@CAT_Alarm_code,@Letoff_Alarm_code,@Takeup_alarm_code,@Head_Mot_Curr,@Spool_Mot_Curr,@Head_Motor_Temp,@Spool_Motor_Temp,@CAT_Motor_Temp,@CPU_Temp,@Fault_in_Sys,@Fault_in_Drive,@Spool_Tapecut_Fault,@Brand_Tape_Fault,@Brand_Fault_inp,@Brand_Ready_inp);");
                                //sb.Append(" select last_insert_id() as _id");
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    command.Parameters.AddWithValue("@date_time", machine.date_time);
                                    command.Parameters.AddWithValue("@stop_time", machine.stop_time);
                                    command.Parameters.AddWithValue("@run_time", machine.run_time);
                                    command.Parameters.AddWithValue("@fault_time", machine.fault_time);
                                    command.Parameters.AddWithValue("@cumm_run_len", machine.cumm_run_len);
                                    command.Parameters.AddWithValue("@mac_serial", machine.mac_serial);
                                    command.Parameters.AddWithValue("@mac_num", machine.mac_num);
                                    command.Parameters.AddWithValue("@PLC_Time", machine.PLC_Time);
                                    command.Parameters.AddWithValue("@mac_speed", machine.mac_speed);
                                    command.Parameters.AddWithValue("@prod_speed", machine.prod_speed);
                                    command.Parameters.AddWithValue("@Actual_Pitch", machine.Actual_Pitch);
                                    command.Parameters.AddWithValue("@Hose_Dia", machine.Hose_Dia);
                                    command.Parameters.AddWithValue("@Tape_Width", machine.Tape_Width);
                                    command.Parameters.AddWithValue("@Tape_Thickness", machine.Tape_Thickness);
                                    command.Parameters.AddWithValue("@Spool_Tension_Wrap", machine.Spool_Tension_Wrap);
                                    command.Parameters.AddWithValue("@Spool_Tension_Unwrap", machine.Spool_Tension_Unwrap);
                                    command.Parameters.AddWithValue("@Brand_Tension_Wrap", machine.Brand_Tension_Wrap);
                                    command.Parameters.AddWithValue("@Brand_Tension_Unwrap", machine.Brand_Tension_Unwrap);
                                    command.Parameters.AddWithValue("@Overlap", machine.Overlap);
                                    command.Parameters.AddWithValue("@Pitch_Wrap", machine.Pitch_Wrap);
                                    command.Parameters.AddWithValue("@Pitch_Unwrap", machine.Pitch_Unwrap);
                                    command.Parameters.AddWithValue("@Wrap_Unwrap", machine.Wrap_Unwrap);
                                    command.Parameters.AddWithValue("@Dwell_Angle", machine.Dwell_Angle);
                                    command.Parameters.AddWithValue("@Jog_Spd", machine.Jog_Spd);
                                    command.Parameters.AddWithValue("@Low_Spd", machine.Low_Spd);
                                    command.Parameters.AddWithValue("@Run_Spd", machine.Run_Spd);
                                    command.Parameters.AddWithValue("@Stop_Spd", machine.Stop_Spd);
                                    command.Parameters.AddWithValue("@mac_Stop", machine.mac_Stop);
                                    command.Parameters.AddWithValue("@Homing_Done", machine.Homing_Done);
                                    command.Parameters.AddWithValue("@Letoff_On_Off", machine.Letoff_On_Off);
                                    command.Parameters.AddWithValue("@Takeup_On_Off", machine.Takeup_On_Off);
                                    command.Parameters.AddWithValue("@Head_Fault_Code", machine.Head_Fault_Code);
                                    command.Parameters.AddWithValue("@Spool_Fault_Code", machine.Spool_Fault_Code);
                                    command.Parameters.AddWithValue("@CAT_Fault_Code", machine.CAT_Fault_Code);
                                    command.Parameters.AddWithValue("@BLM_Fault_Code", machine.BLM_Fault_Code);
                                    command.Parameters.AddWithValue("@Letoff_Fault_Code", machine.Letoff_Fault_Code);
                                    command.Parameters.AddWithValue("@Takeup_Fault_Code", machine.Takeup_Fault_Code);
                                    command.Parameters.AddWithValue("@Head_Alarm_Code", machine.Head_Alarm_Code);
                                    command.Parameters.AddWithValue("@Spool_Alarm_Code", machine.Spool_Alarm_Code);
                                    command.Parameters.AddWithValue("@CAT_Alarm_Code", machine.CAT_Alarm_Code);
                                    command.Parameters.AddWithValue("@Letoff_Alarm_Code", machine.Letoff_Alarm_Code);
                                    command.Parameters.AddWithValue("@Takeup_Alarm_Code", machine.Takeup_Alarm_Code);
                                    command.Parameters.AddWithValue("@Head_Mot_Curr", machine.Head_Mot_Curr);
                                    command.Parameters.AddWithValue("@Spool_Mot_Curr", machine.Spool_Mot_Curr);
                                    command.Parameters.AddWithValue("@Head_Motor_Temp", machine.Head_Motor_Temp);
                                    command.Parameters.AddWithValue("@Spool_Motor_Temp", machine.Spool_Motor_Temp);
                                    command.Parameters.AddWithValue("@CAT_Motor_Temp", machine.CAT_Motor_Temp);
                                    command.Parameters.AddWithValue("@CPU_Temp", machine.CPU_Temp);
                                    command.Parameters.AddWithValue("@Fault_in_Sys", machine.Fault_in_Sys);
                                    command.Parameters.AddWithValue("@Fault_in_Drive", machine.Fault_in_Drive);
                                    command.Parameters.AddWithValue("@Spool_Tapecut_Fault", machine.Spool_Tapecut_Fault);
                                    command.Parameters.AddWithValue("@Brand_Tape_Fault", machine.Brand_Tape_Fault);
                                    command.Parameters.AddWithValue("@Brand_Fault_inp", machine.Brand_Fault_inp);
                                    command.Parameters.AddWithValue("@Brand_Ready_inp", machine.Brand_Ready_inp);
                                    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                                }
                            }
                            
                        }
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        return BadRequest(ex.Message);
                    }
                }
                return Ok(new
                {
                    message = "Added Successfully"
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
    