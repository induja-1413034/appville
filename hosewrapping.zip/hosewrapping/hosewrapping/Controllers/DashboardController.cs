﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace hosewrapping.Controllers
{
    public class DashboardController : Controller
    {
        public IConfiguration Configuration { get; }
        public DashboardController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
      
        public IActionResult Dashboard()
        {            
                return View();
        }
    }
}