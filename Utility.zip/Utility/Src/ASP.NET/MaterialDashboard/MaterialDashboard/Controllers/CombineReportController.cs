﻿using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using MySql.Data.MySqlClient;
using System.Data;
using System.Text;

namespace MaterialDashboard.Controllers
{
    public class CombineReportController : Controller
    {
        private appvilledbContext _context;
        public IConfiguration Configuration { get; }
        public CombineReportController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IActionResult CombineReport()
        {
            Nullable<int> cli_id = HttpContext.Session.GetInt32("cli_id");
            HttpContext.Session.SetInt32("cli_id", Convert.ToInt32(cli_id));
            _context = new appvilledbContext();
            ViewBag.CliMacView = _context.CliMacView.Where(y => y.cli_id == cli_id).Select(x => x.serial).ToList();
            return View();
        }

        private string ConvertTimetoReadableFormat(int time_val)
        {
            string hours = (time_val / 60).ToString().PadLeft(2, '0');
            string minutes = (time_val % 60).ToString().PadLeft(2, '0');
            var time_formatted = string.Format("{0}:{1}", hours, minutes);
            return time_formatted;
        }

        [HttpPost]
        public IActionResult PieChart(string serial, string dt_val1, string dt_val2)
        {
            try
            {
                _context = new appvilledbContext();
                DateTime From_date = Convert.ToDateTime(dt_val1);
                DateTime To_date = Convert.ToDateTime(dt_val2);
                var viewres1 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).OrderBy(y => y.time_recv).FirstOrDefault();
                var viewres2 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).OrderByDescending(y => y.time_recv).FirstOrDefault();
                int idle_time = 0;
                int up_time = 0;
                int wait_time = 0;
                int prod_count = 0;
                var viewres3 = 0;
                var error_time = 0;
                var stop_time = 0;
                var OEE_value = 0.0;
                var cycle_time = 0;
                var planned_production_time = 0.0;
                var stop_time_formatted = "";
                var up_time_formatted = "";
                var wait_time_formatted = "";
                var error_time_formatted = "";
                if (viewres1 == null || viewres2 == null)
                {
                    ViewBag.Message = "No Data";
                }
                else
                {
                    idle_time = Convert.ToInt32(viewres2.idle_time) - Convert.ToInt32(viewres1.idle_time);
                    up_time = Math.Abs(Convert.ToInt32(viewres2.up_time) - Convert.ToInt32(viewres1.up_time));
                    wait_time = Math.Abs(Convert.ToInt32(viewres2.wait_time) - Convert.ToInt32(viewres1.wait_time));
                    prod_count = Convert.ToInt32(viewres2.count) - Convert.ToInt32(viewres1.count);
                    viewres3 = _context.UtlMacDet.Where(y => y.time_recv >= From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial) && y.status.Equals("4") && y.time < 1000).Sum(y => y.time);
                    error_time = viewres3 / 60;
                    stop_time = Math.Abs(Convert.ToInt32(idle_time) - Convert.ToInt32(error_time));
                    planned_production_time = (viewres2.time_recv - viewres1.time_recv).TotalSeconds;
                    var details1 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial) && y.cycle_time == 0).Count();
                    if (details1 > 10)
                    {
                        OEE_value = 0.0;
                    }
                    else
                    {
                        var details = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).GroupBy(x => x.cycle_time).Select(y => new { Idle_cycle_time = y.Key, prod_count = (y.Max(z => z.count) - y.Min(s => s.count)) }).ToList();
                        var numerator = details.Sum(x => x.Idle_cycle_time * x.prod_count);
                        OEE_value = numerator / (planned_production_time * 1000);
                    }
                    stop_time_formatted = "stop: " + ConvertTimetoReadableFormat(stop_time);
                    up_time_formatted = "up: " + ConvertTimetoReadableFormat(up_time);
                    wait_time_formatted = "wait: " + ConvertTimetoReadableFormat(wait_time);
                    error_time_formatted = "error: " + ConvertTimetoReadableFormat(error_time);
                }
                return Ok(new[] { new
            {
                idle_time = idle_time,
                error_time = error_time,
                stop_time = stop_time,
                up_time = up_time,
                wait_time = wait_time,
                prod_count = prod_count,
                error_time1 = error_time,
                up_time_formatted = up_time_formatted,
                wait_time_formatted = wait_time_formatted,
                error_time_formatted = error_time_formatted,
                stop_time_formatted = stop_time_formatted,
                OEE_value = OEE_value
            }});
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost]
        public IActionResult Load_Table(string serial, string dt_val1, string dt_val2)
        {
            try
            {
                _context = new appvilledbContext();
                DateTime From_date = Convert.ToDateTime(dt_val1);
                DateTime To_date = Convert.ToDateTime(dt_val2);
                var sells = _context.UtlErrForGraph
                    .Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial) && y.time < 1000)
         .GroupBy(a => new { a.error_code, a.error_details })
         .Select(a => new { errorcode = a.Key.error_code, total_time = a.Sum(b => b.time), err_des = a.Key.error_details })
         .OrderByDescending(a => a.total_time)
         .ToList();
                string[] total_time = new string[sells.Count];
                for (int t = 0; t < sells.Count; t++)
                {
                    string hours = Convert.ToString(TimeSpan.FromSeconds(sells[t].total_time / 3600));
                    string minutes = Convert.ToString(TimeSpan.FromSeconds((sells[t].total_time / 60) % 60));
                    string seconds = Convert.ToString(TimeSpan.FromSeconds(sells[t].total_time % 60));
                    string[] hoursformat = hours.Split(":");
                    string[] minutesformat = minutes.Split(":");
                    string[] secondsformat = seconds.Split(":");
                    total_time[t] = hoursformat[2] + ":" + minutesformat[2] + ":" + secondsformat[2];
                }
                return Ok(sells);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        public IActionResult Load_Combine_Table(string serial, string dt_val1, string dt_val2)
        {
            _context = new appvilledbContext();
            try
            {
                List<returnforjson1> returnforjsons = new List<returnforjson1>();
                returnforjson1 returnforjson2 = null;
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Append("select min(cast(time_recv as time)), max(cast(time_recv as Time)), utl_mac_error.error_code, utl_error_info.error_details");
                    sb.Append(" from utl_mac_det inner join utl_mac_error on utl_mac_error.data_id=utl_mac_det.sno");
                    sb.Append(" inner join utl_error_info on utl_mac_error.error_code = utl_error_info.error_code and utl_error_info.machine_serial = utl_mac_det.machine_serial");
                    sb.Append(string.Format(" where utl_mac_det.time_recv between '{0}' and '{1}' and utl_mac_det.machine_serial='{2}'", dt_val1, dt_val2, serial));
                    sb.Append(" group by utl_mac_error.codegrouping order by utl_mac_det.time_recv");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                returnforjson2 = new returnforjson1();
                                returnforjson2.time_range = string.Format("{0}-{1}", reader.GetTimeSpan(0), reader.GetTimeSpan(1));
                                returnforjson2.Err_code = reader.GetInt32(2).ToString();
                                returnforjson2.Err_des = reader.GetString(3);
                                returnforjsons.Add(returnforjson2);
                            }
                        }
                    }
                }
                return Ok(returnforjsons);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public class returnforjson1
        {
            public string time_range;
            public string Err_code;
            public string Err_des;
        }


        public IActionResult Load_detail_Table(string serial, string dt_val1, string dt_val2, string err_code)
        {
            try
            {
                List<timereport> timelist = new List<timereport>();
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Append("select cast(time_recv as date), min(cast(time_recv as time)), max(cast(time_recv as Time)), sum(time) from utl_mac_det");
                    sb.Append(" inner join utl_mac_error on utl_mac_error.data_id=utl_mac_det.sno");
                    sb.Append(string.Format(" where utl_mac_det.time_recv between '{0}' and '{1}' and error_code='{2}' and utl_mac_det.machine_serial='{3}'", dt_val1, dt_val2, err_code, serial));
                    sb.Append(" group by utl_mac_error.codegrouping, cast(utl_mac_det.time_recv as date) order by utl_mac_det.time_recv");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timereport time = new timereport();
                                time.date = reader.GetDateTime(0);
                                time.start_time = reader.GetTimeSpan(1);
                                time.end_time = reader.GetTimeSpan(2);
                                var tot_time_in_seconds = reader.GetInt32(3);
                                if (tot_time_in_seconds == '0')
                                {
                                    timelist.Add(time);
                                    continue;
                                }
                                time.Total_time = TimeSpan.FromSeconds(tot_time_in_seconds);
                                timelist.Add(time);
                            }
                        }
                    }
                }
                return Ok(timelist);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Linegraph(string dt_val1, string dt_val2,string serial)
        {
            
            _context = new appvilledbContext();
            returnforjson returnforjson = null;
            DateTime From_date = Convert.ToDateTime(dt_val1);
            DateTime To_date = Convert.ToDateTime(dt_val2);
            var viewres1 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).OrderBy(y => y.time_recv).ToList();
            var viewres2 = _context.MacDetailsErrorView.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).OrderBy(y => y.time_recv).ToList();
            viewres1.ToArray();
            viewres2.ToArray();
            string[] speed;
            DateTime[] time_recv;
            Nullable<int>[] stoppingalarm;
            string[] error_description;
            if (viewres1.Count == 0 && viewres2.Count == 0)
            {
                speed = new string[1];
                time_recv = new DateTime[1];
                stoppingalarm = new Nullable<int>[1];
                error_description = new string[1];
                return Ok(new
                {

                });
            }
            else
            {
                try
                {
                    speed = new string[viewres1.Count];
                    time_recv = new DateTime[viewres1.Count];
                    stoppingalarm = new Nullable<int>[viewres1.Count];
                    error_description = new string[viewres1.Count];
                    for (int i = 0; i < viewres1.Count; i++)
                    {
                        speed[i] = viewres1[i].speed;
                        time_recv[i] = viewres1[i].time_recv;
                        var test = viewres2[i].error_code;
                        if (test == null)
                        {

                            if (viewres2[i].error_code == null)
                            {
                                stoppingalarm[i] = 0;
                                error_description[i] = "---";
                            }
                        }
                        else
                        {
                            stoppingalarm[i] = viewres2[i].error_code;
                            error_description[i] = viewres2[i].error_details;
                        }
                    }
                    returnforjsons returnforjson_list = new returnforjsons();
                    returnforjsons returnforjson_list1 = new returnforjsons();
                    for (int i = 0; i < viewres1.Count; i++)
                    {
                        returnforjson = new returnforjson();
                        var stop = stoppingalarm[i];
                        var description = error_description[i];
                        var combine = "";
                        if (stop == 0 && description == "---")
                        {
                            combine = time_recv[i].ToString("yyyy-MM-dd hh:mm:ss");
                        }
                        else
                        {
                            //+" - Error_description " + error_description[i]
                            combine = time_recv[i].ToString("yyyy-MM-dd hh:mm:ss") + " - Blocking alarm: " + stoppingalarm[i].ToString() + " - Error Description: " + error_description[i];
                        }
                        returnforjson.meta = combine;
                        returnforjson.value = int.Parse(speed[i]);
                        // error[i] = stoppingalarm[i];
                        returnforjson_list.returnforjsonsnew.Add(returnforjson);
                    }
                    return Ok(new
                    {
                        test = returnforjson_list.returnforjsonsnew
                    });
                }
                catch(Exception e) {
                    return BadRequest(e.Message);
                }
               
            }
            
        }

        public class returnforjsons
        {
            public List<returnforjson> returnforjsonsnew = new List<returnforjson>();

        }
        public class returnforjson
        {
            public int value;
            // public int? value1;
            public string meta;
        };
        public class timereport
        {
            public DateTime date;
            public TimeSpan start_time;
            public TimeSpan end_time;
            public TimeSpan Total_time;
        }
    }
}


