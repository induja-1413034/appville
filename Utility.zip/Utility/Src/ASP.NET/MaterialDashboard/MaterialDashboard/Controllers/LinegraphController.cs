﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MaterialDashboard.Controllers
{
    public class LinegraphController : Controller
    {
        private appvilledbContext _context;
        public IActionResult Linegraph()
        {
            return View();
        }

        //[HttpPost]
        //public IActionResult Linegraph(string dt_val1, string dt_val2)
        //{
        //    _context = new appvilledbContext();            
        //    //List<returnforjson_list.returnforjsonsnew> returnforjsons = new List<returnforjson_list.returnforjsonsnew>();
        //    returnforjson returnforjson = null;
        //    DateTime From_date = Convert.ToDateTime(dt_val1);
        //    DateTime To_date = Convert.ToDateTime(dt_val2);
        //    var viewres1 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date).OrderBy(y => y.time_recv).ToList();
        //    var viewres2 = _context.MacDetailsErrorView.Where(y => y.time_recv > From_date && y.time_recv <= To_date).OrderBy(y => y.time_recv).ToList();
        //          viewres1.ToArray();
        //    viewres2.ToArray();
        //    string[] speed = new string[viewres1.Count];
        //          Nullable<int>[] stoppingalarm = new Nullable<int>[viewres2.Count];
        //          DateTime[] time_recv = new DateTime[viewres1.Count];
        //    for (int i = 0; i < viewres2.Count; i++)
        //    {
        //        speed[i] = viewres1[i].speed;
        //        time_recv[i] = viewres1[i].time_recv;
        //        if (viewres2[i].error_code == null) { 
        //            stoppingalarm[i] = 0;
        //        }
        //        else
        //        {
        //            stoppingalarm[i] = viewres2[i].error_code;
        //        }
        //    }
        //        /* for (int i = 0; i <viewres1.Count; i++)
        //         {
        //             if (viewres1[i].status.Equals("4"))
        //             {
        //                 speed[i] = viewres1[i].speed;
        //                 time_recv[i] = viewres1[i].time_recv;
        //                 stoppingalarm[i] = viewres1[i].speed;
        //             }
        //             else
        //             {
        //                 speed[i] = viewres1[i].speed;
        //                 stoppingalarm[i] = "0";
        //                 time_recv[i] = viewres1[i].time_recv;
        //             }
        //         }*/
        //        returnforjsons returnforjson_list = new returnforjsons();
        //    returnforjsons returnforjson_list1 = new returnforjsons();
        //    // returnforjson_list.returnforjsonsnew.
        //    for (int i = 0; i < viewres1.Count; i++)
        //          {
        //              returnforjson = new returnforjson();
        //        // returnforjson.stoppingalarm = stoppingalarm[i];
        //        var stop = stoppingalarm[i];
        //        var combine = "";
        //        if (stop==0) {
        //            combine = time_recv[i].ToString("yyyy-MM-dd hh:mm:ss");
        //        }
        //        else { 
        //        combine = time_recv[i].ToString("yyyy-MM-dd hh:mm:ss") + " - Blocking alarm: " + stoppingalarm[i].ToString();
        //        }
        //        returnforjson.meta = combine;
        //        returnforjson.value = int.Parse(speed[i]);
        //        returnforjson_list.returnforjsonsnew.Add(returnforjson);
        //          }
        //    /* for (int i = 0; i < viewres1.Count; i++)
        //     {
        //         returnforjson = new returnforjson();
        //         // returnforjson.stoppingalarm = stoppingalarm[i];
        //         returnforjson.meta = time_recv[i].ToString("yyyy-MM-dd hh:mm:ss");
        //         returnforjson.value = int.Parse(stoppingalarm[i]);
        //         returnforjson_list1.returnforjsonsnew.Add(returnforjson);
        //     }*/
        //    //return Ok( new[] { returnforjson_list.returnforjsonsnew,returnforjson_list1.returnforjsonsnew
        //    // return Ok( new[] test={ returnforjson_list.returnforjsonsnew});
        //    return Ok(new
        //    {
        //        test= returnforjson_list.returnforjsonsnew
        //    });

        [HttpPost]
        public IActionResult Linegraph(string dt_val1, string dt_val2)
        {
            _context = new appvilledbContext();
            returnforjson returnforjson = null;
            DateTime From_date = Convert.ToDateTime(dt_val1);
            DateTime To_date = Convert.ToDateTime(dt_val2);
            var viewres1 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date).OrderBy(y => y.time_recv).ToList();
            var viewres2 = _context.MacDetailsErrorView.Where(y => y.time_recv > From_date && y.time_recv <= To_date).OrderBy(y => y.time_recv).ToList();
            viewres1.ToArray();
            viewres2.ToArray();
            string[] speed = new string[viewres1.Count];
            Nullable<int>[] stoppingalarm = new Nullable<int>[viewres2.Count];
            DateTime[] time_recv = new DateTime[viewres1.Count];
            for (int i = 0; i < viewres2.Count; i++)
            {
                speed[i] = viewres1[i].speed;
                time_recv[i] = viewres1[i].time_recv;
                if (viewres2[i].error_code == null)
                {
                    stoppingalarm[i] = 0;
                }
                else
                {
                    stoppingalarm[i] = viewres2[i].error_code;
                }
            }
            returnforjsons returnforjson_list = new returnforjsons();
            returnforjsons returnforjson_list1 = new returnforjsons();
            for (int i = 0; i < viewres1.Count; i++)
            {
                returnforjson = new returnforjson();
                var stop = stoppingalarm[i];
                var combine = "";
                if (stop == 0)
                {
                    combine = time_recv[i].ToString("yyyy-MM-dd hh:mm:ss");
                }
                else
                {
                    combine = time_recv[i].ToString("yyyy-MM-dd hh:mm:ss") + " - Blocking alarm: " + stoppingalarm[i].ToString();
                }
                returnforjson.meta = combine;
                returnforjson.value = int.Parse(speed[i]);
                returnforjson_list.returnforjsonsnew.Add(returnforjson);
            }
            return Ok(new
            {
                test = returnforjson_list.returnforjsonsnew
            });

        }
        public class returnforjsons
        {
            public List<returnforjson> returnforjsonsnew = new List<returnforjson>();

        }
        public class returnforjson
        {
            public int value;
            public string meta;
        };
    }
}