﻿using System;
using System.Linq;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MaterialDashboard.Controllers
{
    public class MachineLiveStatusController : Controller
    {
        private appvilledbContext _context;
        public IActionResult MachineLiveStatus(string serial)
        {
            _context = new appvilledbContext();
            if (serial == null)
            {
                HttpContext.Session.GetInt32("cli_id");
                uint id = Convert.ToUInt32(HttpContext.Session.GetInt32("cli_id"));
                HttpContext.Session.SetInt32("cli_id", Convert.ToInt32(id));
                ViewBag.CliMacView = _context.CliMacView.Where(y => y.cli_id == id).Select(x => x.serial).ToList();
                return View();
            }
            else
            {
                var Model_id = _context.CliMacView.Where(y => y.serial == serial).Select(x => x.model_id).FirstOrDefault();
                var Image_link = _context.RemModel.Where(y => y.model_id == Model_id).Select(x => x.Image_to_upload_path).FirstOrDefault();
                return Ok(Image_link);
            }
        }
        /* public IActionResult MachineLiveStatus()
         {
             HttpContext.Session.GetInt32("cli_id");
             uint id = Convert.ToUInt32(HttpContext.Session.GetInt32("cli_id"));
             HttpContext.Session.SetInt32("cli_id", Convert.ToInt32(id));
             _context = new appvilledbContext();
             ViewBag.CliMacView = _context.CliMacView.Where(y => y.cli_id == id).Select(x => x.serial).ToList();
             return View();
         }*/
        public IActionResult Test()
        {
            HttpContext.Session.GetInt32("cli_id");
            uint id = Convert.ToUInt32(HttpContext.Session.GetInt32("cli_id"));
            HttpContext.Session.SetInt32("cli_id", Convert.ToInt32(id));
            _context = new appvilledbContext();
            ViewBag.CliMacView = _context.CliMacView.Where(y => y.cli_id == id).Select(x => x.serial).ToList();
            return View();
        }
    }
}