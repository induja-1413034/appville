﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MaterialDashboard.Controllers
{
    public class UserDetailsController : Controller
    {
        private appvilledbContext _context;

        public async Task<IActionResult> UserDetails(uint Id)
        {
            _context = new appvilledbContext();
            List<LoginTab> login = await _context.LoginTab.ToListAsync();
            ViewResult details = View(login.Where(x => x.cli_id == Id).ToList());
            Nullable<int> session = HttpContext.Session.GetInt32("test");            
            if (session == 23)
                return details;
             else
                return RedirectToAction("Index", "Home");
        }
        public IActionResult AddUser(uint Id)
        {
            return View();
        }
        [HttpPost]        
        public async Task<IActionResult> AddUser(uint Id, [Bind("Username,Password,Role,cli_id,Mail,Address,Phone")] LoginTab LoginTab)
        {            
            {
                _context = new appvilledbContext();
                LoginTab.cli_id = Id;
                LoginTab.Id = 0;
                byte[] passwordHash, passwordSalt;
                CreatePasswordHash(LoginTab.Password, out passwordHash, out passwordSalt);

                LoginTab.PasswordHash_str = Convert.ToBase64String(passwordHash);
                LoginTab.PasswordSalt_str = Convert.ToBase64String(passwordSalt);

                _context.Add(LoginTab);
                await _context.SaveChangesAsync();
                Nullable<int> session = HttpContext.Session.GetInt32("test");
                if (session == 23)
                    return RedirectToAction("UserDetails", "UserDetails", new { Id });
                else
                    return RedirectToAction("Index", "Home");
            }
        }


        private static void CreatePasswordHash(string pass_word, out byte[] passwordHash, out byte[] passwordSalt)
        {
            if (pass_word == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(pass_word)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");

            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(pass_word));
            }
        }
        

        public async Task<IActionResult> EditUser(uint Id, uint Id1)
        {

            _context = new appvilledbContext();
            if (Id.Equals(null))
            {
                return NotFound();
            }

            var details = await _context.LoginTab.FindAsync(Convert.ToInt32(Id));           
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return View(details);
             else
                return RedirectToAction("Index", "Home");

        }
        
        [HttpPost]
        public async Task<IActionResult> EditUser(uint Id, uint Id1, [Bind("Username,Password,Role,cli_id,Mail,Address,Phone")] LoginTab LoginTab)
        {
            _context = new appvilledbContext();
            LoginTab.Id = Convert.ToUInt16(Id);           

            if (Id.Equals(LoginTab.Id))
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(LoginTab);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException ex)
                {                  
                        throw ex;
                }
                LoginTab login = new LoginTab();                
                var id = LoginTab.cli_id;
                return RedirectToAction("UserDetails", "UserDetails", new { id });
            }
            return View(LoginTab);
        }
        

        public async Task<IActionResult> Btn_Click(int Id, uint cli_id)
        {
            _context = new appvilledbContext();
            int temp = Convert.ToInt16(Id);
            var details = await _context.LoginTab.FindAsync(temp);
            _context.LoginTab.Remove(details);
            await _context.SaveChangesAsync();
            Id = Convert.ToInt32(cli_id);
            return RedirectToAction("UserDetails", "UserDetails", new { Id });
        }

    }

}



