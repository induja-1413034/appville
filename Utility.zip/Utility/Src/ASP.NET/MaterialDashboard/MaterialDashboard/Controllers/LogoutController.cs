﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace MaterialDashboard.Controllers
{
    public class LogoutController : Controller
    {
        public IActionResult Logout()
        {
            return View();
        }
    }
}