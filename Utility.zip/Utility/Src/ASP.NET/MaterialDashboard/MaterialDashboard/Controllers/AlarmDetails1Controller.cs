﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MaterialDashboard.Controllers
{
    public class AlarmDetails1Controller : Controller
    {
        private appvilledbContext _context;
        public IActionResult AlarmDetails1(string id)
        {
            _context = new appvilledbContext();           
            ViewResult viewRes1 = View(_context.UtlErrorInfo.Where(x => x.machine_serial == id).OrderBy(y=>y.error_code).ToList());
            return viewRes1;
        }

        public IActionResult EditAlarm(string id,int code)
        {
            _context = new appvilledbContext();
            Nullable<int> cli_id = HttpContext.Session.GetInt32("cli_id");
            if (id.Equals(null))
            {
                return NotFound();
            }
            var details = _context.UtlErrorInfo.Where(x => x.machine_serial == id & x.error_code == code).FirstOrDefault();
            if (details == null)
            {
                return NotFound();
            }
            return View(details);
        }

        [HttpPost]
        public async Task<IActionResult> EditAlarm(string id, [Bind("_id,error_details,error_code,is_error,machine_serial")] UtlErrorInfo UtlErrorInfo)
        {
            _context = new appvilledbContext();
            if (ModelState.IsValid)
            {
                try
                {
                    var details = _context.UtlErrorInfo.Where(x => x.machine_serial == id & x.error_code == UtlErrorInfo.error_code).FirstOrDefault();
                    details.error_code = UtlErrorInfo.error_code;
                    details.error_details = UtlErrorInfo.error_details;
                    details.is_error = UtlErrorInfo.is_error;
                    _context.UtlErrorInfo.Update(details);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetailsExists(UtlErrorInfo.error_code))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
             return RedirectToAction("AlarmDetails1", "AlarmDetails1", new { id });
                    }

        private bool DetailsExists(int error_code)
        {
            throw new NotImplementedException();
        }
    }
}