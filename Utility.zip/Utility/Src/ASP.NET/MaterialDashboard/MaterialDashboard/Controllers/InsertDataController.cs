﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace MaterialDashboard.Controllers
{
    public class InsertDataController : Controller
    {       
      
        public IConfiguration Configuration { get; }
        public InsertDataController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(string Machine_details)
        {
            try
            {              
                UtlMacDetJson machine = new UtlMacDetJson();
                machine = JsonConvert.DeserializeObject<UtlMacDetJson>(Machine_details);
                DateTime latest_stored_recv_time = new DateTime();
                int prev_data_id = 0;
                int machinedata_id = 0;
                List<string> errorcodes_new = new List<string>();
                List<Errorwithgrouping> errorcodes_old = new List<Errorwithgrouping>();
                Errorwithgrouping errorwithgrouping = null;
                List<UtlMacError> errorInsertlist = new List<UtlMacError>();
                UtlMacError errorInsert = null;
                TimeSpan time = new TimeSpan();
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];               
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    MySqlTransaction transaction;
                    transaction = conn.BeginTransaction();
                    try
                    {
                        StringBuilder sb = new StringBuilder();
                        string sql = "";
                        if (machine.error != null)
                        {
                            errorcodes_new = machine.error.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.Trim()).ToList();
                            bool isFoundnull = false;
                            sb.Clear();
                            sb.Append("SELECT sno, error_code, codegrouping FROM mac_details_error_view");
                            sb.Append(string.Format(" where sno=(select max(sno) from mac_details_error_view where machine_serial='{0}')",machine.machine_serial));
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                using (MySqlDataReader reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        errorInsert = new UtlMacError();
                                        prev_data_id = reader.GetInt32(0);
                                        if (reader["error_code"] != DBNull.Value)
                                        {
                                            errorwithgrouping = new Errorwithgrouping();
                                            errorwithgrouping.Prev_errorcode = Convert.ToString(reader.GetInt32(1));
                                            errorwithgrouping.Prev_codegrouping = reader.GetDouble(2);
                                            errorcodes_old.Add(errorwithgrouping);
                                        }
                                        else
                                        {
                                            isFoundnull = true;
                                            break;
                                        }
                                    }
                                    if (isFoundnull == true)
                                    {
                                        foreach (var err in errorcodes_new)
                                        {
                                            errorInsert = new UtlMacError();
                                            // errorInsert.data_id = machinedata_id;
                                            errorInsert.error_code = Convert.ToInt32(err);
                                            errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                            errorInsertlist.Add(errorInsert);
                                        }
                                    }
                                    else
                                    {
                                        List<ErrorComparator.Error_Results> list_Err_With_Status = new List<ErrorComparator.Error_Results>();
                                        list_Err_With_Status = (new ErrorComparator()).PerformComparison(errorcodes_old, errorcodes_new);
                                        foreach (var err in list_Err_With_Status)
                                        {
                                            if (err.status == "SameErrorgrouping")
                                            {
                                                errorInsert = new UtlMacError();
                                                //errorInsert.data_id = machinedata_id;
                                                errorInsert.error_code = Convert.ToInt32(err.error);
                                                errorInsert.codegrouping = errorcodes_old.Where(y => y.Prev_errorcode == err.error).Select(x => x.Prev_codegrouping).First();
                                                errorInsertlist.Add(errorInsert);
                                            }
                                            else if (err.status == "NewErrorgrouping")
                                            {
                                                errorInsert = new UtlMacError();
                                                //errorInsert.data_id = machinedata_id;
                                                errorInsert.error_code = Convert.ToInt32(err.error);
                                                errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                                errorInsertlist.Add(errorInsert);
                                            }
                                        }
                                    }
                                }
                            }
                            sb.Clear();
                            sb.Append(string.Format("select time_recv from utl_mac_det where machine_serial='{0}' order by sno desc limit 1", machine.machine_serial));
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                using (MySqlDataReader reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        latest_stored_recv_time = reader.GetDateTime(0);
                                    }
                                }
                            }

                            //sb.Clear();
                            //sb.Append("insert into utl_data(date_time, time, time_recv) values(@date_time, @time, @time_recv);");
                            //sb.Append(" select last_insert_id() as sno");
                            //sql = sb.ToString();
                            //using (MySqlCommand command = new MySqlCommand(sql, conn))
                            //{
                            //    command.Connection = conn;
                            //    command.Transaction = transaction;
                            //    command.Parameters.AddWithValue("@date_time", DateTime.Now);
                            //    var diff_time_obj = machine.data_received_time - latest_stored_recv_time;
                            //    int diff_time = Convert.ToInt32(diff_time_obj.TotalSeconds);
                            //    command.Parameters.AddWithValue("@time", diff_time);
                            //    command.Parameters.AddWithValue("@time_recv", machine.data_received_time);
                            //    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                            //}

                            sb.Clear();
                            sb.Append("insert into utl_mac_det(machine_serial,speed,count,up_time,idle_time,PLC_time,wait_time,recipe_name,status,machine_type,date_time, time, time_recv,cycle_time) values(@machine_serial,@speed,@count,@up_time,@idle_time,@PLC_time, @wait_time,@recipe_name,@status,@machine_type,@date_time, @time, @time_recv,@cycle_time);");
                            sb.Append(" select last_insert_id() as sno");
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                command.Parameters.AddWithValue("@date_time", DateTime.Now);
                             
                                var diff_time_obj = machine.data_received_time - latest_stored_recv_time;
                                int diff_time = Convert.ToInt32(diff_time_obj.TotalSeconds);
                                command.Parameters.AddWithValue("@time", diff_time);
                                command.Parameters.AddWithValue("@time_recv", machine.data_received_time);
                                //command.Parameters.AddWithValue("@data_id", machinedata_id);
                                command.Parameters.AddWithValue("@machine_serial", machine.machine_serial);
                                command.Parameters.AddWithValue("@speed", machine.speed);
                                command.Parameters.AddWithValue("@count", machine.count);
                                command.Parameters.AddWithValue("@up_time", machine.up_time);
                                command.Parameters.AddWithValue("@idle_time", machine.idle_time);
                                command.Parameters.AddWithValue("@PLC_time", machine.PLC_time);
                                command.Parameters.AddWithValue("@wait_time", machine.wait_time);
                                command.Parameters.AddWithValue("@recipe_name", machine.recipe_name);
                                command.Parameters.AddWithValue("@status", machine.status);
                                command.Parameters.AddWithValue("@machine_type", machine.machine_type);
                                command.Parameters.AddWithValue("@cycle_time", machine.cycle_time);
                                machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                            }
                            foreach (var errinsert in errorInsertlist)
                            {
                                sb.Clear();
                                sb.Append("insert into utl_mac_error(data_id,error_code,codegrouping) values(@data_id,@error_code,@codegrouping)");
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    command.Parameters.Clear();
                                    command.Parameters.AddWithValue("@data_id", machinedata_id);
                                    command.Parameters.AddWithValue("@error_code", errinsert.error_code);
                                    command.Parameters.AddWithValue("@codegrouping", errinsert.codegrouping);
                                    int iVal = command.ExecuteNonQuery();
                                }
                            }
                        }
                        else
                        {                          
                            sb.Clear();
                            sb.Append("insert into utl_mac_det(machine_serial,speed,count,up_time,idle_time,PLC_time,wait_time,recipe_name,status,machine_type,date_time, time, time_recv,cycle_time) values(@machine_serial,@speed,@count,@up_time,@idle_time,@PLC_time, @wait_time,@recipe_name,@status,@machine_type,@date_time, @time, @time_recv,@cycle_time);");
                            sb.Append(" select last_insert_id() as sno");
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                command.Parameters.AddWithValue("@date_time", DateTime.Now);
                                if (latest_stored_recv_time == DateTime.MinValue)
                                {
                                    time = new TimeSpan(0, 0, 0, 0, 0);
                                }
                                else
                                {
                                    time = machine.data_received_time - latest_stored_recv_time;
                                }                              
                                int diff_time = Convert.ToInt32(time.TotalSeconds);
                                command.Parameters.AddWithValue("@time", diff_time);
                                command.Parameters.AddWithValue("@time_recv", machine.data_received_time);                              
                                command.Parameters.AddWithValue("@machine_serial", machine.machine_serial);
                                command.Parameters.AddWithValue("@speed", machine.speed);
                                command.Parameters.AddWithValue("@count", machine.count);
                                command.Parameters.AddWithValue("@up_time", machine.up_time);
                                command.Parameters.AddWithValue("@idle_time", machine.idle_time);
                                command.Parameters.AddWithValue("@PLC_time", machine.PLC_time);
                                command.Parameters.AddWithValue("@wait_time", machine.wait_time);
                                command.Parameters.AddWithValue("@recipe_name", machine.recipe_name);
                                command.Parameters.AddWithValue("@status", machine.status);
                                command.Parameters.AddWithValue("@machine_type", machine.machine_type);
                                command.Parameters.AddWithValue("@cycle_time", machine.cycle_time);
                                machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                            }
                        }
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        return BadRequest(ex.Message);
                    }
                }
               return Content("Added Successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public class Errorwithgrouping
        {
            public string Prev_errorcode { get; internal set; }
            public double Prev_codegrouping { get; internal set; }
        }
    }
}