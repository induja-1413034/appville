﻿using System;
using System.Diagnostics;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using System.Text;

namespace MaterialDashboard.Controllers
{
    public class HomeController : Controller
    {
        private appvilledbContext _context;
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]        
        public IActionResult Index([Bind("username,password,role")]LoginView LoginView)
        {
            try
            {
                _context = new appvilledbContext();            
                var user = _context.LoginTab.Where(x => x.Username == LoginView.username).FirstOrDefault();
                if (user != null)
                {
                    var PasswordHash = Convert.FromBase64String(user.PasswordHash_str);
                    var PasswordSalt = Convert.FromBase64String(user.PasswordSalt_str);

                    if (!VerifyPasswordHash(LoginView.password, PasswordHash, PasswordSalt))
                    {
                        ViewBag.Message = "Incorrect Password";
                        return View("Index");
                    }
                    else
                    {
                        var role = _context.LoginTab.Where(y => y.Username.Equals(LoginView.username)).Select(x => x.Role).FirstOrDefault();
                        var login_id = _context.LoginTab.Where(y => y.Username.Equals(LoginView.username)).Select(x => x.Id).FirstOrDefault();
                        HttpContext.Session.SetInt32("test", 23);
                        HttpContext.Session.GetInt32("test");
                        if (role.Equals("user"))
                        {
                            LoginView.login_id = login_id;
                            var val2 = LoginView.username;
                            HttpContext.Session.SetInt32("login_id", login_id);
                            Nullable<int> b = HttpContext.Session.GetInt32("login_id");
                            var cli_id = _context.LoginView.Where(x => x.username == val2).Select(x => x.cli_id).FirstOrDefault();
                            int val3 = Convert.ToInt32(cli_id);
                            HttpContext.Session.SetInt32("cli_id", val3);
                            Nullable<int> a = HttpContext.Session.GetInt32("cli_id");
                            return RedirectToAction("MachineLiveStatus", "MachineLiveStatus");
                        }                       
                        else
                            return RedirectToAction("CustomerList", "CustomerList");
                    }
                }
                else
                {
                    ViewBag.Message = "Incorrect Username";
                    return View("Index");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View("Index");
            }
        }

        private static bool VerifyPasswordHash(string password, byte[] storedHash, byte[] storedSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");
          

            using (var hmac = new System.Security.Cryptography.HMACSHA512(storedSalt))
            {
                var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password));
                for (int i = 0; i < computedHash.Length; i++)
                {
                    if (computedHash[i] != storedHash[i]) return false;
                }
            }
            return true;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
