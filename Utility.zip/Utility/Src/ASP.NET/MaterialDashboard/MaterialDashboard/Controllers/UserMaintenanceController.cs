﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MaterialDashboard.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Collections;

namespace MaterialDashboard.Controllers

{
    public class UserMaintenanceController : Controller
    {
        private appvilledbContext _context;
        public IActionResult AddMaintenance()
        {
            Nullable<int> cli_id = HttpContext.Session.GetInt32("cli_id");
            _context = new appvilledbContext();
              var val2 = _context.CliMacView.Where(y => y.cli_id == cli_id).Select(x => x.serial).ToList();
              ViewBag.CliMacView = val2;            
            return View();
        }
        
        [HttpPost]        
        public async Task<IActionResult> AddMaintenance([Bind("sno,date_time,machine_cycle,maintanance_type,cause,work_done,replaced_parts,tech_name,serial,video")] UtlMaintainenceDet UtlMaintainenceDet)
        {            
            {
                _context = new appvilledbContext();
                _context.Add(UtlMaintainenceDet);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(AddMaintenance));
            }            
        }
        public IActionResult ViewMaintenance()
        {
            _context = new appvilledbContext();
            Nullable<int> cli_id = HttpContext.Session.GetInt32("cli_id");            
            ViewBag.CliMacView = _context.CliMacView.Where(y => y.cli_id == cli_id).Select(x => x.serial).ToList();                                                       
            return View();
          
        }
      
        [HttpPost]
        //public IActionResult ViewMaintenance(int id,[Bind("serial")] UtlMaintainenceDet UtlMaintainenceDet)        
        public  IActionResult ViewMaintenance(string serial)
        {
            _context = new appvilledbContext();
            
            Nullable<int> cli_id = HttpContext.Session.GetInt32("cli_id");
            HttpContext.Session.SetInt32("cli_id", Convert.ToInt32(cli_id));
            ViewBag.CliMacView = _context.CliMacView.Where(y => y.cli_id == cli_id).Select(x => x.serial).ToList();
            UtlMaintainenceDet utl = new UtlMaintainenceDet();
            var seriallist = _context.UtlMaintainenceDet.Where(x => x.serial.Equals(serial)).ToList();
            return Ok(seriallist);            
        }


        public async Task<IActionResult> EditMaintenance(int id)
        {

            _context = new appvilledbContext();

            Nullable<int> cli_id = HttpContext.Session.GetInt32("cli_id");            
            ViewBag.CliMacView = _context.CliMacView.Where(y => y.cli_id == cli_id).Select(x => x.serial).ToList();

            ViewResult viewRes = View(await _context.UtlMaintainenceDet.ToListAsync());
            if (id.Equals(null))
            {
                return NotFound();
            }

            var details = await _context.UtlMaintainenceDet.FindAsync(id);
            if (details == null)
            {
                return NotFound();
            }
            return View(details);

        }
        [HttpPost]        
        public async Task<IActionResult> EditMaintenance(int id, [Bind("date_time,machine_cycle,maintanance_type,cause,work_done,replaced_parts,tech_name,serial,video")] UtlMaintainenceDet UtlMaintainenceDet)
        {
            _context = new appvilledbContext();
            var serial1 = UtlMaintainenceDet.serial;
            HttpContext.Session.SetString("serial", serial1);
            UtlMaintainenceDet.sno = id;            
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(UtlMaintainenceDet);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetailsExists(UtlMaintainenceDet.sno))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                //ViewBag.calljavascriptfunction = "FetchMacDetails();";

                return RedirectToAction(nameof(ViewMaintenance));
            }
            

            return View(UtlMaintainenceDet);
        }

        public async Task<IActionResult> Btn_Click(int id)
        {
            _context = new appvilledbContext();
            var details = await _context.UtlMaintainenceDet.FindAsync(id);
            _context.UtlMaintainenceDet.Remove(details);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ViewMaintenance));
        }


        public async Task<IActionResult> DeleteAll(string serial)
        {
            _context = new appvilledbContext();
            var details = await _context.UtlMaintainenceDet.Where(x=>x.serial.Equals(serial)).ToListAsync();
            _context.UtlMaintainenceDet.RemoveRange(details);
            await _context.SaveChangesAsync();
           // ViewBag.UtlMaintainenceDet = _context.UtlMaintainenceDet.Where(x => x.serial == serial).ToList();
            return RedirectToAction(nameof(ViewMaintenance));
        }
        private bool DetailsExists(object cliId)
        {
            throw new NotImplementedException();
        }
    }

}