﻿using System;
using System.Collections.Generic;
using System.Linq;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections;
using MySql.Data.MySqlClient;
using System.Data;
using System.Text;

namespace MaterialDashboard.Controllers
{
    public class RecipeBasedReportController : Controller
    {
        private appvilledbContext _context;
        public IConfiguration Configuration { get; }
        public RecipeBasedReportController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult RecipeBasedReport()
        {
            Nullable<int> cli_id = HttpContext.Session.GetInt32("cli_id");
            HttpContext.Session.SetInt32("cli_id", Convert.ToInt32(cli_id));
            _context = new appvilledbContext();
            var val2 = _context.CliMacView.Where(y => y.cli_id == cli_id).Select(x => x.serial).ToList();
            ViewBag.CliMacView = val2;
            return View();
        }
        [HttpPost]
        public IEnumerable RecipeBasedReport(string serial, string dt_val1, string dt_val2, string recipe_format)
        {
            DateTime From_date = Convert.ToDateTime(dt_val1);
            DateTime To_date = Convert.ToDateTime(dt_val2);
            List<int> final = new List<int>();
            List<recipe> recp = new List<recipe>();
            string prev_recipe = "-1";
            string recipe_name = "-1";
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand command = new MySqlCommand("create_recipe_table", conn))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new MySqlParameter("@dat_from", From_date));
                    command.Parameters.Add(new MySqlParameter("@dat_to", To_date));
                    command.Parameters.Add(new MySqlParameter("@mac_serial", serial));
                    command.Parameters.Add(new MySqlParameter("@recipe_format", recipe_format));
                    int iVal = command.ExecuteNonQuery();
                }
                StringBuilder sb = new StringBuilder();
                string sql = "";
                sb.Append("select * from temp_recipe_report_for_code");
                sql = sb.ToString();

                using (MySqlCommand command = new MySqlCommand(sql, conn))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var sno = reader.GetInt32(0);
                            recipe_name = reader.GetString(3);
                            if (recipe_name != prev_recipe)
                            {
                                final.Add(sno);
                            }
                            prev_recipe = recipe_name;
                        }

                    }
                }
                int[] finalarray = final.ToArray();
                int low_limit = 0;
                int upper_limit = 0;
                for (int i = 1; i < finalarray.Count(); i++)
                {
                    low_limit = finalarray[i - 1];
                    upper_limit = finalarray[i];
                    sb.Clear();
                    sb.Append(string.Format("update temp_recipe_report_for_code set group_num={0} where sno<{1} and sno>={2}", i, upper_limit, low_limit));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int iVal = command.ExecuteNonQuery();
                    }
                }
                var last_count = finalarray.Count();
                if (last_count != 0)
                {
                    low_limit = finalarray[(last_count - 1)];
                    sb.Clear();
                    sb.Append(string.Format("update temp_recipe_report_for_code set group_num={0} where sno>={1}", last_count, low_limit));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int iVal = command.ExecuteNonQuery();
                    }

                    sb.Clear();
                    sb.Append("SELECT cast(time_recv as datetime) as date,min(time_recv) as start_time, max(time_recv) as end_time, sum(time) as tot_time_in_seconds,recipe_name");
                    sb.Append(string.Format(" FROM temp_recipe_report_for_code group by group_num"));

                    sql = sb.ToString();

                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            recipe Recp = new recipe();
                            Recp.recipes = "all";
                            recp.Add(Recp);

                            while (reader.Read())
                            {
                                recipe rec = new recipe();
                                if (reader.GetString(4) != null)
                                {
                                    rec.recipes = reader.GetString(4) + "(" + (reader.GetDateTime(1)).ToString("yyyy-MM-dd HH:mm:ss") + "-" + (reader.GetDateTime(2)).ToString("yyyy-MM-dd HH:mm:ss") + ")";
                                    recp.Add(rec);
                                }
                            }
                        }
                    }
                }
            }
            return recp;
        }
        public class recipe
        {
            public string recipes;
        }
        private string ConvertTimetoReadableFormat(int time_val)
        {
            string hours = (time_val / 60).ToString().PadLeft(2, '0');
            string minutes = (time_val % 60).ToString().PadLeft(2, '0');
            var time_formatted = string.Format("{0}:{1}", hours, minutes);
            return time_formatted;
        }
        public JsonResult PieChart(string serial, string dt_val1, string dt_val2,string recipe)
        {
            _context = new appvilledbContext();
            DateTime From_date = Convert.ToDateTime(dt_val1);
            DateTime To_date = Convert.ToDateTime(dt_val2);
            DateTime myDateTime = From_date;
            var viewres1 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).OrderBy(y => y.time_recv).FirstOrDefault();
            var viewres2 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).OrderByDescending(y => y.time_recv).FirstOrDefault();
            int idle_time = 0;
            int up_time = 0;
            int wait_time = 0;
            int prod_count = 0;
            var viewres3 = 0;
            var error_time = 0;
            var error_time1 = 0;
            var stop_time = 0;
            var stop_time_abs = 0;
            var up_time_abs = 0;
            var stop_time_formatted = "";
            var up_time_formatted = "";
            var wait_time_formatted = "";
            var error_time_formatted = "";


            if (viewres1 == null || viewres2 == null)
            {
                ViewBag.Message = "No Data";
            }
            else
            {
                idle_time = Convert.ToInt32(viewres2.idle_time) - Convert.ToInt32(viewres1.idle_time);
                up_time = Convert.ToInt32(viewres2.up_time) - Convert.ToInt32(viewres1.up_time);
                wait_time = Convert.ToInt32(viewres2.wait_time) - Convert.ToInt32(viewres1.wait_time);
                prod_count = Convert.ToInt32(viewres2.count) - Convert.ToInt32(viewres1.count);
                viewres3 = _context.UtlMacDet.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial) && y.status.Equals("4") && y.time< 1000).Sum(y => y.time);
                error_time = viewres3 / 60;
                error_time1 = Convert.ToInt32(viewres3);
                stop_time = Convert.ToInt32(idle_time) - Convert.ToInt32(error_time);
                stop_time_abs = Math.Abs(stop_time);
                up_time_abs = Math.Abs(up_time);

                stop_time_formatted = "stop: " + ConvertTimetoReadableFormat(stop_time_abs);
                up_time_formatted = "up: " + ConvertTimetoReadableFormat(up_time_abs);
                wait_time_formatted = "wait: " + ConvertTimetoReadableFormat(wait_time);
                error_time_formatted = "error: " + ConvertTimetoReadableFormat(error_time);
            }           
            return Json(new[] { new
            {
                idle_time = idle_time,
                error_time = error_time,
                stop_time = stop_time_abs,
                up_time = up_time_abs,
                wait_time = wait_time,
                prod_count = prod_count,
                error_time1 = error_time,
                up_time_formatted = up_time_formatted,
                wait_time_formatted = wait_time_formatted,
                error_time_formatted = error_time_formatted,
                stop_time_formatted = stop_time_formatted

            }});
        }

        [HttpPost]
        public IEnumerable Load_Table(string serial, string dt_val1, string dt_val2)
        {
            _context = new appvilledbContext();
            DateTime From_date = Convert.ToDateTime(dt_val1);
            DateTime To_date = Convert.ToDateTime(dt_val2);
            var sells = _context.UtlErrForGraph
                .Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial) && y.time < 1000)
     .GroupBy(a => new { a.error_code, a.error_details })
     .Select(a => new { errorcode = a.Key.error_code, total_time = a.Sum(b => b.time), err_des = a.Key.error_details })
     .OrderByDescending(a => a.total_time)
     .ToList();
            int count = sells.Count;
            string[] total_time = new string[count];
            for (int t = 0; t < sells.Count; t++)
            {
                string hours = Convert.ToString(TimeSpan.FromSeconds(sells[t].total_time / 3600));
                string minutes = Convert.ToString(TimeSpan.FromSeconds((sells[t].total_time / 60) % 60));
                string seconds = Convert.ToString(TimeSpan.FromSeconds(sells[t].total_time % 60));
                string[] hoursformat = hours.Split(":");
                string[] minutesformat = minutes.Split(":");
                string[] secondsformat = seconds.Split(":");
                total_time[t] = hoursformat[2] + ":" + minutesformat[2] + ":" + secondsformat[2];
            }
            return sells;
        }
        public IEnumerable Load_Combine_Table(string serial, string dt_val1, string dt_val2)
        {
            _context = new appvilledbContext();
            List<returnforjson> returnforjsons = new List<returnforjson>();
            returnforjson returnforjson = null;
            DateTime From_date = Convert.ToDateTime(dt_val1);
            DateTime To_date = Convert.ToDateTime(dt_val2);
            DateTime myDateTime = From_date;
            var table = _context.UtilityErrView.Where(y => y.time_recv > From_date && y.time_recv <= To_date && y.machine_serial.Equals(serial)).OrderBy(a => a.time_recv).ToList();
            string prev_err_code = "";
            string prev_err_desc = "";
            DateTime start_time = DateTime.MinValue;
            DateTime end_time = DateTime.MinValue;
            int count = table.Count;
            string[] range = new string[count];
            string[] error_code = new string[count];
            string[] error_desc = new string[count];
            for (int i = 0; i < table.Count; i++)
            {
                var loc_err_code = Convert.ToString(table[i].err_concat);
                var loc_err_des = Convert.ToString(table[i].error_details);
                if (prev_err_code.Equals(loc_err_code))
                {
                    end_time = table[i].time_recv;
                }
                else
                {
                    if (start_time != DateTime.MinValue)
                    {
                        string start_time_alone = start_time.ToString("HH:mm");
                        string end_time_alone = end_time.ToString("HH:mm");
                        string time_range = string.Format("{0} - {1}", start_time_alone, end_time_alone);
                        if (time_range != null && loc_err_code != null && loc_err_des != null)
                        {
                            range[i] = time_range;
                            error_code[i] = loc_err_code;
                            error_desc[i] = loc_err_des;
                        }
                    }
                    start_time = table[i].time_recv;
                    end_time = table[i].time_recv;
                    prev_err_code = loc_err_code;
                    prev_err_desc = loc_err_des;
                }
            }
            var range1 = range.ToList();
            var range2 = range1.Where(x => x != null).ToList();
            List<string> error_code1 = error_code.ToList();
            List<string> error_code2 = error_code.ToList();
            List<string> error_desc1 = error_desc.ToList();
            List<string> error_desc2 = error_desc1.ToList();
            if (error_code1.Count() == 0 && error_desc1.Count() == 0)
            {
                ViewBag.Message = "No Data";
            }
            else
            {
                error_code1.Insert(0, table[0].err_concat);
                error_code2 = error_code1.Where(x => x != null).ToList();
                
                error_desc1.Insert(0, table[0].error_details);
                error_desc2 = error_desc1.Where(x => x != null).ToList();

                for (int i = 0; i < range2.Count; i++)
                {
                    returnforjson = new returnforjson();
                    returnforjson.time_range = range2[i];
                    returnforjson.Err_code = error_code2[i];
                    returnforjson.Err_des = error_desc2[i];
                    returnforjsons.Add(returnforjson);
                }
            }
            return returnforjsons;
        }
        public class returnforjson
        {
            public string time_range;
            public string Err_code;
            public string Err_des;
        }
        public IEnumerable Load_detail_Table(string serial, string dt_val1, string dt_val2, string err_code)
        {

            int prev_err = -1;
            int error_code = -1;
            List<int> final = new List<int>();
            List<timereport> timelist = new List<timereport>();
            DateTime From_date = Convert.ToDateTime(dt_val1);
            DateTime To_date = Convert.ToDateTime(dt_val2);
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand command = new MySqlCommand("create_err_table", conn))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new MySqlParameter("@dat_from", From_date));
                    command.Parameters.Add(new MySqlParameter("@dat_to", To_date));
                    command.Parameters.Add(new MySqlParameter("@err_code", err_code));
                    command.Parameters.Add(new MySqlParameter("@mac_serial", serial));
                    int iVal = command.ExecuteNonQuery();
                }
                StringBuilder sb = new StringBuilder();
                string sql = "";
                sb.Append("select * from temp_error_report_for_code");
                sql = sb.ToString();
                using (MySqlCommand command = new MySqlCommand(sql, conn))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int sno = reader.GetInt32(0);
                            if (reader["error_code"] != DBNull.Value)
                            {
                                error_code = reader.GetInt32(3);
                            }
                            else
                            {
                                error_code = 0;
                            }
                            if (error_code != prev_err)
                            {
                                final.Add(sno);
                            }
                            prev_err = error_code;
                        }
                    }
                }

                int[] finalarray = final.ToArray();
                int low_limit = 0;
                int upper_limit = 0;
                for (int i = 1; i < finalarray.Count(); i++)
                {
                    low_limit = finalarray[i - 1];
                    upper_limit = finalarray[i];
                    sb.Clear();
                    sb.Append(string.Format("update temp_error_report_for_code set group_num={0} where sno<{1} and sno>={2}", i, upper_limit, low_limit));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int iVal = command.ExecuteNonQuery();
                    }
                }
                var last_count = finalarray.Count();
                low_limit = finalarray[(last_count - 1)];
                sb.Clear();
                sb.Append(string.Format("update temp_error_report_for_code set group_num={0} where sno>={1}", last_count, low_limit));
                sql = sb.ToString();
                using (MySqlCommand command = new MySqlCommand(sql, conn))
                {
                    int iVal = command.ExecuteNonQuery();
                }

                sb.Clear();
                sb.Append("SELECT cast(time_recv as date) as date,min(cast(time_recv as time)) as start_time, max(cast(time_recv as time)) as end_time, sum(time) as tot_time_in_seconds,error_details,error_code");
                sb.Append(string.Format(" FROM temp_error_report_for_code where error_code = {0}  group by group_num", err_code));
                sql = sb.ToString();
                using (MySqlCommand command = new MySqlCommand(sql, conn))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            timereport time = new timereport();
                            time.date = reader.GetDateTime(0);
                            time.start_time = reader.GetTimeSpan(1);
                            time.end_time = reader.GetTimeSpan(2);
                            var tot_time_in_seconds = reader.GetInt32(3);
                            if (tot_time_in_seconds == '0')
                            {
                                timelist.Add(time);
                                continue;
                            }
                            time.Total_time = TimeSpan.FromSeconds(tot_time_in_seconds);
                            timelist.Add(time);
                        }
                    }
                }
                return timelist;

            }

        }
        public class timereport
        {
            public DateTime date;
            public TimeSpan start_time;
            public TimeSpan end_time;
            public TimeSpan Total_time;
        }


    }
}