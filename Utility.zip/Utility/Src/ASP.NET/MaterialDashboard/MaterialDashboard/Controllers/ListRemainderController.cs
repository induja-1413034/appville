﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MaterialDashboard.Controllers
{
    public class ListRemainderController : Controller
    {
        private appvilledbContext _context;       
        public async Task<IActionResult> ListRemainder(uint id)
        {
            int mod_id = (int)id;
            _context = new appvilledbContext();
            List<UtlModelRemView> list = await _context.UtlModelRemView.ToListAsync();  
            ViewResult details = View(list.OrderBy(s => s.base_threshold).Where(x => x.model_id == mod_id).ToList());
            Nullable<int> session = HttpContext.Session.GetInt32("test");            
            if (session == 23)
                return details;
            else
                return RedirectToAction("Index", "Home");
        }
        public IActionResult AddRemainder(int id)
        {
            _context = new appvilledbContext();
            ViewBag.RemModel = _context.RemModel.Where(x => x.model_id == Convert.ToUInt32(id)).ToList();
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return View();
            else
                return RedirectToAction("Index", "Home");
        }

        [HttpPost]        
        public async Task<IActionResult> AddRemainder(int id, [Bind("model_id,name,base_threshold,remainder_title,details,video")] RemModelRem RemModelRem)
        {           
            {
                _context = new appvilledbContext();
                RemModelRem.model_id = id;
                _context.Add(RemModelRem);
                await _context.SaveChangesAsync();
                return RedirectToAction("ListRemainder", "ListRemainder", new { id });
            }
        }

        public async Task<IActionResult> EditRemainder(uint Id,uint Id1)
        {
            _context = new appvilledbContext();
            ViewBag.RemModel = _context.RemModel.ToList();
            if (Id1.Equals(null))
            {
                return NotFound();
            }
            var details = await _context.RemModelRem.FindAsync(Id);
            if (details == null)
            {
                return NotFound();
            }
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return View(details);
            else
                return RedirectToAction("Index", "Home");
        }
        
        [HttpPost]        
        public async Task<IActionResult> EditRemainder(int Id, int Id1,[Bind("model_id,rem_id,name,base_threshold,remainder_title,details,video")] RemModelRem RemModelRem)
        {
            _context = new appvilledbContext();
            RemModelRem.rem_id = Convert.ToUInt32(Id);
            if (Id1.Equals(RemModelRem.rem_id))
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(RemModelRem);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetailsExists(RemModelRem.model_id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                Id = RemModelRem.model_id;
                return RedirectToAction("ListRemainder", "ListRemainder", new { Id });
            }
            return View(RemModelRem);
        }

        private bool DetailsExists(int model_id)
        {
            throw new NotImplementedException();
        }

        public async Task<IActionResult> Btn_Click(uint id, int model_id)
        {
            _context = new appvilledbContext();
            uint temp = Convert.ToUInt16(id);
            var details = await _context.RemModelRem.FindAsync(temp);
            _context.RemModelRem.Remove(details);
            await _context.SaveChangesAsync();
            id = Convert.ToUInt32(model_id);
            return RedirectToAction("ListRemainder", "ListRemainder", new { id });
        }
        
    }
}