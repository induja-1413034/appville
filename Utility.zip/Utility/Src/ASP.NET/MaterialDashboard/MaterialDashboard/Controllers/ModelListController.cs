﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace MaterialDashboard.Controllers
{
    public class ModelListController : Controller
    {
        private readonly IHostingEnvironment _environment;
        public IConfiguration Configuration { get; }      

        public ModelListController(IConfiguration configuration,IHostingEnvironment hostingEnvironment)
        {
            _environment = hostingEnvironment;
            Configuration = configuration;
        }
        private appvilledbContext _context;
        
        public async Task<IActionResult> ModelList()
        {
            _context = new appvilledbContext(); 
            ViewResult viewRes = View(await _context.RemModel.ToListAsync());
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return viewRes;
            else
                return RedirectToAction("Index", "Home");
        }

        public IActionResult AddModel()
        {
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return View();
            else
                return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public async Task<IActionResult> AddModel([Bind("model_id,name,remark")]RemModel RemModel, IFormFile fileSelect)
        {
            try
            {
                _context = new appvilledbContext();
                var file = fileSelect;
                RemModel.Image_to_upload_path = UploadFileToBlob(file);
                _context.Add(RemModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(ModelList));
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public string UploadFileToBlob(IFormFile file)
        {
            try
            {
                var _task = Task.Run(() => this.UploadFileToBlobAsync(file));
                _task.Wait();
                string fileUrl = _task.Result;
                return fileUrl;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private async Task<string> UploadFileToBlobAsync(IFormFile file)
        {
            try
            {
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "uploads";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                string fileName = this.GenerateFileName(file.FileName);

                if (await cloudBlobContainer.CreateIfNotExistsAsync())
                {
                    await cloudBlobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
                }
                if (fileName != null)
                {
                    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);                    
                    cloudBlockBlob.Properties.ContentType = file.ContentType;                 
                    await cloudBlockBlob.UploadFromStreamAsync(file.OpenReadStream());                  
                    return cloudBlockBlob.Uri.AbsoluteUri;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private string GenerateFileName(string fileName)
        {
            string strFileName = string.Empty;
            string[] strName = fileName.Split('.');
            strFileName = DateTime.Now.ToUniversalTime().ToString("yyyy-MM-dd")+"/"+DateTime.Now.ToUniversalTime().ToString("yyyyMMdd\\THHmmssfff") + "." + strName[strName.Length - 1];
            return strFileName;
        }
       

        public async Task<IActionResult> EditModel(uint id)
        {
            try
            {
                _context = new appvilledbContext();
                if (id.Equals(null))
                {
                    return NotFound();
                }

                var details = await _context.RemModel.FindAsync(id);
                if (details == null)
                {
                    return NotFound();
                }
                Nullable<int> session = HttpContext.Session.GetInt32("test");
                if (session == 23)
                    return View(details);
                else
                    return RedirectToAction("Index", "Home");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        [HttpPost]        
        public async Task<IActionResult> EditModel(string id, [Bind("model_id,name,remark,Image_to_upload_path")]RemModel RemModel, IFormFile fileSelect)
        {
            _context = new appvilledbContext();
            if (id.Equals(RemModel.model_id))
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    DeleteBlobData(RemModel.Image_to_upload_path);
                    RemModel.Image_to_upload_path = UploadFileToBlob(fileSelect); 
                    _context.Update(RemModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!DetailsExists(RemModel.model_id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        return BadRequest(ex.Message);
                    }
                }
                return RedirectToAction(nameof(ModelList));
            }
            return View(RemModel);
        }

        private bool DetailsExists(uint model_id)
        {
            throw new NotImplementedException();
        }

        public async Task<IActionResult> Btn_Click(string id)
        {
            try
            {
                _context = new appvilledbContext();
                uint temp = Convert.ToUInt16(id);
                var details = await _context.RemModel.FindAsync(temp);              
                DeleteBlobData(details.Image_to_upload_path);
                _context.RemModel.Remove(details);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(ModelList));
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public async void DeleteBlobData(string fileUrl)
        {
            try
            {
                Uri uriObj = new Uri(fileUrl);
                string BlobName = Path.GetFileName(uriObj.LocalPath);
                string[] path2 = uriObj.Segments;
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "uploads";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                CloudBlobDirectory folder = cloudBlobContainer.GetDirectoryReference("directoryName");

                string pathPrefix = path2[2];
                CloudBlobDirectory blobDirectory = cloudBlobContainer.GetDirectoryReference(pathPrefix);              
                CloudBlockBlob blockBlob = blobDirectory.GetBlockBlobReference(BlobName);                     
                await blockBlob.DeleteAsync();
            }
            catch(Exception ex)
            {
                BadRequest(ex.Message);
            }
        }

        public async Task<IActionResult> ListRemainder(uint id)
        {
            try
            {
                _context = new appvilledbContext();
                int temp = (int)id;
                List<UtlModelRemView> RemModel = await _context.UtlModelRemView.ToListAsync();
                ViewResult details = View(RemModel.Where(x => x.rem_id == temp).ToList());
                return details;
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}