﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MaterialDashboard.Controllers
{
    public class PurchaseDetailsController : Controller
    {
        private appvilledbContext _context;
        public async Task<IActionResult> PurchaseDetails_old(uint id)
        {
            _context = new appvilledbContext();
            List<cli_purchase_details_view> purchaseList = await _context.cli_purchase_details_view.ToListAsync();
            ViewResult details = View(purchaseList.Where(x => x.cli_id == Convert.ToInt32(id)).ToList());
            return details;
        }

        public IActionResult PurchaseDetails(uint id)
        {            
            _context = new appvilledbContext();
            HttpContext.Session.SetInt32("cli_id", Convert.ToInt32(id));
            ViewResult purchaseList = View((from cli in _context.RemCliDet
                                            join cli_mac in _context.RemCliMac on cli.CliId equals cli_mac.cli_id
                                            join mac_mod in _context.RemMacDet on cli_mac.mac_id equals mac_mod.mac_id
                                            join modl in _context.RemModel on mac_mod.model_id equals modl.model_id
                                            join login in _context.LoginTab on mac_mod.login_id equals login.Id
                                            where cli.CliId == id
                                            select new cli_purchase_details_view()
                                            {
                                                cli_id = (int)cli_mac.cli_id,
                                                user_phone = login.Phone,
                                                mac_id = cli_mac.mac_id,
                                                name = cli.Name,
                                                serial = mac_mod.serial,
                                                purchase_dt = (mac_mod.purchase_dt).Substring(0,10),
                                                site_location = mac_mod.site_location,
                                                user_address = login.Address,
                                                user_mail = login.Mail,
                                                username = login.Username,
                                                model = modl.name,
                                            }).ToList());
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return purchaseList;
            else
                return RedirectToAction("Index", "Home");
        }

        public IActionResult AddPurchase(int id)
        {
            _context = new appvilledbContext();           
            ViewBag.RemModel = _context.RemModel.ToList();
            var temp = _context.LoginTab.Where(x => x.cli_id == Convert.ToUInt32(id)).ToList();           
            ViewBag.LoginTab = _context.LoginTab.Where(x => x.cli_id == Convert.ToUInt32(id)).ToList();
         
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23 && temp.Count == 0)
            {
                ViewBag.Message = "Please Add a User before Adding a Purchase Details";
                return View();
            }
            else if (session == 23)
                return View();
            else
                return RedirectToAction("Index", "Home");
        }
        [HttpPost]        
        public async Task<IActionResult> AddPurchase(int id, [Bind("mac_id,model_id,purchase_dt,serial,site_location,cli_id,login_id,operator_name,mail_id,phone_number,address,mac_id")] RemMacDet RemMacDet )
        {          
            {
                 _context = new appvilledbContext();
                ViewBag.LoginTab = _context.LoginTab.Where(x => x.Id == Convert.ToUInt32(RemMacDet.login_id)).ToList();              
                _context.Add(RemMacDet);
                await _context.SaveChangesAsync();
                RemCliMac rem = new RemCliMac();
                rem.cli_id = Convert.ToUInt32(id);
                rem.mac_id = RemMacDet.mac_id;
                _context.Add(rem);
                await _context.SaveChangesAsync();
                
                ErrorWithModelId err = new ErrorWithModelId();
                List<UtlErrorInfo> a = new List<UtlErrorInfo>();
                
                 var ab = _context.ErrorWithModelId.Where(x => x.model_id == RemMacDet.model_id).OrderBy(x=>x.error_code).ToList();

                var errorlist= ab.Select(x => new UtlErrorInfo { error_code = x.error_code, error_details = x.error_description, is_error = x.is_error, machine_serial = RemMacDet.serial }).OrderBy(z=>z.error_code).ToList();
                _context.UtlErrorInfo.AddRange(errorlist);
                await _context.SaveChangesAsync();
                return RedirectToAction("PurchaseDetails", "PurchaseDetails", new { id });
            }
        }
        public async Task<IActionResult> EditPurchase(uint id,uint mac_id, string serial)
        {
            _context = new appvilledbContext();
            ViewBag.RemModel = _context.RemModel.ToList();
            ViewBag.LoginTab = _context.LoginTab.Where(x => x.cli_id == Convert.ToUInt32(id)).ToList();          
            ViewBag.RemCliDet = _context.RemCliDet.Where(x => x.CliId == id).ToList();
            if (id.Equals(null))
            {
                return NotFound();
            }            
            var details = await _context.RemMacDet.FindAsync(mac_id);
            if (details == null)
            {
                return NotFound();
            }
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return View(details);
            else
                return RedirectToAction("Index", "Home");
        }

        [HttpPost]        
        public async Task<IActionResult> EditPurchase(uint id, uint mac_id, [Bind("serial,purchase_dt,site_location,model_id,login_id,mac_id,cli_id")] RemMacDet RemMacDet)
        {
            _context = new appvilledbContext();
            if (id.Equals(RemMacDet.mac_id))
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(RemMacDet);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DetailsExists(RemMacDet.mac_id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("PurchaseDetails", "PurchaseDetails", new { id });
            }
            return View(RemMacDet);
        }

        private bool DetailsExists(object id)
        {
            throw new NotImplementedException();
        }
        public async Task<IActionResult> Btn_Click(uint id, uint mac_id, string serial)
        {
            _context = new appvilledbContext();
            var error = await _context.UtlErrorInfo.Where(x => x.machine_serial.Equals(serial)).ToListAsync();
            _context.UtlErrorInfo.RemoveRange(error);
            var details1 = await _context.RemCliMac.FindAsync(mac_id);
            _context.RemCliMac.Remove(details1);
            await _context.SaveChangesAsync();
            var details = await _context.RemMacDet.FindAsync(mac_id);
            _context.RemMacDet.Remove(details);
            await _context.SaveChangesAsync();
            return RedirectToAction("PurchaseDetails", "PurchaseDetails", new { id });
        }        
    }
}
