﻿using System;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MaterialDashboard.Controllers
{
    public class ChangePasswordController : Controller
    {
        private appvilledbContext _context;
        public IActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ChangePassword(string old, string new_pw, string reenter, [Bind("username,password")] LoginTab LoginTab)
        {
            _context = new appvilledbContext();
            Nullable<int> b = HttpContext.Session.GetInt32("login_id");
            if (b.Equals(LoginTab.Id))
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    LoginTab login = new LoginTab();
                   login = _context.LoginTab.Where(x => x.Password.Equals(old) && x.Id.Equals(b)).FirstOrDefault();
                    login.Password = new_pw;
                    await _context.SaveChangesAsync();
                }
                catch (InvalidOperationException)
                {
                    if (!DetailsExists(LoginTab.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("ChangePassword", "ChangePassword");
            }
            return RedirectToAction("", "");
        }

        private bool DetailsExists(int id)
        {
            throw new NotImplementedException();
        }
    }        
    }
