﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MaterialDashboard.Controllers
{
    public class flotchartController : Controller
    {
        public IActionResult flotchart()
        {
            return View();
        }
    }
}