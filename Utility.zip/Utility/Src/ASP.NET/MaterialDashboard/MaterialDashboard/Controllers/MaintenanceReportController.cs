﻿using System;
using System.Collections.Generic;
using System.Linq;
using MaterialDashboard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MaterialDashboard.Controllers
{
    public class MaintenanceReportController : Controller
    {
        private appvilledbContext _context;        
        public IActionResult MaintenanceReport()
        {
            _context = new appvilledbContext();
            ViewResult Maintenance = View((from mac_rem in _context.UtlMaintainenceDet
                                            join mac_det in _context.RemMacDet on mac_rem.serial equals mac_det.serial
                                            join cli_mac in _context.RemCliMac on mac_det.mac_id equals cli_mac.mac_id
                                            join cli_det in _context.RemCliDet on cli_mac.cli_id equals cli_det.CliId                                            
                                            orderby mac_rem.date_time
                                            select new SentRemaindersView()
                                            {
                                               client_name = cli_det.Name,
                                                serial = mac_rem.serial,
                                                sent_dates = Convert.ToDateTime(mac_rem.date_time),
                                                machine_cycle = mac_rem.machine_cycle,
                                                maintanance_type = mac_rem.maintanance_type,
                                                work_done = mac_rem.work_done,
                                                cause = mac_rem.tech_name,
                                                tech_name = mac_rem.tech_name,
                                                replaced_parts = mac_rem.replaced_parts,
                                            }).ToList());
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return Maintenance;
            else
                return RedirectToAction("Index", "Home");
        }
    }
}