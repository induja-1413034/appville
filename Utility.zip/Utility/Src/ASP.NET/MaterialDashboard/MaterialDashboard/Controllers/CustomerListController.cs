﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MaterialDashboard.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;

namespace MaterialDashboard.Controllers
{
    
    public class CustomerListController : Controller
    {
        private appvilledbContext _context;
        public async Task<IActionResult> CustomerList()
        {            
            _context = new appvilledbContext();
           
                ViewResult viewRes = View(await _context.RemCliDet.ToListAsync());
                Nullable<int> session = HttpContext.Session.GetInt32("test");
                if (session == 23)
                    return viewRes;
                else
                    return RedirectToAction("Index", "Home");
         
        }

        public  IActionResult AddCustomer()
        {
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return View();
            else
                return RedirectToAction("Index", "Home");
        }
        
        [HttpPost]        
        public async Task<IActionResult> AddCustomer([Bind("CliId,Name,Mail,Address,Phone")] RemCliDet RemCliDet)
        {        
            {
                _context = new appvilledbContext();
                _context.Add(RemCliDet);
                await _context.SaveChangesAsync();                
                return RedirectToAction("CustomerList", "CustomerList");
            }            
        }

        public async Task<IActionResult> Edit(uint id)
          {

            _context = new appvilledbContext();            
            if (id.Equals(null))
            {
                return NotFound();
            }

            var details = await _context.RemCliDet.FindAsync(id);
            if (details == null)
            {
                return NotFound();
            }
            Nullable<int> session = HttpContext.Session.GetInt32("test");
            if (session == 23)
                return View(details);
            else
                return RedirectToAction("Index", "Home");

        }
        
          [HttpPost]          
          public async Task<IActionResult> Edit(string id, [Bind("CliId,Name,Address,Mail,Phone")] RemCliDet RemCliDet)
          {
            _context = new appvilledbContext();
            if (id.Equals(RemCliDet.CliId))
              {
                  return NotFound();
              }

              if (ModelState.IsValid)
              {
                  try
                  {
                      _context.Update(RemCliDet);
                      await _context.SaveChangesAsync();
                  }
                  catch (DbUpdateConcurrencyException)
                  {
                      if (!DetailsExists(RemCliDet.CliId))
                      {
                          return NotFound();
                      }
                      else
                      {
                          throw;
                      }
                  }
                  return RedirectToAction(nameof(CustomerList));
              }
              return View(RemCliDet);
          }
        
        private bool DetailsExists(uint cliId)
        {
            throw new NotImplementedException();            
        }
        public async Task<IActionResult> Btn_Click(string id)
        {
            _context = new appvilledbContext();
            uint temp = Convert.ToUInt32(id);
            var details = await _context.RemCliDet.FindAsync(temp);
            _context.RemCliDet.Remove(details);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(CustomerList));
        }

    }
    
}

