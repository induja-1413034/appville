﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace MaterialDashboard.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }
    }
}