{
	"to":"d5WnS-QusFg:APA91bEIgRkdGLHX7mLqXwdDK8r3dpnAqnfrxDMCrwFbtmPTtjW0KX_rFy4nHKkemu_1NTIjLn5KIClJWU3gugQ6p5MDSYVA4mSF4RIrZoDNj-2qqeyD-Q6KV8v9OLCIZnU-kYTkzrF5",
	"notification":{
		"title":"hello",
		"body":"world"
	}
}

http://www.javascriptobfuscator.com/Javascript-Obfuscator.aspx

import json
import requests
import urllib.parse
from datetime import datetime, timedelta
import datetime
import time
try:
    Machine_details="{'PLC_time': '2019-04-04 15:22:58', 'StoppingAlarm': 0, 'up_time': '2', 'machine_serial': '6080', 'wait_time': '2', 'count': 22, 'machine_type': 5, 'speed': 0, 'error': '6,7', 'recipe_name': '5', 'data_received_time': '2019-04-04 15:22:58', 'status': '4', 'idle_time': '44'}"
    post_req = Machine_details
    utility_url = "http://104.214.35.170/InsertData/Create/?Machine_details="+ urllib.parse.quote(Machine_details)
    #posting the data to the database for every 15 seconds
    utility_req = requests.post(url=utility_url)
    print(utility_req.text)
except Exception as ex:
    print('error:-', ex)


https://www.onlinegdb.com/online_python_compiler