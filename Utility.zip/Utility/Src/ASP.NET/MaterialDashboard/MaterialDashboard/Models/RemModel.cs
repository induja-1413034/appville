﻿using Microsoft.AspNetCore.Http;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class RemModel
    {
        public uint model_id { get; set; }
        public string name { get; set; }
        public string remark { get; set; }
        public IFormFile Image_to_upload { get; set; }
        public string Image_to_upload_path { get; set; }
    }

}