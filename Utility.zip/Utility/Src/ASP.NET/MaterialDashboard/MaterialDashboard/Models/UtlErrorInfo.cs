﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public partial class UtlErrorInfo
    {
        public int error_code { get; set; }
        public string error_details { get; set; }
        public bool is_error { get; set; }
        public int _id { get; set; }
        public string machine_serial { get; set; }
    }
}
