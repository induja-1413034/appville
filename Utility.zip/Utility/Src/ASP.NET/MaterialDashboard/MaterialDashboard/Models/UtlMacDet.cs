﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class UtlMacDet
    {
        public int sno { get; set; }      
        //public DateTime data_received_time { get; set; }
        //public string error{get;set;}
        public string machine_serial { get; set; }
        public string speed { get; set; }
        public double count { get; set; }
        public string up_time { get; set; }
        public string idle_time { get; set; }
        public DateTime PLC_time { get; set; }
        public string wait_time { get; set; }
        public string recipe_name { get; set; }        
        public int? is_fault { get; set; }
        public string status { get; set; }
        public string machine_type { get; set; }
        public int time { get; set; }
        public DateTime time_recv { get; set; }
        public double cycle_time { get; set; }

    }
}
