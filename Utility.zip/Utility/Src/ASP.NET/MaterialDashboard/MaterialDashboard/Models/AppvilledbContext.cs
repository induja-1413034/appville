﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MaterialDashboard.Models
{
    public partial class appvilledbContext : DbContext
    {
        public appvilledbContext()
        {
        }

        public appvilledbContext(DbContextOptions<appvilledbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LoginTab> LoginTab { get; set; }
        public virtual DbSet<RemCliDet> RemCliDet { get; set; }
        public virtual DbSet<RemCliMac> RemCliMac { get; set; }
        public virtual DbSet<RemMacDet> RemMacDet { get; set; }
        public virtual DbSet<SentRemaindersView> SentRemaindersView { get; set; }
        public virtual DbSet<RemModel> RemModel { get; set; }
        public virtual DbSet<UtlModelRemView> UtlModelRemView { get; set; }
        public virtual DbSet<cli_purchase_details_view> cli_purchase_details_view { get; set; }
        public virtual DbSet<RemModelRem> RemModelRem { get; set; }
        public virtual DbSet<UtlMaintainenceDet> UtlMaintainenceDet { get; set; }
        public virtual DbSet<UtlErrorInfo> UtlErrorInfo { get; set; }
        public virtual DbSet<LoginView> LoginView { get; set; }
        public virtual DbSet<CliMacView> CliMacView { get; set; }        
        public virtual DbSet<UtilityErrView> UtilityErrView { get; set; }
        public virtual DbSet<UtlErrForGraph> UtlErrForGraph { get; set; }
        public virtual DbSet<UtlMacDet> UtlMacDet { get; set; }
        public virtual DbSet<UtlMacError> UtlMacError { get; set; }
        public virtual DbSet<UtlData> UtlData { get; set; }
        public virtual DbSet<ErrorWithModelId> ErrorWithModelId { get; set; }
        public virtual DbSet<MacDetailsErrorView> MacDetailsErrorView { get; set; }

        // Unable to generate entity type for table 'rem_mac_det'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                // optionsBuilder.UseMySql("Server=appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com;Database=appvilledb;user=appville_user;pwd=Appvilleiot1;Convert Zero Datetime=True;");
                optionsBuilder.UseMySql("Server=braiding-new.mysql.database.azure.com;Port=3306;Database=utility;Uid=braidinguser@braiding-new;Pwd=123Appville!;Convert Zero Datetime=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RemModel>().Ignore(c => c.Image_to_upload);
            modelBuilder.Entity<LoginTab>().Ignore(c => c.Password);
            modelBuilder.Entity<LoginView>().Ignore(c => c.password);
            modelBuilder.Entity<LoginTab>(entity =>
            {
                entity.ToTable("login_tab");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("int(11)");
                
                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Mail)
                    .HasColumnName("mail")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.PasswordHash_str)
                    .HasColumnName("PasswordHash_str")
                    .HasColumnType("varchar(1000)");

                entity.Property(e => e.PasswordSalt_str)
                   .HasColumnName("PasswordSalt_str")
                   .HasColumnType("varchar(1000)");

                entity.Property(e => e.Phone)
                    .HasColumnName("phone")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Role)
                    .HasColumnName("role")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.cli_id)
                    .HasColumnName("cli_id")
                    .HasColumnType("uint(10)");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasColumnType("varchar(45)");
            });

            modelBuilder.Entity<RemCliDet>(entity =>
            {
                entity.HasKey(e => e.CliId);

                entity.ToTable("rem_cli_det");

                entity.Property(e => e.CliId)                
                    .HasColumnName("cli_id")
                    .HasColumnType("uint(10)");  

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Mail)
                    .HasColumnName("mail")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Phone)
                    .HasColumnName("phone")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasColumnType("varchar(45)");
            });

            modelBuilder.Entity<RemCliMac>(entity =>
            {
                entity.HasKey(e => e.mac_id);

                entity.ToTable("rem_cli_mac");

                entity.Property(e => e.Sno)
                    .HasColumnName("sno")
                    .HasColumnType("int(11)");

                entity.Property(e => e.cli_id)
                   .HasColumnName("cli_id")
                   .HasColumnType("uint(10)");

                entity.Property(e => e.mac_id)
                   .HasColumnName("mac_id")
                   .HasColumnType("uint(11)");
            });
            
            modelBuilder.Entity<cli_purchase_details_view>(entity =>
            {
                entity.HasKey(e => e.cli_id);

                entity.ToTable("cli_purchase_details_view");

                entity.Property(e => e.cli_id).HasColumnName("cli_id");

                entity.Property(e => e.name)
                    .HasColumnName("name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.mac_id)
                    .HasColumnName("mac_id")
                    .HasColumnType("uint(11)");

                entity.Property(e => e.login_id)
                    .HasColumnName("login_id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.operator_name)
                    .HasColumnName("operator_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.mail)
                    .HasColumnName("mail")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.phone)
                    .HasColumnName("phone")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.serial)
                    .HasColumnName("serial")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.model)
                    .HasColumnName("model")
                    .HasColumnType("varchar(45)");
                

                entity.Property(e => e.purchase_dt)
                    .HasColumnName("purchase_dt")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.site_location)
                    .HasColumnName("site_location")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.user_phone)
                    .HasColumnName("user_phone")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.user_address)
                    .HasColumnName("user_address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.user_mail)
                    .HasColumnName("user_mail")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.username)
                    .HasColumnName("username")
                    .HasColumnType("varchar(45)");
            });

            modelBuilder.Entity<SentRemaindersView>(entity =>
            {
                entity.HasKey(e => e.sent_dates);

                entity.ToTable("sent_remainders_view");

                entity.Property(e => e.client_name)
                    .HasColumnName("client_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.address)
                    .HasColumnName("address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.mail)
                    .HasColumnName("mail")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.phone)
                    .HasColumnName("phone")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.serial)
                    .HasColumnName("serial")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.sent_dates)
                    .HasColumnName("sent_dates")
                    .HasColumnType("datetime");

                entity.Property(e => e.machine_cycle)
                    .HasColumnName("machine_cycle")
                    .HasColumnType("int(11)");

                entity.Property(e => e.maintanance_type)
                    .HasColumnName("maintanance_type")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.work_done)
                    .HasColumnName("work_done")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.cause)
                    .HasColumnName("cause")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.tech_name)
                   .HasColumnName("tech_name")
                   .HasColumnType("varchar(45)");

                entity.Property(e => e.replaced_parts)
                   .HasColumnName("replaced_parts")
                   .HasColumnType("varchar(45)");
            });
            modelBuilder.Entity<RemModel>(entity =>
            {
                entity.HasKey(e => e.model_id);

                entity.ToTable("rem_model");

                entity.Property(e => e.model_id)
                    .HasColumnName("model_id")
                    .HasColumnType("uint(10)");

                entity.Property(e => e.name)
                  .HasColumnName("name")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.remark)
                  .HasColumnName("remark")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.Image_to_upload_path)
                  .HasColumnName("image_upload_path")
                  .HasColumnType("varchar(300)");
            });

            modelBuilder.Entity<UtlModelRemView>(entity =>
            {
                entity.HasKey(e => e.rem_id);

                entity.ToTable("utl_model_rem_view");

                entity.Property(e => e.rem_id)
                    .HasColumnName("rem_id")
                    .HasColumnType("uint(10)");

                entity.Property(e => e.name)
                  .HasColumnName("name")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.base_threshold)
                  .HasColumnName("base_threshold")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.remainder_title)
                  .HasColumnName("remainder_title")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.details)
                  .HasColumnName("details")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.video)
                  .HasColumnName("video")
                  .HasColumnType("varchar(45)");

            });

            modelBuilder.Entity<RemModelRem>(entity =>
            {
                entity.HasKey(e => e.rem_id);

                entity.ToTable("rem_model_rem");

                entity.Property(e => e.model_id)
                    .HasColumnName("model_id")
                    .HasColumnType("uint(10)");

                entity.Property(e => e.rem_id)
                    .HasColumnName("rem_id")
                    .HasColumnType("uint(10)");                

                entity.Property(e => e.base_threshold)
                  .HasColumnName("base_threshold")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.remainder_title)
                  .HasColumnName("remainder_title")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.details)
                  .HasColumnName("details")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.video)
                  .HasColumnName("video")
                  .HasColumnType("varchar(45)");

            });

            modelBuilder.Entity<RemMacDet>(entity =>
            {
                entity.HasKey(e => e.mac_id);

                entity.ToTable("rem_mac_det");

                entity.Property(e => e.purchase_dt)
                    .HasColumnName("purchase_dt")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.serial)
                  .HasColumnName("serial")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.model_id)
                  .HasColumnName("model_id")
                  .HasColumnType("uint(11)");

                entity.Property(e => e.remark)
                  .HasColumnName("remark")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.operator_name)
                  .HasColumnName("operator_name")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.mail_id)
                  .HasColumnName("mail_id")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.phone_number)
                 .HasColumnName("phone_number")
                 .HasColumnType("varchar(45)");

                entity.Property(e => e.site_location)
                 .HasColumnName("site_location")
                 .HasColumnType("varchar(45)");

                entity.Property(e => e.login_id)
                 .HasColumnName("login_id")
                 .HasColumnType("int(11)");

                entity.Property(e => e.address)
                 .HasColumnName("address")
                 .HasColumnType("varchar(45)");

            });
            //Models.UtlMaintainenceDet.UtlMaintainenceDetclass
            modelBuilder.Entity<UtlMaintainenceDet>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("utl_maintainence_det");

                entity.Property(e => e.serial)
                    .HasColumnName("serial")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.machine_cycle)
                  .HasColumnName("machine_cycle")
                  .HasColumnType("int(11)");

                entity.Property(e => e.maintanance_type)
                  .HasColumnName("maintanance_type")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.cause)
                  .HasColumnName("cause")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.work_done)
                  .HasColumnName("work_done")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.replaced_parts)
                  .HasColumnName("replaced_parts")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.date_time)
                  .HasColumnName("date_time")
                  .HasColumnType("datetime");

                entity.Property(e => e.tech_name)
                  .HasColumnName("tech_name")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.video)
                  .HasColumnName("video")
                  .HasColumnType("varchar(45)");

            });

            modelBuilder.Entity<UtlErrorInfo>(entity =>
            {
                entity.HasKey(e => e._id);

                entity.ToTable("utl_error_info");

                entity.Property(e => e._id)
                    .HasColumnName("_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.machine_serial)
                    .HasColumnName("machine_serial")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.error_code)
                    .HasColumnName("error_code")
                    .HasColumnType("int(11)");

                entity.Property(e => e.error_details)
                   .HasColumnName("error_details")
                   .HasColumnType("varchar(45)");

                entity.Property(e => e.is_error)
                   .HasColumnName("is_error")
                   .HasColumnType("TINYINT(4)");
            });

            modelBuilder.Entity<LoginView>(entity =>
            {
                entity.HasKey(e => e.cli_id);

                entity.ToTable("login_view");

                entity.Property(e => e.username)
                    .HasColumnName("username")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.password)
                   .HasColumnName("password")
                   .HasColumnType("varchar(45)");

                entity.Property(e => e.role)
                   .HasColumnName("role")
                   .HasColumnType("varchar(45)");

                entity.Property(e => e.login_id)
                 .HasColumnName("login_id")
                 .HasColumnType("int(11)");
            });
            modelBuilder.Entity<CliMacView>(entity =>
            {
                entity.HasKey(e => e.cli_id);

                entity.ToTable("cli_mac_view");

                entity.Property(e => e.name)
                    .HasColumnName("name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.cli_id)
                    .HasColumnName("cli_id")
                    .HasColumnType("uint(10)");

                entity.Property(e => e.model_id)
                   .HasColumnName("model_id")
                   .HasColumnType("int(10)");

            });

            modelBuilder.Entity<UtilityErrView>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("utility_err_view");

                entity.Property(e => e.time_recv)
                    .HasColumnName("time_recv")
                    .HasColumnType("datetime");                

                entity.Property(e => e.err_concat)
                   .HasColumnName("err_concat")
                   .HasColumnType("text");

                entity.Property(e => e.error_details)
                  .HasColumnName("error_details")
                  .HasColumnType("text");

                entity.Property(e => e.machine_serial)
                  .HasColumnName("machine_serial")
                  .HasColumnType("varchar(45)");
                
                entity.Property(e => e.recipe_name)
                  .HasColumnName("recipe_name")
                  .HasColumnType("varchar(45)");
            });

            modelBuilder.Entity<UtlErrForGraph>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("utl_err_for_graph");

                entity.Property(e => e.time_recv)
                    .HasColumnName("time_recv")
                    .HasColumnType("datetime");

                entity.Property(e => e.time)
                   .HasColumnName("time")
                   .HasColumnType("int(11)");

                entity.Property(e => e.error_details)
                  .HasColumnName("error_details")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.machine_serial)
                  .HasColumnName("machine_serial")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.recipe_name)
                  .HasColumnName("recipe_name")
                  .HasColumnType("varchar(45)");

                entity.Property(e => e.error_code)
                  .HasColumnName("error_code")
                  .HasColumnType("int(11)");
            });

            modelBuilder.Entity<UtlMacDet>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("utl_mac_det");

                entity.Property(e => e.sno)
                    .HasColumnName("sno")
                    .HasColumnType("int(11)");

                entity.Property(e => e.time)
                   .HasColumnName("time")
                   .HasColumnType("int(11)");

                entity.Property(e => e.time_recv)
                  .HasColumnName("time_recv")
                  .HasColumnType("datetime");

                entity.Property(e => e.machine_serial)
                    .HasColumnName("machine_serial")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.speed)
                    .HasColumnName("speed")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.count)
                    .HasColumnName("count")
                    .HasColumnType("double");

                entity.Property(e => e.up_time)
                    .HasColumnName("up_time")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.idle_time)
                    .HasColumnName("idle_time")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.PLC_time)
                    .HasColumnName("PLC_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.wait_time)
                    .HasColumnName("wait_time")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.recipe_name)
                    .HasColumnName("recipe_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.is_fault)
                    .HasColumnName("is_fault")
                    .HasColumnType("int(11)");

                entity.Property(e => e.status)
                   .HasColumnName("status")
                   .HasColumnType("varchar(45)");

                entity.Property(e => e.machine_type)
                    .HasColumnName("machine_type")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.cycle_time)
                    .HasColumnName("cycle_time")
                    .HasColumnType("double");
            });

            modelBuilder.Entity<UtlMacError>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("utl_mac_error");

                entity.Property(e => e.sno)
                    .HasColumnName("sno")
                    .HasColumnType("int(11)");

                entity.Property(e => e.data_id)
                   .HasColumnName("data_id")
                   .HasColumnType("int(11)");

                entity.Property(e => e.error_code)
                   .HasColumnName("error_code")
                   .HasColumnType("int(11)");
          
            });

            modelBuilder.Entity<UtlData>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("utl_data");

                entity.Property(e => e.sno)
                    .HasColumnName("sno")
                    .HasColumnType("int(11)");

                entity.Property(e => e.date_time)
                   .HasColumnName("date_time")
                   .HasColumnType("datetime");

                entity.Property(e => e.time)
                   .HasColumnName("time")
                   .HasColumnType("int(11)");

                entity.Property(e => e.time_recv)
                  .HasColumnName("time_recv")
                  .HasColumnType("datetime");


            });

            modelBuilder.Entity<ErrorWithModelId>(entity =>
            {
                entity.HasKey(e => e._id);

                entity.ToTable("error_with_model_id");

                entity.Property(e => e._id)
                    .HasColumnName("_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.error_code)
                   .HasColumnName("error_code")
                   .HasColumnType("int(10)");

                entity.Property(e => e.error_description)
                   .HasColumnName("error_description")
                   .HasColumnType("varchar(45)");

                entity.Property(e => e.is_error)
                  .HasColumnName("is_error")
                  .HasColumnType("TINYINT(4)");

                entity.Property(e => e.model_id)
                  .HasColumnName("model_id")
                  .HasColumnType("int(10)");

            });

            modelBuilder.Entity<MacDetailsErrorView>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("mac_details_error_view");

                entity.Property(e => e.sno)
                    .HasColumnName("sno")
                    .HasColumnType("int(11)");

                entity.Property(e => e.error_code)
                   .HasColumnName("error_code")
                   .HasColumnType("int(11)");

                entity.Property(e => e.time_recv)
                   .HasColumnName("time_recv")
                   .HasColumnType("datetime");                

                entity.Property(e => e.time_diff_in_min)
                  .HasColumnName("time_diff_in_min")
                  .HasColumnType("int(11)");

                entity.Property(e => e.machine_serial)
                  .HasColumnName("machine_serial")
                  .HasColumnType("varchar(10)");

                entity.Property(e => e.status)
                  .HasColumnName("status")
                  .HasColumnType("varchar(10)");

                entity.Property(e => e.error_details)
                  .HasColumnName("error_details")
                  .HasColumnType("varchar(45)");

                /*entity.Property(e => e.codegrouping)
                  .HasColumnName("codegrouping")
                  .HasColumnType("double");*/

            });

        }
    }
}
