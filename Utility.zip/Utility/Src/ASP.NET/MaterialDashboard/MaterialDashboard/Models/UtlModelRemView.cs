﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public partial class UtlModelRemView
    {
        public uint rem_id { get; set; }
        public uint? model_id { get; set; }
        public string name { get; set; }
        public int base_threshold { get; set; }
        public string remainder_title { get; set; }
        public string details { get; set; }
        public string video { get; set; }
    }
}
