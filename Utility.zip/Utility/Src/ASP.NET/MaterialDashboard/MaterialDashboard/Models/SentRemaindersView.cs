﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class SentRemaindersView
    {
        public string client_name { get; set; }
        public string address { get; set; }
        public string mail { get; set; }
        public string phone { get; set; }
        public string serial { get; set; }
        public DateTime sent_dates { get; set; }
        public int machine_cycle { get; set; }
        public string maintanance_type { get; set; }
        public string work_done { get; set; }
        public string cause { get; set; }
        public string tech_name { get; set; }
        public string replaced_parts { get; set; }

    }
}
