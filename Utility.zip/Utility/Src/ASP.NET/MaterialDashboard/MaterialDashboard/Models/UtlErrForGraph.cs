﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public partial class UtlErrForGraph
    {
        public int sno { get; set; }
        public DateTime time_recv { get; set; }
        public int time { get; set; }
        public string machine_serial { get; set; }
        public string recipe_name { get; set; }
        public int error_code { get; set; }
        public string error_details { get; set; }
    }
}
