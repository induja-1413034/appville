﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class UtlData
    {
        public int sno { get; set; }
        public DateTime date_time { get; set; }
        public int time { get; set; }
        public DateTime time_recv { get; set; }
    }
}
