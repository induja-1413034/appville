﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public partial class RemModelRem
    {
        public int model_id { get; set; }
        public uint rem_id { get; set; }
        public string base_threshold { get; set; }
        public string details { get; set; }
        public string video { get; set; }
        public string image { get; set; }
        public string remainder_title { get; set; }
    }
}
