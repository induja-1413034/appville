﻿using System;
using System.Collections.Generic;

namespace MaterialDashboard.Models
{
    public partial class LoginTab
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string PasswordHash_str { get; set; }
        public string PasswordSalt_str { get; set; }
        public string Role { get; set; } = "user";
        public uint cli_id { get; set; }
        public string Mail { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
    }
}
