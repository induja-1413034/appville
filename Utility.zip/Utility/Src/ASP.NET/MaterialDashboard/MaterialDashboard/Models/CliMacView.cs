﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public partial class CliMacView
    {
        public uint cli_id { get; set; }
        public string serial { get; set; }
        public string name { get; set; }
        public int model_id { get; set; }
    }
}
