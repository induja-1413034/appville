﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class UtlMacDetJson
    {
       
            public int sno { get; set; }
            public int data_id { get; set; }
            public DateTime data_received_time { get; set; }
            public string error { get; set; }
            public string machine_serial { get; set; }
            public string speed { get; set; }
            public string count { get; set; }
            public string up_time { get; set; }
            public string idle_time { get; set; }
            public string PLC_time { get; set; }
            public string wait_time { get; set; }
            public string recipe_name { get; set; }
            public int is_fault { get; set; }
            public string status { get; set; }
            public string machine_type { get; set; }
            public string cycle_time { get; set; }
        }
}
