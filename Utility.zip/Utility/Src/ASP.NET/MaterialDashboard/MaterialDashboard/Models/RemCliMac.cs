﻿using System;
using System.Collections.Generic;

namespace MaterialDashboard.Models
{
    public partial class RemCliMac
    {
        public uint mac_id { get; set; }
        public int Sno { get; set; }
        public uint cli_id { get; set; }
       
    }
}
