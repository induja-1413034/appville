﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class UtlMacError
    {
        public int sno { get; set; }
        public int data_id { get; set; }
        public int error_code { get; set; }
        public double codegrouping;
    }
}
