﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public partial class cli_purchase_details_view
    {
        public int cli_id { get; set; }
        public string name { get; set; }
        public string operator_name { get; set; }
        public string mail { get; set; }
        public string phone { get; set; }
        public string serial { get; set; }
        public string model { get; set; }
        //public int mac_id { get; set; }
        public Nullable<uint> mac_id { get; set; }
        public Nullable<int> id;
        //public int id { get; set; }
        // public Nullable<int> mac_id;
        // public Nullable<int> id;
        public string purchase_dt { get; set; }
        public string site_location { get; set; }
        public Nullable<int> login_id { get; set; }
       // public Nullable<int> login_id;
       // public int client_id { get; set; }
        public Nullable<int> client_id;
        public string user_phone { get; set; }
        public string user_address { get; set; }
        public string user_mail { get; set; }
        public string username { get; set; }
    }
}
