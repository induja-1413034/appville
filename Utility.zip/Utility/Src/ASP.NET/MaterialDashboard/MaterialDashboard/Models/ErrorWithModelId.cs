﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class ErrorWithModelId
    {
        public int _id { get; set; }
        public int error_code { get; set; }
        public string error_description { get; set; }
        public bool is_error { get; set; }
        public int model_id { get; set; }

    }
}
