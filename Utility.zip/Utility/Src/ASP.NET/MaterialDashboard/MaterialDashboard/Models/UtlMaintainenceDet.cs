﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public partial class UtlMaintainenceDet
    {
        public int sno { get; set; }
        public string serial { get; set; }
        public int machine_cycle { get; set; }
        public string maintanance_type { get; set; }
        public string cause { get; set; }
        public string work_done { get; set; }
        public string replaced_parts { get; set; }
        public string tech_name { get; set; }
        public string video { get; set; }
        public DateTime date_time { get; set; }

        public class Item
        {
            public List<UtlMaintainenceDetclass> utlMaintainenceDets { get; set; }
        }
    }
    

    public class UtlMaintainenceDetclass
    {
        public int sno { get; set; }
        public string serial { get; set; }
        public int machine_cycle { get; set; }
        public string maintanance_type { get; set; }
        public string cause { get; set; }
        public string work_done { get; set; }
        public string replaced_parts { get; set; }
        public string tech_name { get; set; }
        public string video { get; set; }
        public DateTime date_time { get; set; }

    }
}
