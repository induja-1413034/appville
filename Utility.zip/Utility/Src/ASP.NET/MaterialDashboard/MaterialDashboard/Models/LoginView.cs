﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class LoginView
    {
        public string username { get; set; }
        public string password { get; set; }
        public string role { get; set; }
        public uint cli_id { get; set; }
        public int login_id { get; set; }
    }
}
