﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MaterialDashboard.Models
{
    public class MacDetailsErrorView
    {
        public int sno { get; set; }
        public DateTime time_recv { get; set; }
        public int time_diff_in_min { get; set; }
        public string machine_serial { get; set; }
        public string status { get; set; }
        public int? error_code { get; set; }
        public string error_details { get; set; }
       // public double codegrouping { get; set;}
    }
}
