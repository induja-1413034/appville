﻿using System;
using System.Collections.Generic;

namespace MaterialDashboard.Models
{
    public partial class RemMacDet
    {
        public uint mac_id { get; set; }
        public string purchase_dt { get; set; }
        public string serial { get; set; }
        public uint model_id { get; set; }
        public string remark { get; set; }
        public string operator_name { get; set; }
        public string mail_id { get; set; }
        public string phone_number { get; set; }
        public string site_location { get; set; }
        public Nullable<int> login_id { get; set; }
        //public int login_id { get; set; }
        public string address { get; set; }



    }
}
