dotnet ef dbcontext scaffold "Server=appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com;Database=appvilledb;user=appville_user;pwd=Appvilleiot1" "Pomelo.EntityFrameworkCore.MySql" -f -o .\Models -t rem_cli_det -t rem_mac_det -t rem_cli_mac -t cli_purchase_details_view -t login_tab

dotnet ef dbcontext scaffold "Server=appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com;Database=appvilledb;user=appville_user;pwd=Appvilleiot1" "Pomelo.EntityFrameworkCore.MySql" -f -o .\Models2 -t cli_purchase_details_view

dotnet ef dbcontext scaffold "server=appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com;user=appville_user;password=Appvilleiot1;database=appvilledb" MySql.Data.EntityFrameworkCore -o .\Models -t rem_cli_det -t rem_mac_det -f

Customer Details
--rem_cli_det - Customer Details
--rem_cli_det - Add Customer
--rem_cli_det - Edit Customer
rem_mac_det - cli_mac_list(delete)
rem_mac_det - add purchase
---rem_cli_mac - edit
cli_purchase_details_view - cli_mac_list
----login_tab - user details


https://www.youtube.com/watch?v=N10QW_AIOnI

appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com;Database=appvilledb
appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com

MQTT 
server: 104.214.79.73 
port:1883
user name: appville
password: App123Ville