import RPi.GPIO as GPIO
from time import sleep
from picamera import PiCamera
from time import sleep
import sys
import io
import requests
import urllib.request
camera = PiCamera()
def button_callback(channel):
    print("Button was pushed!")
    camera.start_preview()
    sleep(1)
    camera.led = True
    camera.capture('picture.jpg')
    camera.stop_preview()
    camera.led = False
    test_url='https://floatspotserver.azurewebsites.net/api/TextDetection/ImageUpload'
    files = {'file': open('picture.jpg', 'rb')}
    r = requests.post(test_url, files=files)
    print(r.status_code)
    resp = requests.get("https://floatspotserver.azurewebsites.net/api/TextDetection/TextDetection")
    print(resp.text)
    url = 'https://floatspotserver.azurewebsites.net/api/TextDetection'
    urllib.request.urlretrieve(url, 'test.png')
    sleep(1)
    #camera.close()
GPIO.setmode(GPIO.BCM)
GPIO.setup(23, GPIO.IN, pull_up_down = GPIO.PUD_DOWN)
GPIO.add_event_detect(23,GPIO.RISING,callback=button_callback,bouncetime=5000)
message = input("Press enter to quit\n\n")
GPIO.cleanup()
