﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
    public class Emailconfig
    {
        public String FromName = "Appville Softwares";
        public String FromAddress = "Appvillecbe@gmail.com";

        public String LocalDomain { get; set; }

        public String MailServerAddress = "smtp.gmail.com";
        public String MailServerPort = "587";

        public String UserId = "Appvillecbe@gmail.com";
        public String UserPassword = "123!Appville";


    }
}
