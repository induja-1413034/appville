﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
    public class TextDetectionDetails
    {
        public int id { get; set; }
        public int history_id { get; set; }
        public DateTime date_time { get; set; }
        public string MC_Number { get; set; }
        public string product { get; set; }
        public string Speed { get; set; }
        public int Good_Bag { get; set; }
        public int Emp_Bag { get; set; }
        public int NG_Bag { get; set; }
        public int Total_Bag { get; set; }
        public int Run_Time { get; set; }
        public int Stop_Time { get; set; }
        public int Adjust_Time { get; set; }
        public int Wait_Time { get; set; }
        public int Alarm_Time { get; set; }
        public int Total_Time { get; set; }
        public double Availability { get; set; }
        public double Efficiency { get; set; }
        public double Quality { get; set; }
        public double OEE { get; set; }
        public string Remark { get; set; }
        public bool IsBagMatched { get; set; }
        public bool IsTimeMatched { get; set; }
    }
}

