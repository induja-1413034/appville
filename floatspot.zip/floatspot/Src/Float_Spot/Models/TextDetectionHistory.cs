﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
    public class TextDetectionHistory
    {
        public int id { get; set; }
        public string csvfilepath { get; set; }
        public string textfilepath { get; set; }
        public string imagepath { get; set; }       
        public DateTime datetime { get; set; }
    }
}
