﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
    public class Backup_details
    {
        public int sno { get; set; }
        public string email_id { get; set; }
        public DateTime backup_time { get; set; }
        public string file_path { get; set; }
    }
}
