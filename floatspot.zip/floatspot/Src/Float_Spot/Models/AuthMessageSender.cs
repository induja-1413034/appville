﻿using Microsoft.Extensions.Options;
using MimeKit;
using MailKit.Net.Smtp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using MailKit.Security;
using Microsoft.AspNetCore.Identity.UI.Services;
using System.Net;
using MimeKit.Text;

namespace Float_Spot.Models
{
    public interface IEmailService
    {
        Task SendEmailAsync(string email, string message);
        //  Task SendEmailAsync(string message);
    }

    public class AuthMessageSender :IEmailService
    {
        private readonly Emailconfig ec;
        public AuthMessageSender(IOptions<Emailconfig> emailConfig)
        {
            this.ec = emailConfig.Value;
        }

        public async Task SendEmailAsync(string email, string message)
        {
            try
            {
                var emailMessage = new MimeMessage();

                emailMessage.From.Clear();
                emailMessage.From.Add(new MailboxAddress(ec.FromName, ec.FromAddress));

                emailMessage.To.Clear();
                emailMessage.To.Add(new MailboxAddress("Microsoft ASP.NET Core", email));

                emailMessage.Subject = "Test";
                emailMessage.Body = new TextPart(TextFormat.Html) { Text = string.Format("'{0}'", message) };

                using (var client = new MailKit.Net.Smtp.SmtpClient())
                {
                    client.LocalDomain = ec.LocalDomain;
                    client.ServerCertificateValidationCallback = (s, c, h, e) => true;
                    //await client.ConnectAsync(ec.MailServerAddress, Convert.ToInt32(ec.MailServerPort), SecureSocketOptions.Auto).ConfigureAwait(false);
                    await client.AuthenticateAsync(new NetworkCredential(ec.UserId, ec.UserPassword));
                    await client.SendAsync(emailMessage).ConfigureAwait(false);
                    await client.DisconnectAsync(true).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



        }
    }
}
