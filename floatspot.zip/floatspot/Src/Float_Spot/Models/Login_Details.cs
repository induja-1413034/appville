﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
    public class Login_Details
    {
        public int sno { get; set; }
        public string email_id { get; set; }
        public string Password { get; set; }
       // public byte[] PasswordHash { get; set; }
        public string PasswordHash_str { get; set; }
        //public byte[] PasswordSalt { get; set; }
        public string PasswordSalt_str { get; set; }
        public bool is_verified { get; set; }
    }
}
