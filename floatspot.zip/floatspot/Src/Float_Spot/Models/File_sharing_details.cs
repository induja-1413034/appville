﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
    public class File_sharing_details
    {
        public int sno { get; set; }
        public string from_mail_id { get; set; }
        public string to_mail_id { get; set; }
        public IFormFile file_to_share { get; set; }
        public string file_path { get; set; }
        public bool is_read { get; set; }
    }
}
