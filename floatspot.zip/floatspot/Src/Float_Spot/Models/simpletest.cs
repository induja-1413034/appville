﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net.Mail;
//using System.Threading.Tasks;

//namespace Float_Spot.Models
//{
//    public class simpletest
//    {
//        public async Task sendemail(string Toemail, string filePath)
//        {
//            try
//            {
//                await Task.Run(() =>
//                {
//                    MailMessage mail = new MailMessage();
//                    SmtpClient SmtpServer = new SmtpClient("smtp.sendgrid.net");
//                    mail.From = new MailAddress("xxxxxxxx@gmail.com");
//                    mail.To.Add(Toemail);
//                    mail.Subject = "Test Mail - 1";
//                    mail.Body = "mail with attachment";
//                    System.Net.Mail.Attachment attachment;
//                    attachment = new System.Net.Mail.Attachment(filePath);
//                    mail.Attachments.Add(attachment);
//                    SmtpServer.Port = 25;
//                    SmtpServer.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["ApiKey"], ConfigurationManager.AppSettings["ApiKeyPass"]);
//                    SmtpServer.EnableSsl = true;
//                    SmtpServer.Send(mail);
//                });
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }
//    }
//}
