﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
    public class Usage
    {
        public int sno { get; set; }
        public int login_id { get; set; }
        public DateTime current_date { get; set; }

        public string email_id { get; set; }
        public string name { get; set; }
        public string login_type { get; set; }
    }
}
