using System;
using Float_Spot;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;


namespace Float_Spot.Models
{
    public partial class appvilledbContext : DbContext
    {
        public appvilledbContext()
        {
        }

        public appvilledbContext(DbContextOptions<appvilledbContext> options)
            : base(options)
        {
        }

		public virtual DbSet<Login_Table> Login_Table { get; set; }
        public virtual DbSet<Login_Details> Login_Details { get; set; }
        public virtual DbSet<Backup_details> Backup_details { get; set; }
        public virtual DbSet<File_sharing_details> File_sharing_details { get; set; }
        public virtual DbSet<Usage> Usage { get; set; }
        public virtual DbSet<TextDetectionHistory> TextDetectionHistory { get; set; }
        public virtual DbSet<TextDetectionDetails> TextDetectionDetails { get; set; }
       


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("Server=braiding-new.mysql.database.azure.com; Port=3306; Database=float_spot; Uid=braidinguser@braiding-new; Pwd=123Appville!; SslMode=Preferred;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<File_sharing_details>().Ignore(c => c.file_to_share);
          //  modelBuilder.Entity<Login_Table>().Ignore(c => c.new_Password);

            modelBuilder.Entity<Login_Table>(entity =>
			{
				entity.HasKey(e => e.sno);

				entity.ToTable("login_table");

				entity.Property(e => e.sno).HasColumnName("sno").HasColumnType("int(11)"); 

				entity.Property(e => e.email_id)
					.HasColumnName("email_id")
					.HasColumnType("varchar(45)");

                entity.Property(e => e.name)
                    .HasColumnName("name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.login_type)
                    .HasColumnName("login_type")
                    .HasColumnType("varchar(45)");

                /*entity.Property(e => e.Password)
					.HasColumnName("Password")
					.HasColumnType("varchar(50)");*/



                entity.Property(e => e.is_verified)
                    .HasColumnName("is_verified")
                    .HasColumnType("tinyint(4)");

            });

            modelBuilder.Entity<Login_Details>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("login_details");

                entity.Property(e => e.sno).HasColumnName("sno").HasColumnType("int(11)");

                entity.Property(e => e.email_id)
                    .HasColumnName("email_id")
                    .HasColumnType("varchar(100)");

                //entity.Property(e => e.PasswordHash)
                //    .HasColumnName("PasswordHash")
                //    .HasColumnType("varbinary(1000)");

                //entity.Property(e => e.PasswordSalt)
                //    .HasColumnName("PasswordSalt")
                //    .HasColumnType("varbinary(1000)");

                entity.Property(e => e.PasswordHash_str)
                    .HasColumnName("PasswordHash_str")
                    .HasColumnType("varchar(1000)");

                entity.Property(e => e.PasswordSalt_str)
                   .HasColumnName("PasswordSalt_str")
                   .HasColumnType("varchar(1000)");

                entity.Property(e => e.is_verified)
                    .HasColumnName("is_verified")
                    .HasColumnType("tinyint(4)");
            });
            modelBuilder.Entity<Login_Details>().Ignore(c => c.Password);

            modelBuilder.Entity<Usage>().Ignore(c => c.email_id);
            modelBuilder.Entity<Usage>().Ignore(c => c.name);
            modelBuilder.Entity<Usage>().Ignore(c => c.login_type);
            modelBuilder.Entity<Usage>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("usage");

                entity.Property(e => e.sno).HasColumnName("sno").HasColumnType("int(10)");

                entity.Property(e => e.login_id)
                    .HasColumnName("login_id")
                    .HasColumnType("int(10");

                entity.Property(e => e.current_date)
                    .HasColumnName("current_date")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<Backup_details>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("backup_details");

                entity.Property(e => e.sno).HasColumnName("sno");

               // entity.Property(e => e.sno).HasColumnName("sno").HasColumnType("int(11)");

                entity.Property(e => e.email_id)
                    .HasColumnName("email_id")
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.backup_time)
                    .HasColumnName("backup_time")
                    .HasColumnType("DATETIME");

                entity.Property(e => e.file_path)
                    .HasColumnName("file_path")
                    .HasColumnType("varchar(100)");
            });
                     


            modelBuilder.Entity<File_sharing_details>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("file_sharing_details");

                entity.Property(e => e.sno).HasColumnName("sno");

                // entity.Property(e => e.sno).HasColumnName("sno").HasColumnType("int(11)");

                entity.Property(e => e.from_mail_id)
                    .HasColumnName("from_mail_id")
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.to_mail_id)
                    .HasColumnName("to_mail_id")
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.file_path)
                    .HasColumnName("file_path")
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.is_read)
                    .HasColumnName("is_read")
                    .HasColumnType("TINYINT(4)");
            });

            modelBuilder.Entity<TextDetectionHistory>(entity =>
            {
                entity.HasKey(e => e.id);

                entity.ToTable("text_detection_history");

                entity.Property(e => e.id).HasColumnName("id");

              
                entity.Property(e => e.csvfilepath)
                    .HasColumnName("csvfilepath")
                    .HasColumnType("varchar(1000)");

                entity.Property(e => e.datetime)
                    .HasColumnName("datetime")
                    .HasColumnType("DATETIME");

                entity.Property(e => e.imagepath)
                    .HasColumnName("imagepath")
                    .HasColumnType("varchar(1000)");

                entity.Property(e => e.textfilepath)
                    .HasColumnName("textfilepath")
                    .HasColumnType("varchar(1000)");
            });

            modelBuilder.Entity<TextDetectionDetails>(entity =>
            {
                entity.HasKey(e => e.id);

                entity.ToTable("textdetectiondetails");

                entity.Property(e => e.id).HasColumnName("id");

                entity.Property(e => e.history_id)
                    .HasColumnName("history_id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.date_time)
                    .HasColumnName("date_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.MC_Number)
                    .HasColumnName("MC_Number")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Speed)
                    .HasColumnName("Speed")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.product)
                    .HasColumnName("product")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Good_Bag)
                    .HasColumnName("Good_Bag")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Emp_Bag)
                    .HasColumnName("Emp_Bag")
                    .HasColumnType("int(11)");

                entity.Property(e => e.NG_Bag)
                    .HasColumnName("NG_Bag")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Total_Bag)
                    .HasColumnName("Total_Bag")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Run_Time)
                    .HasColumnName("Run_Time")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Stop_Time)
                    .HasColumnName("Stop_Time")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Adjust_Time)
                    .HasColumnName("Adjust_Time")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Alarm_Time)
                    .HasColumnName("Alarm_Time")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Wait_Time)
              .HasColumnName("Wait_Time")
              .HasColumnType("int(11)");

                entity.Property(e => e.Total_Time)
                    .HasColumnName("Total_Time")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Availability)
                    .HasColumnName("Availability")
                    .HasColumnType("double");

                entity.Property(e => e.Efficiency)
                    .HasColumnName("Efficiency")
                    .HasColumnType("double");

                entity.Property(e => e.Quality)
                    .HasColumnName("Quality")
                    .HasColumnType("double");

                entity.Property(e => e.OEE)
                    .HasColumnName("OEE")
                    .HasColumnType("double");

                entity.Property(e => e.Remark)
                    .HasColumnName("Remark")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.IsBagMatched)
                    .HasColumnName("IsBagMatched")
                    .HasColumnType("tinyint(4)");

                entity.Property(e => e.IsTimeMatched)
                    .HasColumnName("IsTimeMatched")
                    .HasColumnType("tinyint(4)");

            });

           /* modelBuilder.Entity<PresentationRasp>(entity =>
            {
                entity.HasKey(e => e._id);

                entity.ToTable("presentation_rasp");

                entity.Property(e => e._id).HasColumnName("_id").HasColumnType("int(11)");

                entity.Property(e => e.inp)
                    .HasColumnName("inp")
                    .HasColumnType("varchar(10)");
                
            });*/
        }
    }
}
