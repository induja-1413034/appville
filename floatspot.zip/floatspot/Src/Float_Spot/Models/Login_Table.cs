﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Float_Spot
{
    public class Login_Table
    {
        public int sno { get; set; }
        public string email_id { get; set; }
        //public string Password { get; set; }
        //public byte[] PasswordHash { get; set; }
        //public byte[] PasswordSalt { get; set; }
        //  public string new_Password { get; set; }
        public bool is_verified { get; set; }
        public string name { get; set; }
        public string login_type { get; set; }
       
    }
}
