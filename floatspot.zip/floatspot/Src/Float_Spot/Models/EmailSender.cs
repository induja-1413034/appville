﻿using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Float_Spot.Models
{
   /*public interface IEmailSender
    {
        Task SendEmailAsync(string email, string subject, string message);
        //  Task SendEmailAsync(string message);
    }*/
    public class EmailSender : IEmailSender
    {
        //private readonly AuthMessageSenderOptions Options;
        public AuthMessageSenderOptions Options { get; }

        public EmailSender(IOptions<AuthMessageSenderOptions> optionsAccessor)
        {
            Options = optionsAccessor.Value;
        }

       //set only via Secret Manager
        public async Task SendEmailAsync(string email, string subject, string message)
        {
             await Execute(Options.SendGridKey, subject, message, email);
        }

        public  Task Execute(string apiKey, string subject, string message, string email)
        {

            var client = new SendGridClient(apiKey);
            var msg = new SendGridMessage()
            {
                From = new EmailAddress("appvillecbe@gmail.com", "Appville Softwares"),
                Subject = subject,
                PlainTextContent = message,
                HtmlContent = message
            };
            msg.AddTo(new EmailAddress(email));
           /* var username = "appville";
            var pswd = "f9H3sHa7oQvrhXV";
            var credentials = new NetworkCredential(username, pswd);*/
            //var transportWeb = new Web(credentials);
            // Disable click tracking.
            // See https://sendgrid.com/docs/User_Guide/Settings/tracking.html
            //msg.SetClickTracking(false, false);
            var result =  client.SendEmailAsync(msg);           
            result.Wait();
            return client.SendEmailAsync(msg);
        }
    }
}

