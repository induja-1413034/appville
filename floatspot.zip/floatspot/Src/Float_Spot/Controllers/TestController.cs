﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        [HttpPost]
        public IActionResult getjson(testjson1 testjson)
        {            
            List<testjson> jsonlist = new List<testjson>();
            testjson test = new testjson();
            test.id = 1;
            test.name = "hai1";
            jsonlist.Add(test);
            testjson test1 = new testjson();
            test1.id = 2;
            test1.name = "hai2";
            jsonlist.Add(test1);
            testjson test2 = new testjson();
            test2.id = 3;
            test2.name = "hai3";
            jsonlist.Add(test2);
            testjson test3 = new testjson();
            test3.id = 4;
            test3.name = "hai4";
            jsonlist.Add(test3);
            var details=jsonlist.Find(x => x.id == Convert.ToInt32(testjson.id));
            return Ok(details);
        }

    }

    public class testjson
    {
        public int id;
        public string name;
    }
    public class testjson1
    {
        public string id;
    }
}