﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;
using CsvHelper;
using System.Net.Mail;
using System.Net.Mime;
//using MailKit.Net.Smtp;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TextDetectionController : ControllerBase
    {       
        private readonly IHostingEnvironment _environment;
        public IConfiguration Configuration { get; }
        private appvilledbContext _context;
               
        public TextDetectionController(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _environment = hostingEnvironment;
            Configuration = configuration;
        }

        [HttpPost("ImageUpload")]
        public async Task<IActionResult> AddBackup_details(IFormFile file)
        {
            try
            {
                _context = new appvilledbContext();
                string filePath = "";
                filePath = await UploadFileToBlobAsync(file);
                TextDetectionHistory text = new TextDetectionHistory();
                text.imagepath = filePath;
                _context.Add(text);
                await _context.SaveChangesAsync();
                if (filePath != "")
                {
                    return await textdetection(filePath);
                }
                else
                {
                    return Ok("Error in FileUpload");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new string[] { ex.Message });
            }
        }

        
        private async Task<IActionResult> textdetection(string imageFilePath)
        {
            try
            {              
                List<string> texts = new List<string>();                
                string response = await MakeOCRRequest(imageFilePath);
                if (response != null)
                {
                    dynamic dynObj = JsonConvert.DeserializeObject(response);
                    try
                    {
                        foreach (var dat in dynObj.recognitionResults)
                        {
                            foreach (var data in dat.lines)
                            {
                                string text = data.text;
                                if (text != null)
                                {
                                    texts.Add(text);
                                }
                            }
                        }
                        if (texts.Count != 0)
                        {
                            return Ok(texts);
                        }
                        else
                        {
                            return Ok(new string[] { "No Texts Found" });
                        }
                    }
                    catch (Exception ex)
                    {
                        string text = null;
                        var dat = dynObj.error;
                        text = dat.message;
                        return BadRequest(new string[] { text });
                    }
                }
                else
                {
                    return Ok(new string[] { "Text_Detection_Failed" });
                }
                
            }
            catch(Exception ex)
            {
                return BadRequest(new string[] { ex.Message });
            }
        }
      

        private async Task<string> UploadFileToBlobAsync(IFormFile file)
        {
            try
            {
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();                
                string strContainerName = "textdetectionhistory";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);                
                string[] strName = file.FileName.Split(".");                
                string fileName = DateTime.Now.ToUniversalTime().ToString("yyyyMMdd\\THHmmssfff") + "." + strName[strName.Length - 1]; ;
                if (await cloudBlobContainer.CreateIfNotExistsAsync())
                {
                    await cloudBlobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });                   
                }               
                if (fileName != null)
                {
                    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    cloudBlockBlob.Properties.ContentType = file.ContentType;
                    await cloudBlockBlob.UploadFromStreamAsync(file.OpenReadStream());
                    return cloudBlockBlob.Uri.AbsoluteUri;                   
                }                
                return null;
            }
            catch (Exception ex)
            {                
                throw ex;
            }
        }

        private async Task<string> MakeOCRRequest(string imageFilePath)
        {
            try
            {
                HttpClient client = new HttpClient();

                const string subscriptionKey = "1fd5bcba017c41aea8a564f79c7b3067";               

                const string uriBase =
                  "https://southcentralus.api.cognitive.microsoft.com/vision/v2.0/read/core/asyncBatchAnalyze";

                client.DefaultRequestHeaders.Add(
                    "Ocp-Apim-Subscription-Key", subscriptionKey);

                string uri = uriBase;
                HttpResponseMessage response;
                string operationLocation;
                byte[] byteData = GetImageAsByteArray(imageFilePath);

                using (ByteArrayContent content = new ByteArrayContent(byteData))
                {
                    content.Headers.ContentType =
                        new MediaTypeHeaderValue("application/octet-stream");

                    response = await client.PostAsync(uri, content);
                    Console.WriteLine("\nResponse:\n\n{0}\n", response);
                }
                if (response.IsSuccessStatusCode)
                    operationLocation =
                        response.Headers.GetValues("Operation-Location").FirstOrDefault();
                else
                {
                    string errorString = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("\n\nResponse:\n{0}\n",
                        JToken.Parse(errorString).ToString());
                    return JToken.Parse(errorString).ToString();
                }

                string contentString;
                int i = 0;
                do
                {
                    System.Threading.Thread.Sleep(1000);
                    response = await client.GetAsync(operationLocation);
                    contentString = await response.Content.ReadAsStringAsync();
                    ++i;
                }
                while (i < 10 && contentString.IndexOf("\"status\":\"Succeeded\"") == -1);

                if (i == 10 && contentString.IndexOf("\"status\":\"Succeeded\"") == -1)
                {
                    return "\nTimeout error.\n";
                }
                var jsonresponse = JToken.Parse(contentString).ToString();
                return jsonresponse;
            }
            catch (Exception ex)
            {               
                return (ex.Message);
            }
        }

        static byte[] GetImageAsByteArray(string urlImage)
        {
            var webClient = new WebClient();
            byte[] imageBytes = webClient.DownloadData(urlImage);
            return imageBytes;         
        }

        //[HttpGet]
        //public async Task<IActionResult> downloadFileAsync()
        //{
        //    try
        //    {
        //        string accessKey = Configuration["ConnectionStrings:AccessKey"];
        //        CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
        //        CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
        //        string strContainerName = "textdetectionhistory";
        //        CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
        //        string fileName = "testimage";
        //        CloudBlockBlob blockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
        //        var stream = await blockBlob.OpenReadAsync();
        //        return File(stream, blockBlob.Properties.ContentType, fileName);              
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}
    }
}