﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginDetailsController : ControllerBase
    {
        private appvilledbContext _context;

        [HttpPost]
        public async Task<IActionResult> sign_up([FromBody]Login_Details login)
        {
            try
            {
                _context = new appvilledbContext();
                if (string.IsNullOrWhiteSpace(login.Password))
                    throw new Exception("Password is required");

                var details = _context.Login_Details.Where(x => x.email_id == login.email_id).FirstOrDefault();
                if (details != null)
                    throw new Exception("Email " + login.email_id + " is already taken");


                byte[] passwordHash, passwordSalt;
                CreatePasswordHash(login.Password, out passwordHash, out passwordSalt);

                //login.PasswordHash = passwordHash;
                login.PasswordHash_str = Convert.ToBase64String(passwordHash);
                //login.PasswordSalt = passwordSalt;
                login.PasswordSalt_str = Convert.ToBase64String(passwordSalt);

                _context.Login_Details.Add(login);
                await _context.SaveChangesAsync();              
                return Ok("success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("Login")]
        public IActionResult Login(string email_id, string password)
        {
            try
            {
                _context = new appvilledbContext();

                var user = _context.Login_Details.Where(x => x.email_id.Equals(email_id)).FirstOrDefault();
                var PasswordHash = Convert.FromBase64String(user.PasswordHash_str);               
                var PasswordSalt = Convert.FromBase64String(user.PasswordSalt_str);

                if (!VerifyPasswordHash(password, PasswordHash, PasswordSalt))
                    return Ok("Incorrect Username or Password");

                else
                    return Ok("Login Success");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        private static void CreatePasswordHash(string pass_word, out byte[] passwordHash, out byte[] passwordSalt)
        {
            if (pass_word == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(pass_word)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");

            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(pass_word));
            }
        }

        private static bool VerifyPasswordHash(string password, byte[] storedHash, byte[] storedSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");
            //if (storedHash.Length != 64) throw new ArgumentException("Invalid length of password hash (64 bytes expected).", "passwordHash");
            // if (storedSalt.Length != 128) throw new ArgumentException("Invalid length of password salt (128 bytes expected).", "passwordHash");

            using (var hmac = new System.Security.Cryptography.HMACSHA512(storedSalt))
            {
                var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password));
                for (int i = 0; i < computedHash.Length; i++)
                {
                    if (computedHash[i] != storedHash[i]) return false;
                }
            }
            return true;
        }
    }
}