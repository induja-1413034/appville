﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;
using CsvHelper;
using System.Net.Mail;
using System.Net.Mime;
//using MailKit.Net.Smtp;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TextDetection1Controller : ControllerBase
    {
        private readonly IHostingEnvironment _environment;
        public IConfiguration Configuration { get; }
        private appvilledbContext _context;

        string err_details = "";
        public TextDetection1Controller(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _environment = hostingEnvironment;
            Configuration = configuration;
        }

        [HttpPost("ImageUpload")]
        public async Task<IActionResult> AddBackup_details(IFormFile file)
        {
            try
            {
                _context = new appvilledbContext();
                string filePath = "";
                filePath = await UploadFileToBlobAsync(file);
                TextDetectionHistory text = new TextDetectionHistory();
                text.imagepath = filePath;
                _context.Add(text);
                _context.SaveChanges();
                if (filePath != "")
                {
                    return await textdetection(filePath);
                }
                else
                {
                    return Ok("Error in FileUpload");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(err_details);
            }
        }


        private async Task<IActionResult> textdetection(string imageFilePath)
        {
            try
            {
                List<string> texts = new List<string>();
                string response = await MakeOCRRequest(imageFilePath);
                if (response != null)
                {
                    dynamic dynObj = JsonConvert.DeserializeObject(response);
                    foreach (var dat in dynObj.recognitionResults)
                    {
                        foreach (var data in dat.lines)
                        {
                            string text = data.text;
                            texts.Add(text);
                        }
                    }
                }
               var result = await FormatText(texts); 
                return Ok(result);
            }
            catch (Exception ex)
            {
                err_details += ex.ToString() + "(text detection)\n";
                throw ex;
            }
        }

        //new
        private async Task<IActionResult> FormatText(List<string> texts)
        {
            try
            {
                string[] textarray = new string[13];
                var total = 0;
                var total1 = "";
                var time = "";
                var per = "";
                var run_format = "";
                var stop_format = "";
                var adjust_format = "";
                var wait_format = "";
                var alarm_format = "";
                int a = 0, b = 0, c = 0, start = 0, current = 0, run = 0, stop = 0, adjust = 0, wait = 0, alarm = 0, total_time = 0;
                double per1 = 0.0;
                double per2 = 0.0;
                double per3 = 0.0;
                double per4 = 0.0;
                for (int i = 11; i < texts.Count; i++)
                {
                    if (texts[i] == "GOOD BAG")
                    {
                        //if(texts[i+1].Replace(".",","))
                        var result = texts[i] + "," + texts[i + 1].Replace(".", "").Replace(" ", ",") + "," + texts[i + 2];
                        textarray[0] = result;
                        var aa = texts[i + 1].Replace(".", "");
                        aa = aa.Replace("PC", "");
                        a = Convert.ToInt32(aa);
                        var aaa = texts[i + 2].Replace("%", "");
                        per1 = Convert.ToDouble(aaa);
                        i = i + 2;
                    }
                    else if (texts[i] == "EMP BAG")
                    {
                        var result = texts[i] + "," + texts[i + 1].Replace(".", "").Replace(" ", ",") + "," + texts[i + 2];
                        textarray[1] = result;
                        var bb = texts[i + 1].Replace(".", "");
                        bb = bb.Replace("PC", "");
                        b = Convert.ToInt32(bb);
                        var bbb = texts[i + 2].Replace("%", "");
                        per2 = Convert.ToDouble(bbb);
                        i = i + 2;
                    }
                    else if (texts[i] == "NG BAG")
                    {
                        var result = texts[i] + "," + texts[i + 1].Replace(".", "").Replace(" ", ",") + "," + texts[i + 2];
                        textarray[2] = result;
                        var cc = texts[i + 1].Replace(".", "");
                        cc = cc.Replace("PC", "");
                        c = Convert.ToInt32(cc);
                        var ccc = texts[i + 2].Replace("%", "");
                        per3 = Convert.ToDouble(ccc);
                        i = i + 2;
                    }
                    else if (texts[i] == "TOTAL BAG")
                    {
                        var result = texts[i] + "," + texts[i + 1].Replace(".", "").Replace(" ", ",");
                        textarray[3] = result;
                        var dd = texts[i + 1].Replace(".", "");
                        dd = dd.Replace("PC", "");
                        total = Convert.ToInt32(dd);
                        per4 = per1 + per2 + per3;
                        if(per4 >= 100.0 && per4 <=105)
                        {
                            per = "Percentage Matched";
                        }
                        else
                        {
                            per = "Percentage not Matched";
                        }
                        if (total == a + b + c)
                        {
                            total1 = "Total Bag Matched";
                        }
                        else
                        {
                            total1 = "Total Bag not Matched";
                        }
                        i = i + 1;
                    }
                    else if (texts[i] == "RUN TIME")
                    {
                        int totalmin = 0;
                        if (texts[i + 1].Contains("H"))
                        {
                            var hours = texts[i + 1].Split("H").First();
                            var min = texts[i + 1].Split("H").Last().Replace("M", "");
                            run_format = hours + ":" + min + ":00";
                            totalmin = Convert.ToInt32(hours) * 60 + Convert.ToInt32(min);
                            run = totalmin;
                        }
                        else
                        {
                            var min = texts[i + 1].Replace("M", "");
                            run_format = "00" + ":" + min + ":00";
                            totalmin = Convert.ToInt32(min);
                            run = totalmin;
                        }

                        var result = texts[i] + "," + texts[i + 1].Replace("H", ":").Replace("M", "") + ",(" + totalmin + " Minutes)";
                        textarray[6] = result;
                        i = i + 1;
                    }
                    else if (texts[i] == "STOP TIME")
                    {
                        int totalmin = 0;
                        if (texts[i + 1].Contains("H"))
                        {
                            var hours = texts[i + 1].Split("H").First();
                            var min = texts[i + 1].Split("H").Last().Replace("M", "");
                            stop_format = hours + ":" + min + ":00";
                            totalmin = Convert.ToInt32(hours) * 60 + Convert.ToInt32(min);
                            stop = totalmin;
                        }
                        else
                        {
                            var min = texts[i + 1].Replace("M", "");
                            stop_format = "00" + ":" + min + ":00";
                            totalmin = Convert.ToInt32(min);
                            stop = totalmin;
                        }

                        var result = texts[i] + "," + texts[i + 1].Replace("H", ":").Replace("M", "") + ",(" + totalmin + " Minutes)";
                        textarray[7] = result;
                        i = i + 1;
                    }
                    else if (texts[i] == "ADJUST TIME")
                    {
                        int totalmin = 0;
                        if (texts[i + 1].Contains("H"))
                        {
                            var hours = texts[i + 1].Split("H").First();
                            var min = texts[i + 1].Split("H").Last().Replace("M", "");
                            adjust_format = hours + ":" + min + ":00";
                            totalmin = Convert.ToInt32(hours) * 60 + Convert.ToInt32(min);
                            adjust = totalmin;
                        }
                        else
                        {
                            var min = texts[i + 1].Replace("M", "");
                            adjust_format = "00" + ":" + min + ":00";
                            totalmin = Convert.ToInt32(min);
                            adjust = totalmin;
                        }
                        var result = texts[i] + "," + texts[i + 1].Replace("H", ":").Replace("M", "") + ",(" + totalmin + " Minutes)";
                        textarray[8] = result;
                        i = i + 1;
                    }
                    else if (texts[i] == "WAIT TIME")
                    {
                        int totalmin = 0;
                        if (texts[i + 1].Contains("H"))
                        {
                            var hours = texts[i + 1].Split("H").First();
                            var min = texts[i + 1].Split("H").Last().Replace("M", "");
                            wait_format = hours + ":" + min + ":00";
                            totalmin = Convert.ToInt32(hours) * 60 + Convert.ToInt32(min);
                            wait = totalmin;
                        }
                        else
                        {
                            var min = texts[i + 1].Replace("M", "");
                            wait_format = "00" + ":" + min + ":00";
                            totalmin = Convert.ToInt32(min);
                            wait = totalmin;
                        }

                        var result = texts[i] + "," + texts[i + 1].Replace("H", ":").Replace("M", "") + ",(" + totalmin + " Minutes)";
                        textarray[9] = result;
                        i = i + 1;
                    }
                    else if (texts[i] == "ALARM TIME")
                    {
                        int totalmin = 0;
                        if (texts[i + 1].Contains("H"))
                        {
                            var hours = texts[i + 1].Split("H").First();
                            var min = texts[i + 1].Split("H").Last().Replace("M", "");
                            alarm_format = hours + ":" + min + ":00";
                            totalmin = Convert.ToInt32(hours) * 60 + Convert.ToInt32(min);
                            alarm = totalmin;
                        }
                        else
                        {
                            var min = texts[i + 1].Replace("M", "");
                            alarm_format = "00" + ":" + min + ":00";
                            totalmin = Convert.ToInt32(min);
                            alarm = totalmin;
                        }

                        var result = texts[i] + "," + texts[i + 1].Replace("H", ":").Replace("M", "") + ",(" + totalmin + " Minutes)";
                        textarray[10] = result;
                        i = i + 1;
                    }
                    else if (texts[i] == "TOTAL")
                    {
                        int totalmin = 0;
                        if (texts[i + 1].Contains("H"))
                        {
                            var hours = texts[i + 1].Split("H").First();
                            var min = texts[i + 1].Split("H").Last().Replace("M", "");
                            totalmin = Convert.ToInt32(hours) * 60 + Convert.ToInt32(min);
                            total_time = totalmin;
                            if (total_time == start + current + run + stop + adjust + wait + alarm)
                            {
                                time = "Total Time Matched";
                            }
                            else
                            {
                                time = "Total Time not Matched";
                            }
                        }
                        else
                        {
                            var min = texts[i + 1].Replace("M", "");
                            totalmin = Convert.ToInt32(min);
                            total_time = totalmin;
                            if (total_time == start + current + run + stop + adjust + wait + alarm)
                            {
                                time = "Total Time Matched";
                            }
                            else
                            {
                                time = "Total Time not Matched";
                            }
                        }
                        var result = texts[i] + "," + texts[i + 1].Replace("H", ":").Replace("M", "") + ",(" + totalmin + " Minutes)";
                        textarray[11] = result;
                        textarray[4] = total1;
                        textarray[5] = per;
                        textarray[12] = time;
                        i = i + 1;
                    }
                }
                //await WriteToFile(textarray);
                //return Ok("Success");
                return Ok(textarray);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private async Task<string> UploadFileToBlobAsync(IFormFile file)
        {
            try
            {
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "textdetectionhistory";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                string[] strName = file.FileName.Split(".");
                string fileName = DateTime.Now.ToUniversalTime().ToString("yyyyMMdd\\THHmmssfff") + "." + strName[strName.Length - 1]; ;
                if (await cloudBlobContainer.CreateIfNotExistsAsync())
                {
                    await cloudBlobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
                }
                if (fileName != null)
                {
                    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    cloudBlockBlob.Properties.ContentType = file.ContentType;
                    await cloudBlockBlob.UploadFromStreamAsync(file.OpenReadStream());
                    return cloudBlockBlob.Uri.AbsoluteUri;
                }
                return "";
            }
            catch (Exception ex)
            {
                err_details += ex.Message + "ImageUpload\n";
                throw ex;
            }
        }

        private async Task<string> MakeOCRRequest(string imageFilePath)
        {
            try
            {
                HttpClient client = new HttpClient();

                const string subscriptionKey = "1fd5bcba017c41aea8a564f79c7b3067";

                const string uriBase =
                  "https://southcentralus.api.cognitive.microsoft.com/vision/v2.0/read/core/asyncBatchAnalyze";

                client.DefaultRequestHeaders.Add(
                    "Ocp-Apim-Subscription-Key", subscriptionKey);

                string uri = uriBase;
                HttpResponseMessage response;
                string operationLocation;
                byte[] byteData = GetImageAsByteArray(imageFilePath);

                using (ByteArrayContent content = new ByteArrayContent(byteData))
                {
                    content.Headers.ContentType =
                        new MediaTypeHeaderValue("application/octet-stream");

                    response = await client.PostAsync(uri, content);
                    Console.WriteLine("\nResponse:\n\n{0}\n", response);
                }
                if (response.IsSuccessStatusCode)
                    operationLocation =
                        response.Headers.GetValues("Operation-Location").FirstOrDefault();
                else
                {
                    string errorString = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("\n\nResponse:\n{0}\n",
                        JToken.Parse(errorString).ToString());
                    return JToken.Parse(errorString).ToString();
                }

                string contentString;
                int i = 0;
                do
                {
                    System.Threading.Thread.Sleep(1000);
                    response = await client.GetAsync(operationLocation);
                    contentString = await response.Content.ReadAsStringAsync();
                    ++i;
                }
                while (i < 10 && contentString.IndexOf("\"status\":\"Succeeded\"") == -1);

                if (i == 10 && contentString.IndexOf("\"status\":\"Succeeded\"") == -1)
                {
                    return "\nTimeout error.\n";
                }
                var jsonresponse = JToken.Parse(contentString).ToString();
                return jsonresponse;
            }
            catch (Exception ex)
            {
                err_details += ex.Message + "Make Ocr Request\n";
                return (ex.Message);
            }
        }

        static byte[] GetImageAsByteArray(string urlImage)
        {
            var webClient = new WebClient();
            byte[] imageBytes = webClient.DownloadData(urlImage);
            return imageBytes;
        }

        
    }
}