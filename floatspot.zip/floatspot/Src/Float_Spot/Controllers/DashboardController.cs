﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Mvc;

namespace Float_Spot.Controllers
{
    public class DashboardController : Controller
    {
        private appvilledbContext _context;
        public IActionResult Dashboard()
        {
            return View();
        }

        [HttpGet]
        public IActionResult test(DateTime From, DateTime To)
        {
            try
            {
                _context = new appvilledbContext();
                var details = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).ToList();
                return Ok(details);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public IActionResult bar_chart(DateTime From, DateTime To)
        {
            try
            {
                _context = new appvilledbContext();
                List<string> date_format = new List<string>();
                var availability = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.Availability).ToArray();
                var efficiency = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.Efficiency).ToArray();
                var oee = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.OEE).ToArray();
                var quality = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.Quality).ToArray();
                var date = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.date_time).ToArray();
                foreach (var i in date)
                {
                    //date_format.Add(i.ToString().Substring(8) + "-" + i.ToString().Substring(5, 2));
                    date_format.Add(i.ToString().Substring(0, 5));
                }
                return Ok(new
                {
                    date = date_format,
                    availability = availability,
                    efficiency = efficiency,
                    oee = oee,
                    quality = quality
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public IActionResult stacked_bar(DateTime From, DateTime To)
        {
            try
            {
                _context = new appvilledbContext();
                List<string> date_format = new List<string>();
                var date = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.date_time).ToArray();
                var good_bag = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.Good_Bag).ToArray();
                var emp_bag = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.Emp_Bag).ToArray();
                var ng_bag = _context.TextDetectionDetails.Where(x => x.date_time >= From && x.date_time <= To).Select(y => y.NG_Bag).ToArray();
                foreach (var i in date)
                {
                    //date_format.Add(i.ToString().Substring(8) + "-" + i.ToString().Substring(5, 2));
                    date_format.Add(i.ToString().Substring(0,5));
                }
                return Ok(new
                {
                    date = date_format,
                    good_bag = good_bag,
                    emp_bag = emp_bag,
                    ng_bag = ng_bag
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}