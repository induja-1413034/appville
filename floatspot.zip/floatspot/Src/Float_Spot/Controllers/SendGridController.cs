﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;

namespace Float_Spot.Controllers
{   

    [Route("api/[controller]")]
    [ApiController]
    public class SendGridController : ControllerBase
    {
       /* public IEmailSender _emailSender;
        public SendGridController(IEmailSender emailSender)
        {
            _emailSender = emailSender;
        }*/
         private appvilledbContext _context;

        [HttpGet]
        public async Task<IActionResult> OnPostAsync(string returnUrl = null)
        {
            returnUrl = returnUrl ?? Url.Content("/");
            var callback = Url.Link("DefaultApi", new { controller = "SendGridController" });
            if (ModelState.IsValid)
            {
                var user = new IdentityUser { UserName = "induja", Email = "induja26.1997@gmail.com" };
               var callbackUrl =
                    Url.Content(
               "macdue-utility.azurewebsites.net/MachineLiveStatus/MachineLiveStatus"
                ); 

            /*    await _emailSender.SendEmailAsync("induja26.1997@gmail.com", "Confirm your email",
                    $"Please confirm your account by <a href='{callbackUrl}'>clicking here</a>."); */               
                    return LocalRedirect(returnUrl);
            }
            
            return Ok("success");
        }
        /* public IEmailSender _emailSender;

         public SendGridController(IEmailSender emailSender)
         {
             _emailSender = emailSender;
         }*/

        /* [HttpGet("verify")]
         public async Task<IActionResult> Email()
         {
             var str = "https://localhost:44386/api/Home/induja26.1997@gmail.com";
             //var callbackUrl =
             await _emailSender.SendEmailAsync("induja26.1997@gmail.com", $"Please confirm your account by clicking this link: <a href='{str}'>link</a>","test");
             //_emailService.SendEmailAsync("hi");
             return Ok("Success");
         }*/
    }
}