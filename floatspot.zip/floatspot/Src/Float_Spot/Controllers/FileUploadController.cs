﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.FileProviders;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileUploadController : ControllerBase
    {
        private appvilledbContext _context;
        private readonly IHostingEnvironment _environment;
        public IConfiguration Configuration { get; }

        public FileUploadController(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _environment = hostingEnvironment;
            Configuration = configuration;
        }
        

        /*Upload Backup Files and Saving to database*/
        [HttpPost("{id}")]
        public async Task<IActionResult> AddBackup_details(string id, IFormFile file)
        {
            try
            {
                _context = new appvilledbContext();
                var details = _context.Backup_details.Where(x => x.email_id == id).FirstOrDefault();
                if (details != null)
                {
                    DeleteBlobData(details.file_path);
                    //var pathfordirectory = Path.GetFullPath(_environment.WebRootPath);
                    //if (System.IO.File.Exists(string.Format("{0}/{1}", pathfordirectory, details.file_path)))
                    //{
                    //    System.IO.File.Delete(string.Format("{0}/{1}", pathfordirectory, details.file_path));
                    //}
                    details.file_path = UploadFileToBlob(file);
                    details.email_id = id;
                    details.backup_time = DateTime.Now;
                    _context.Update(details);
                    await _context.SaveChangesAsync();
                    return Ok("Updated Successfully");
                }
                else
                {
                    Backup_details details1 = new Backup_details();
                    details1.file_path = UploadFileToBlob(file);
                    details1.email_id = id;
                    details1.backup_time = DateTime.Now;
                    _context.Add(details1);
                    await _context.SaveChangesAsync();
                    return Ok("Saved Successfully");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /*Retriving Backup Details*/
        [HttpGet("{id}")]
        public async Task<IActionResult> downloadFileAsync(string id)
        {
            try
            {
                _context = new appvilledbContext();
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "floatspot";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);

                var details = _context.Backup_details.Where(x => x.email_id == id).FirstOrDefault();
                if (details != null)
                {
                    string filePath = details.file_path;
                    string fileName = Path.GetFileName(details.file_path);
                    Uri uriObj = new Uri(filePath);
                    //string[] path2 = uriObj.Segments;
                    //string pathPrefix = path2[2];
                    //CloudBlobDirectory blobDirectory = cloudBlobContainer.GetDirectoryReference(pathPrefix);
                    CloudBlockBlob blockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    var stream = await blockBlob.OpenReadAsync();
                    return File(stream, blockBlob.Properties.ContentType, fileName);
                }
                else
                {
                    return Ok("No backup found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        /*upload Sharing Files and Saving Details*/
        [HttpPost]
        public async Task<IActionResult> FileShare([FromForm]File_sharing_details fileshare)
        {
            try
            {
                _context = new appvilledbContext();
                File_sharing_details file_Sharing = new File_sharing_details();
                file_Sharing.from_mail_id = fileshare.from_mail_id;
                file_Sharing.to_mail_id = fileshare.to_mail_id;
                file_Sharing.file_path = UploadFileToBlob(fileshare.file_to_share);
                _context.Add(file_Sharing);
                await _context.SaveChangesAsync();
                return Ok("Saved Successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        /*Getting Shared Messages*/
        [Route("GetSharedMessage/{id}")]
        [HttpGet]
        public IActionResult SharedMessagelist(string id)
        {
            try
            {
                _context = new appvilledbContext();
                var msglist = _context.File_sharing_details.Where(x => x.to_mail_id == id);
                var msg_list_to_return = msglist.Select(x => new File_sharing_messages { From = x.from_mail_id, File_name = Path.GetFileName(x.file_path), Msg_read_status = x.is_read });
                return Ok(msg_list_to_return);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public class File_sharing_messages
        {
            public string From { get; set; } 
            public string File_name { get; set; }
            public bool Msg_read_status { get; set; }
        }

        /*Retriving Specific file*/
        [HttpGet("Download_file/{file_name}")]
        public async Task<IActionResult> downloadExactFileAsync(string file_name)
        {
            try
            {
                _context = new appvilledbContext();
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "floatspot";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                CloudBlockBlob blockBlob = cloudBlobContainer.GetBlockBlobReference(file_name);
                var stream = await blockBlob.OpenReadAsync();
                return File(stream, blockBlob.Properties.ContentType, file_name);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        public string UploadFileToBlob(IFormFile file)
        {
            try
            {
                var _task = Task.Run(() => this.UploadFileToBlobAsync(file));
                _task.Wait();
                string fileUrl = _task.Result;
                return fileUrl;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private async Task<string> UploadFileToBlobAsync(IFormFile file)
        {
            try
            {
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "floatspot";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                string fileName = this.GenerateFileName(file.FileName);

                if (await cloudBlobContainer.CreateIfNotExistsAsync())
                {
                    await cloudBlobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
                }
                if (fileName != null)
                {
                    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    cloudBlockBlob.Properties.ContentType = file.ContentType;
                    await cloudBlockBlob.UploadFromStreamAsync(file.OpenReadStream());
                    return cloudBlockBlob.Uri.AbsoluteUri;
                }
                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private string GenerateFileName(string fileName)
        {
            string strFileName = string.Empty;
            string[] strName = fileName.Split('.');
            strFileName = DateTime.Now.ToUniversalTime().ToString("yyyyMMdd\\THHmmssfff") + "." + strName[strName.Length - 1];
            return strFileName;
        }       

        public async void DeleteBlobData(string fileUrl)
        {
            try
            {
                Uri uriObj = new Uri(fileUrl);
                string BlobName = Path.GetFileName(uriObj.LocalPath);
                string[] path2 = uriObj.Segments;
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "floatspot";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                //CloudBlobDirectory folder = cloudBlobContainer.GetDirectoryReference("directoryName");

                string pathPrefix = path2[2];
                CloudBlobDirectory blobDirectory = cloudBlobContainer.GetDirectoryReference(pathPrefix);
                CloudBlockBlob blockBlob = blobDirectory.GetBlockBlobReference(BlobName);
                await blockBlob.DeleteAsync();
            }
            catch (Exception ex)
            {
                BadRequest(ex.Message);
            }
        }
    }
}