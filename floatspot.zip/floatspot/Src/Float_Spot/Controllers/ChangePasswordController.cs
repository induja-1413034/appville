﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChangePasswordController : ControllerBase
    {
        private appvilledbContext _context;
       /* [HttpGet]
        public IActionResult changepwd([FromBody] Login_Table login)
        {
            _context = new appvilledbContext();
            var a = _context.Login_Table.Where(x => x.email_id.Equals(login.email_id) && x.Password.Equals(login.Password)).FirstOrDefault();
            if (a != null)
            {
                a.Password = login.new_Password;
                _context.Update(a);
                _context.SaveChanges();
                return Ok("Password changed Successfully");
            }
            else
            {
                return Ok("Your Current Password is Wrong");
            }
        }*/
    }
}