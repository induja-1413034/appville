﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;
using CsvHelper;
using System.Net.Mail;
//using System.IO;
using System.Net.Mime;
using System.ComponentModel;
using System.Text.RegularExpressions;
using Microsoft.WindowsAzure.Storage.Auth;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TextDetectionReportController : ControllerBase
    {
        private readonly IHostingEnvironment _environment;
        public IConfiguration Configuration { get; }
        private appvilledbContext _context;

        public TextDetectionReportController(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _environment = hostingEnvironment;
            Configuration = configuration;
        }

        TimeZoneInfo timeZoneInfo;
        DateTime dateTime;      

        [HttpPost("ImageUpload")]
        public async Task<IActionResult> AddBackup_details(IFormFile file)
        {
            try
            {
                _context = new appvilledbContext();
                string filePath = "";
                filePath = await UploadFileToBlobAsync(file);
                if (filePath != "")
                {
                    TextDetectionHistory details = new TextDetectionHistory();
                    details.datetime = DateTime.Now;

                    details.imagepath = filePath;
                    timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                    dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                    details.datetime = dateTime;
                    details.imagepath = filePath;
                    _context.Add(details);
                    await _context.SaveChangesAsync();
                    return Ok(new[] { "Success=" + details.id });
                }
                else
                {

                    return BadRequest(new[] { "Failure=Error in FileUpload" });

                   // return BadRequest(new[] { "Failure=Error in FileUpload" });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new[] { "Failure=" + ex.Message });
            }
        }


        [HttpGet("Detection/{id}")]
        public async Task<IActionResult> textdetection(string id)
        {
            try
            {
                _context = new appvilledbContext();
                List<string> texts = new List<string>();
                string imageFilePath = _context.TextDetectionHistory.Where(x => x.id == Convert.ToInt32(id)).Select(y => y.imagepath).FirstOrDefault();
                if (imageFilePath == null)
                {
                    return Ok(new[] { "Failure=" + "This is not a valid id" });
                }
                else
                {
                    string response1 = await MakeOCRRequest1(imageFilePath);
                    if (response1 != null)
                    {
                        dynamic dynObj = JsonConvert.DeserializeObject(response1);
                        try
                        {
                            foreach (var dat in dynObj.recognitionResults)
                            {
                                foreach (var data in dat.lines)
                                {
                                    string text = data.text;
                                    if (text != null)
                                    {
                                        texts.Add(text);
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            string text = null;
                            var dat = dynObj.error;
                            text = dat.message;
                            return BadRequest(new { Failure = text });
                        }
                        if (texts.Count != 0)
                        {
                            return await WriteToFileNoFormat(id, texts);
                        }
                        else
                        {

                            return BadRequest(new[] { "Failure=No Texts Found" });  
                        }
                    }
                    else
                    {
                        return BadRequest(new[] { "Failure=Text_Detection_Failed" });
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new[] { "Failure=" + ex.Message });
            }
            finally
            {
                _context.Dispose();
            }
        }

        //Write to file without format
        private async Task<IActionResult> WriteToFileNoFormat(string id, List<string> texts)
        {
            try
            {
                string uploadedurlpath = "";
                _context = new appvilledbContext();
                using (var mem = new MemoryStream())
                {
                    using (StreamWriter writer = new StreamWriter(mem))
                    {
                        foreach (string line in texts)
                        {
                            writer.WriteLine(line);
                        }
                        writer.Flush();
                        writer.BaseStream.Position = 0;

                        string accessKey = Configuration["ConnectionStrings:AccessKey"];
                        CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                        CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                        string strContainerName = "textdetectionhistorytext";
                        CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                        timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                        string fileName = dateTime.ToString("yyyyMMdd\\THHmmssfff") + "." + "txt";                       
                        if (fileName != null)
                        {
                            CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                            cloudBlockBlob.Properties.ContentType = "text/plain";
                            await cloudBlockBlob.UploadFromStreamAsync(writer.BaseStream);
                            uploadedurlpath = cloudBlockBlob.Uri.AbsoluteUri;
                            if (uploadedurlpath != "")
                            {
                                var details = _context.TextDetectionHistory.Find(Convert.ToInt32(id));
                                details.textfilepath = cloudBlockBlob.Uri.AbsoluteUri;
                                _context.Update(details);
                                await _context.SaveChangesAsync();
                            }
                        }
                    }
                }
                return Ok(new[] { "Success=" + id });
            }
            catch (Exception ex)
            {
                return BadRequest(new[] { "Failure=" + ex.Message });
            }
            finally
            {
                _context.Dispose();
            }
        }

        [HttpGet("Format/{id}/{McNumber}/{Remark?}")]
        public async Task<IActionResult> Formattest(string id, string McNumber, string Remark)
        {
            try
            {
                _context = new appvilledbContext();
                string textFile = _context.TextDetectionHistory.Where(x => x.id.Equals(Convert.ToInt32(id))).Select(y => y.textfilepath).FirstOrDefault();               
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "textdetectionhistorytext";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                string fileName = textFile.Split('/').LastOrDefault();
                if (fileName != null)
                {
                    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    await cloudBlockBlob.FetchAttributesAsync();
                    byte[] byteArray = new byte[cloudBlockBlob.Properties.Length];
                    await cloudBlockBlob.DownloadToByteArrayAsync(byteArray, 0);                  
                    MemoryStream ms = new MemoryStream(byteArray);
                    List<string> textarray = new List<string>();
                    using (StreamReader file = new StreamReader(ms))
                    {
                        string ln;
                        while ((ln = file.ReadLine()) != null)
                        {
                            textarray.Add(ln);
                        }
                        file.Close();
                    }
                    return await FormatText(textarray, id, McNumber, Remark);
                }
                else
                {
                    return Ok(new[] { "Failure=" + "This is not a valid id" });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new[] { "Failure=" + ex.Message });
            }
            finally
            {
                _context.Dispose();
            }
        }

        private async Task<IActionResult> FormatText(List<string> texts, string id, string McNumber, string Remark)
        {
            try
            {
                _context = new appvilledbContext();
                TextDetectionDetails detectionDetails = new TextDetectionDetails();
                detectionDetails.history_id = Convert.ToInt32(id);
                if (texts.Count < 5)
                {
                    return null;
                }               
                for (int i = 5; i < texts.Count - 1; i++)
                {
                    if (texts[i].ToUpper().Contains("RS") || texts[i + 1].Contains("("))
                    {
                        //string pp = Regex.Replace(texts[i], @"[\s]", "");
                        string[] products = Regex.Split(texts[i], @"\D+");
                        if (products[0] != "")
                        {
                            string pp1 = texts[i].Replace(products[0], "");
                            string pp2 = pp1.Replace("$", "S");
                            detectionDetails.product = pp2;
                        }
                        else
                        {
                            string pp1 = texts[i].Replace("$", "S");
                            detectionDetails.product = pp1;
                        }
                        string aa = Regex.Replace(texts[i + 1], @"[\s]", "");
                        string[] numbers = Regex.Split(aa, @"\D+");
                        if (texts[i + 1].Contains("("))
                        {
                            detectionDetails.Speed = numbers[1];
                        }
                        else
                        {
                            detectionDetails.Speed = numbers[0];
                        }
                    }
                    else if (texts[i] == "GOOD BAG")
                    {
                        string aa = Regex.Replace(texts[i + 1], @"[^\d]", "");
                        if (aa == "")
                        {
                            detectionDetails.Good_Bag = 0;
                        }
                        else
                        {
                            detectionDetails.Good_Bag = Convert.ToInt32(aa);
                        }
                        i = i + 2;
                    }
                    else if (texts[i] == "EMP BAG")
                    {
                        string bb = Regex.Replace(texts[i + 1], @"[^\d]", "");
                        if (bb == "")
                        {
                            detectionDetails.Emp_Bag = 0;
                        }
                        else
                        {
                            detectionDetails.Emp_Bag = Convert.ToInt32(bb);
                        }
                        i = i + 2;
                    }
                    else if (texts[i] == "NG BAG")
                    {
                        string cc = Regex.Replace(texts[i + 1], @"[^\d]", "");
                        if (cc == "")
                        {
                            detectionDetails.NG_Bag = 0;
                        }
                        else
                        {
                            detectionDetails.NG_Bag = Convert.ToInt32(cc);
                        }
                        i = i + 2;
                    }
                    else if (texts[i] == "TOTAL BAG")
                    {
                        string dd = Regex.Replace(texts[i + 1], @"[^\d]", "");
                        if (dd == "")
                        {
                            detectionDetails.Total_Bag = 0;
                        }
                        else
                        {
                            detectionDetails.Total_Bag = Convert.ToInt32(dd);
                        }
                        int TotalBag_calculated = detectionDetails.Good_Bag + detectionDetails.Emp_Bag + detectionDetails.NG_Bag;
                        var lesstotal = TotalBag_calculated - 2;
                        var plustotal = TotalBag_calculated + 2;
                        if (detectionDetails.Total_Bag >= lesstotal && detectionDetails.Total_Bag <= plustotal)
                        {
                            detectionDetails.IsBagMatched = true;
                        }
                        else
                        {
                            detectionDetails.IsBagMatched = false;
                        }
                        i = i + 1;
                    }
                    else if (texts[i] == "RUN TIME")
                    {
                        int totalmin = 0;
                        int hours = 0;
                        int min = 0;
                        string aa = Regex.Replace(texts[i + 1], @"[\s]", "");
                        string[] numbers = Regex.Split(aa, @"\D+");
                        if (numbers.Length == 2)
                        {
                            if (texts[i + 1].Contains('M'))
                            {
                                if (numbers[0] != "")
                                {
                                    min = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    min = 0;
                                }
                                totalmin = min;
                            }
                            else if (texts[i + 1].Contains('H'))
                            {
                                if (numbers[0] != "")
                                {
                                    hours = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    hours = 0;
                                }
                                totalmin = hours * 60;
                            }
                        }
                        else
                        {
                            if (numbers[0] != "")
                            {
                                hours = int.Parse(numbers[0]);
                            }
                            else
                            {
                                hours = 0;
                            }
                            if (numbers[1] != "")
                            {
                                min = int.Parse(numbers[1]);
                            }
                            else
                            {
                                min = 0;
                            }
                            totalmin = hours * 60 + min;
                        }
                        detectionDetails.Run_Time = totalmin;
                        i = i + 1;
                    }
                    else if (texts[i] == "STOP TIME")
                    {
                        int totalmin = 0;
                        int hours = 0;
                        int min = 0;
                        string aa = Regex.Replace(texts[i + 1], @"[\s]", "");
                        string[] numbers = Regex.Split(aa, @"\D+");
                        if (numbers.Length == 2)
                        {
                            if (texts[i + 1].Contains('M'))
                            {
                                if (numbers[0] != "")
                                {
                                    min = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    min = 0;
                                }
                                totalmin = min;
                            }
                            else if (texts[i + 1].Contains('H'))
                            {
                                if (numbers[0] != "")
                                {
                                    hours = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    hours = 0;
                                }
                                totalmin = hours * 60;
                            }
                        }
                        else
                        {
                            if (numbers[0] != "")
                            {
                                hours = int.Parse(numbers[0]);
                            }
                            else
                            {
                                hours = 0;
                            }
                            if (numbers[1] != "")
                            {
                                min = int.Parse(numbers[1]);
                            }
                            else
                            {
                                min = 0;
                            }
                            totalmin = hours * 60 + min;
                        }
                        detectionDetails.Stop_Time = totalmin;
                        i = i + 1;
                    }
                    else if (texts[i] == "ADJUST TIME")
                    {
                        int totalmin = 0;
                        int hours = 0;
                        int min = 0;
                        string aa = Regex.Replace(texts[i + 1], @"[\s]", "");
                        string[] numbers = Regex.Split(aa, @"\D+");
                        if (numbers.Length == 2)
                        {
                            if (texts[i + 1].Contains('M'))
                            {
                                if (numbers[0] != "")
                                {
                                    min = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    min = 0;
                                }
                                totalmin = min;
                            }
                            else if (texts[i + 1].Contains('H'))
                            {
                                if (numbers[0] != "")
                                {
                                    hours = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    hours = 0;
                                }
                                totalmin = hours * 60;
                            }
                        }
                        else
                        {
                            if (numbers[0] != "")
                            {
                                hours = int.Parse(numbers[0]);
                            }
                            else
                            {
                                hours = 0;
                            }
                            if (numbers[1] != "")
                            {
                                min = int.Parse(numbers[1]);
                            }
                            else
                            {
                                min = 0;
                            }
                            totalmin = hours * 60 + min;
                        }
                        detectionDetails.Adjust_Time = totalmin;
                        i = i + 1;
                    }
                    else if (texts[i] == "WAIT TIME")
                    {
                        int totalmin = 0;
                        int hours = 0;
                        int min = 0;
                        string aa = Regex.Replace(texts[i + 1], @"[\s]", "");
                        string[] numbers = Regex.Split(aa, @"\D+");
                        if (numbers.Length == 2)
                        {
                            if (texts[i + 1].Contains('M'))
                            {
                                if (numbers[0] != "")
                                {
                                    min = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    min = 0;
                                }
                                totalmin = min;
                            }
                            else if (texts[i + 1].Contains('H'))
                            {
                                if (numbers[0] != "")
                                {
                                    hours = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    hours = 0;
                                }
                                totalmin = hours * 60;
                            }
                        }
                        else
                        {
                            if (numbers[0] != "")
                            {
                                hours = int.Parse(numbers[0]);
                            }
                            else
                            {
                                hours = 0;
                            }
                            if (numbers[1] != "")
                            {
                                min = int.Parse(numbers[1]);
                            }
                            else
                            {
                                min = 0;
                            }
                            totalmin = hours * 60 + min;
                        }
                        detectionDetails.Wait_Time = totalmin;
                        i = i + 1;
                    }
                    else if (texts[i] == "ALARM TIME")
                    {
                        int totalmin = 0;
                        int hours = 0;
                        int min = 0;
                        string aa = Regex.Replace(texts[i + 1], @"[\s]", "");
                        string[] numbers = Regex.Split(aa, @"\D+");
                        if (numbers.Length == 2)
                        {
                            if (texts[i + 1].Contains('M'))
                            {
                                if (numbers[0] != "")
                                {
                                    min = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    min = 0;
                                }
                                totalmin = min;
                            }
                            else if (texts[i + 1].Contains('H'))
                            {
                                if (numbers[0] != "")
                                {
                                    hours = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    hours = 0;
                                }
                                totalmin = hours * 60;
                            }
                        }
                        else
                        {
                            if (numbers[0] != "")
                            {
                                hours = int.Parse(numbers[0]);
                            }
                            else
                            {
                                hours = 0;
                            }
                            if (numbers[1] != "")
                            {
                                min = int.Parse(numbers[1]);
                            }
                            else
                            {
                                min = 0;
                            }
                            totalmin = hours * 60 + min;
                        }
                        detectionDetails.Alarm_Time = totalmin;
                        i = i + 1;
                    }
                    else if (texts[i] == "TOTAL")
                    {
                        int totalmin = 0;
                        int hours = 0;
                        int min = 0;
                        string aa = Regex.Replace(texts[i + 1], @"[\s]", "");
                        string[] numbers = Regex.Split(aa, @"\D+");
                        if (numbers.Length == 2)
                        {
                            if (texts[i + 1].Contains('M'))
                            {
                                if (numbers[0] != "")
                                {
                                    min = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    min = 0;
                                }
                                totalmin = min;
                            }
                            else if (texts[i + 1].Contains('H'))
                            {
                                if (numbers[0] != "")
                                {
                                    hours = int.Parse(numbers[0]);
                                }
                                else
                                {
                                    hours = 0;
                                }
                                totalmin = hours * 60;
                            }
                        }
                        else
                        {
                            if (numbers[0] != "")
                            {
                                hours = int.Parse(numbers[0]);
                            }
                            else
                            {
                                hours = 0;
                            }
                            if (numbers[1] != "")
                            {
                                min = int.Parse(numbers[1]);
                            }
                            else
                            {
                                min = 0;
                            }
                            totalmin = hours * 60 + min;
                        }
                        detectionDetails.Total_Time = totalmin;
                        var totaltime_calculated = detectionDetails.Run_Time + detectionDetails.Stop_Time + detectionDetails.Adjust_Time + detectionDetails.Wait_Time + detectionDetails.Alarm_Time;
                        if (detectionDetails.Total_Time >= totaltime_calculated - 2 && detectionDetails.Total_Time <= totaltime_calculated + 2)
                        {
                            detectionDetails.IsTimeMatched = true;
                        }
                        else
                        {
                            detectionDetails.IsTimeMatched = false;
                        }
                        i = i + 1;
                    }
                }

                timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                detectionDetails.date_time = dateTime;
                detectionDetails.MC_Number = McNumber;
                detectionDetails.Remark = Remark;
                Double Availability = 0;
                Double Efficiency = 0;
                Double Quality = 0;
                if (detectionDetails.Run_Time != 0)
                {
                    Availability = (Convert.ToDouble(detectionDetails.Run_Time) / Convert.ToDouble(detectionDetails.Total_Time));
                    detectionDetails.Availability = Math.Round(Availability * 100, 2,
                                             MidpointRounding.ToEven);
                }
                if (detectionDetails.Speed != null && detectionDetails.Total_Bag != 0 && detectionDetails.Run_Time != 0)
                {
                    Efficiency = (Convert.ToDouble(detectionDetails.Total_Bag) / (Convert.ToDouble(detectionDetails.Run_Time) * Convert.ToDouble(detectionDetails.Speed)));
                    detectionDetails.Efficiency = Math.Round(Efficiency * 100, 2,
                                             MidpointRounding.ToEven);
                }
                if (detectionDetails.Good_Bag != 0)
                {
                    Quality = (Convert.ToDouble(detectionDetails.Good_Bag) / Convert.ToDouble(detectionDetails.Total_Bag));
                    detectionDetails.Quality = Math.Round(Quality * 100, 2,
                                             MidpointRounding.ToEven);
                }
                detectionDetails.OEE = Math.Round(Availability * Efficiency * Quality * 100, 2, MidpointRounding.ToEven);

                _context.Add(detectionDetails);
                var x = await _context.SaveChangesAsync();
                if (x == 1)
                {
                    if (detectionDetails.IsBagMatched == true && detectionDetails.IsTimeMatched == true && detectionDetails.Speed != null)
                    {
                        return WriteToFile();
                    }
                    else
                    {
                        return BadRequest(new[] { "Failure=" + "Validation Failed. Please Retake Photo" });
                    }
                }
                else
                {
                    return BadRequest(new[] { "Failure=" + "Database Error. Please Retake Photo" });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _context.Dispose();
            }
        }
        
        private IActionResult WriteToFile()
        {
            try
            {
                byte[] bytes = null;
                _context = new appvilledbContext();
                TimeZoneInfo timeZoneInfo;
                DateTime dateTime;
                timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                DateTime dateTime1 = dateTime.AddDays(-30);

                var detailslist = _context.TextDetectionDetails.Where(x => x.date_time <= dateTime && x.date_time >= dateTime1 && x.IsBagMatched == true && x.IsTimeMatched == true).ToList();

                if (detailslist.Count != 0)
                using (var mem = new MemoryStream())
                {
                    using (var writer = new StreamWriter(mem))
                    {
                        string texts = "DateTime,Mc Number, Product, Speed, GoodBag, Emp Bag, NG Bag, Total Bag,Run Time, Stop Time, Adjust Time,Alarm Time, Wait Time,Total Time, Availability,Efficiency,Quality,OEE,Remarks";
                        writer.WriteLine(texts);
                        foreach (var details in detailslist)
                        {
                            string text_to_write = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18}", details.date_time, details.MC_Number, details.product, details.Speed, details.Good_Bag, details.Emp_Bag, details.NG_Bag, details.Total_Bag, details.Run_Time, details.Stop_Time, details.Adjust_Time, details.Alarm_Time, details.Wait_Time, details.Total_Time, details.Availability, details.Efficiency, details.Quality, details.OEE, details.Remark);
                            writer.WriteLine(text_to_write);
                        }
                    }
                    bytes = mem.ToArray();
                }
              
                return SendEmail(bytes);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _context.Dispose();
            }
        }

        private IActionResult SendEmail(byte[] byteArray)
        {
            try
            {
                _context = new appvilledbContext();
                MailMessage mail = new MailMessage();
                mail.Body = "Detected Texts are in csv File. Pls Find Attachment";
                mail.IsBodyHtml = true;
              
                mail.To.Add(new MailAddress("dinesh.k@itc.in"));
                mail.To.Add(new MailAddress("Meeya.lukman@itc.in"));
                mail.To.Add(new MailAddress("Gomathishankar.k@itc.in"));
                mail.To.Add(new MailAddress("logesh2k8@gmail.com"));
                mail.To.Add(new MailAddress("appvillecbe@gmail.com"));                
                mail.From = new MailAddress("tech@appville.in");

                mail.Subject = "Report Generation Successful";
                mail.SubjectEncoding = Encoding.UTF8;
                mail.Priority = MailPriority.Normal;
                MemoryStream ms = null;
                    
                ms=new MemoryStream(byteArray);
                Attachment attachment = new Attachment(ms, "TextDetectionReport.csv");
                mail.Attachments.Add(attachment);

                SmtpClient smtp = new SmtpClient();
                smtp.Credentials = new System.Net.NetworkCredential("appville", "App123Ville!");
                smtp.Host = "smtp.sendgrid.net";
                smtp.Send(mail);
                return Ok(new[] { "Success=" + "Mail Sent" });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

               /* _context = new appvilledbContext();

                var details = _context.TextDetectionHistory.Find(Convert.ToInt32(id));

>>>>>>> 765d73fca5d2119c4a2baa7703e1687dafbbd299
                if (details != null)
                {
                    MailMessage mail = new MailMessage();
                    mail.Body = "Detected Texts are in csv File. Pls Find Attachment";
                    mail.IsBodyHtml = true;
<<<<<<< HEAD


                    mail.To.Add(new MailAddress("nalla@appville.in"));
                    mail.From = new MailAddress("tech@appville.in");
                    mail.To.Add(new MailAddress("nalla@appville.in"));
                    mail.From = new MailAddress("tech@appville.in");
                    mail.To.Add(new MailAddress("appvillecbe@gmail.com"));
                    //mail.To.Add(new MailAddress("nalla@appville.in"));
                    mail.From = new MailAddress("tech@appville.in"); 
=======

                    mail.To.Add(new MailAddress("appvillecbe@gmail.com"));
                    mail.From = new MailAddress("tech@appville.in");

>>>>>>> 765d73fca5d2119c4a2baa7703e1687dafbbd299
                    mail.Subject = "Report Generation Successful";
                    mail.SubjectEncoding = Encoding.UTF8;
                    mail.Priority = MailPriority.Normal;
                    MemoryStream ms = null;

                    //string accessKey = Configuration["ConnectionStrings:AccessKey"];
                    //CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                    //CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                    //string strContainerName = "textdetectionhistorycsv";
                    //CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                    //string fileName = details.csvfilepath.Split('/').LastOrDefault();
                    //if (fileName != null)
                    //{
                    //    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    //    await cloudBlockBlob.FetchAttributesAsync();
                    //    byte[] byteArray = new byte[cloudBlockBlob.Properties.Length];
                    //    var x=await cloudBlockBlob.DownloadToByteArrayAsync(byteArray, 0);
                       // if (byteArray.Length == x)
                        //{
                            //byte[] fileBytes = webClient.DownloadData(details.csvfilepath + "?sv=2018-03-28&ss=bfqt&srt=sco&sp=rwdlacup&se=2019-07-20T18:06:29Z&st=2019-07-20T10:06:29Z&spr=https&sig=tAv45P5VcKBsiwu6hW9RzPkDXTuLkzdSQ9z85wlG3vw%3D");
                           // ms = new MemoryStream(byteArray);
                            Attachment attachment = new Attachment(ms, "TextDetectionReport.csv");
                            mail.Attachments.Add(attachment);

                            SmtpClient smtp = new SmtpClient();
                            smtp.Credentials = new System.Net.NetworkCredential("appville", "App123Ville!");
                            smtp.Host = "smtp.sendgrid.net";
                            smtp.Send(mail);
                            return Ok(new[] { "Success=" + "Mail Sent" });
                        //}
                   // }
                    else
                    {
                        return BadRequest(new[] { "Failure=" + "FileName does not exist" });
                    }
                }
                return BadRequest(new[] { "Failure=" + "Wrong id" });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _context.Dispose();
            }
        }*/


        private async Task<string> UploadFileToBlobAsync(IFormFile file)
        {
            try
            {
                string accessKey = Configuration["ConnectionStrings:AccessKey"];
                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "textdetectionhistory";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                TextDetectionHistory details = new TextDetectionHistory();
                TimeZoneInfo timeZoneInfo;
                DateTime dateTime;
                timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
                string fileName = dateTime.ToString("yyyyMMdd\\THHmmssfff") + "." + "png";
                /* if (await cloudBlobContainer.CreateIfNotExistsAsync())
                 {
                     await cloudBlobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
                 }*/
                if (fileName != null)
                {
                    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    cloudBlockBlob.Properties.ContentType = file.ContentType;
                    await cloudBlockBlob.UploadFromStreamAsync(file.OpenReadStream());
                    return cloudBlockBlob.Uri.AbsoluteUri;
                }
                return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private async Task<string> MakeOCRRequest1(string imageFilePath)
        {
            try
            {
                HttpClient client = new HttpClient();
                const string subscriptionKey = "1fd5bcba017c41aea8a564f79c7b3067";
                const string uriBase =
                  "https://southcentralus.api.cognitive.microsoft.com/vision/v2.0/read/core/asyncBatchAnalyze";

                client.DefaultRequestHeaders.Add(
                    "Ocp-Apim-Subscription-Key", subscriptionKey);

                string uri = uriBase;
                HttpResponseMessage response;
                string operationLocation;               
                string img_url = imageFilePath;              
                byte[] byteData = await GetImageAsByteArray(img_url);
                using (ByteArrayContent content = new ByteArrayContent(byteData))
                {
                    content.Headers.ContentType =
                        new MediaTypeHeaderValue("application/octet-stream");

                    response = await client.PostAsync(uri, content);
                    Console.WriteLine("\nResponse:\n\n{0}\n", response);
                }
                if (response.IsSuccessStatusCode)
                    operationLocation =
                        response.Headers.GetValues("Operation-Location").FirstOrDefault();
                else
                {
                    string errorString = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("\n\nResponse:\n{0}\n",
                        JToken.Parse(errorString).ToString());
                    return JToken.Parse(errorString).ToString();
                }
                string contentString;
                int i = 0;
                do
                {
                    System.Threading.Thread.Sleep(1000);
                    response = await client.GetAsync(operationLocation);
                    contentString = await response.Content.ReadAsStringAsync();
                    ++i;
                }
                while (i < 10 && contentString.IndexOf("\"status\":\"Succeeded\"") == -1);

                if (i == 10 && contentString.IndexOf("\"status\":\"Succeeded\"") == -1)
                {
                    return "\nTimeout error.\n";
                }
                var jsonresponse = JToken.Parse(contentString).ToString();
                return jsonresponse;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private async Task<byte[]> GetImageAsByteArray(string urlImage)
        {
            string accessKey = Configuration["ConnectionStrings:AccessKey"];
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(accessKey);
            CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
            string strContainerName = "textdetectionhistory";
            CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
            string fileName = urlImage.Split('/').LastOrDefault();            
            CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
            await cloudBlockBlob.FetchAttributesAsync();
            var len = cloudBlockBlob.Properties.Length;
            byte[] byteArray = new byte[cloudBlockBlob.Properties.Length];
            await cloudBlockBlob.DownloadToByteArrayAsync(byteArray, 0);
            return byteArray;
        }

        internal class attachements
        {
            public string filepath { get; set; }
            public string fileName { get; set; }
        }

    }
}