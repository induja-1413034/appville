﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using Float_Spot.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MimeKit;
using static Float_Spot.Models.AuthMessageSender;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {                
        public IEmailSender _emailSender;
        public LoginController(IEmailSender emailSender)
        {
            _emailSender = emailSender;
        }
        private appvilledbContext _context;

        [HttpGet]
        public IActionResult Index()
        {
            return Ok("This is Default page");
        }

        /*[HttpGet("Login")]
        public IActionResult Login([FromBody] Login_Table login)
        {
           _context = new appvilledbContext();
           // && x.Password.Equals(login.Password)
           var a = _context.Login_Table.Where(x => x.email_id.Equals(login.email_id)).FirstOrDefault();            
           if (a!=null)
           {
               return Ok("Login Success");
           }
           else { 
            return Ok("Incorrect Username of Password");
           }
       }*/

        /* public HomeController(IEmailService emailService)
         {
             _emailService = emailService;
         }*/

        [HttpPost("usage")]
        public IActionResult usage([FromBody]Usage account_usage)
        {
            try
            {
                _context = new appvilledbContext();
                int count = _context.Login_Table.Where(x => x.email_id.Equals(account_usage.email_id) && x.login_type.Equals(account_usage.login_type) && x.name.Equals(account_usage.name)).Count();
                if (count!=0){
                    int login_id = _context.Login_Table.Where(x => x.email_id.Equals(account_usage.email_id) && x.login_type.Equals(account_usage.login_type) && x.name.Equals(account_usage.name)).Select(y=>y.sno).FirstOrDefault();
                    account_usage.login_id = login_id;
                    account_usage.current_date = DateTime.Now;
                    _context.Usage.Add(account_usage);
                    _context.SaveChanges();
                    return Ok("success");
                }
                else
                {
                    return Ok("Invalid User");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPost("signup")]
        public IActionResult sign_up([FromBody]Login_Table login)
        {
            try { 
                    _context = new appvilledbContext();                    
                    int count = _context.Login_Table.Where(x => x.email_id.Equals(login.email_id) && x.login_type.Equals(login.login_type)&&x.name.Equals(login.name)).Count();
                if (count == 0)
                {
                    try {
                    login.is_verified = true;
                    _context.Login_Table.Add(login);
                    _context.SaveChanges();
                    return Ok(login.sno);
                    }
                    catch (Exception ex)
                    {
                        return BadRequest(ex.Message);
                    }
                }
                else
                {
                    return Ok("Already Registered");
                }
            
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /*if (ModelState.IsValid)
            {
                var user = new IdentityUser { UserName = login.email_id, Email = login.email_id };

                var callbackUrl =
                     Url.Content(
                "macdue-utility.azurewebsites.net/MachineLiveStatus/MachineLiveStatus"
                 );

                await _emailSender.SendEmailAsync(login.email_id, "Confirm your email",
                    $"Please confirm your account by <a href='{callbackUrl}'>clicking here</a>.");
            }*/
    }
}