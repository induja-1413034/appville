﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Float_Spot.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HelpController : ControllerBase
    {
        public ContentResult Index()
        {
            return new ContentResult()
            {
                Content = "<html><body>" +
                "<h1> Signup and Usage</h1>" +
                 "<ul>" +

                   " <li> <b>1. Signup - Mail will be sent to Registered email_id</b>  PostMethod()  FromBody:{\"email_id\":\"induja26.1997\",\"Password\":\"22222\",,\"is_verified\":\"1\"}, https://floatspotserver.azurewebsites.net/api/Home/  (email_id in url) <br><br></li>" +                  
                   " <li> <b>2. Login </b>  GetMethod(), FromBody:{\"email_id\":\"induja26.1997\",\"Password\":\"22222\"}, https://floatspotserver.azurewebsites.net/api/Home/Login  (email_id in url) <br><br></li>" +
                    "<li> <b>3. Changepassword </b>  GetMethod()    FromBody:{\"email_id\":\"induja26.1997\",\"Password\":\"22222\",\"new_Password\":\"1111\"}, https://localhost:44386/api/ChangePassword <br><br></li>" +

                   " <li> <b>1. Signup </b>  PostMethod(), FromBody:{\"email_id\":\"abc@gmail.com\",\"name\":\"test\",\"login_type\":\"google\"}, https://floatspotserver.azurewebsites.net/api/Login/signup  (email_id,name and login_type in url) <br><br></li>" +
                   " <li> <b>2. Usage </b>  PostMethod(), FromBody:{\"email_id\":\"abc@gmail.com\",\"name\":\"test\",\"login_type\":\"google\"}, https://floatspotserver.azurewebsites.net/api/Login/usage  (email_id,name and login_type in url) <br><br></li>" +
                   /* "<li> <b>2. Changepassword </b>  GetMethod()    FromBody:{\"email_id\":\"induja26.1997\",\"Password\":\"22222\",\"new_Password\":\"1111\"}, https://localhost:44386/api/ChangePassword <br><br></li>" +*/

                   
                    "</ul>" +


                   " <li> <b>1. Signup - Mail will be sent to Registered email_id</b>  PostMethod()  FromBody:{\"email_id\":\"induja26.1997\",\"Password\":\"22222\",,\"is_verified\":\"1\"}, https://floatspotserver.azurewebsites.net/api/Home/  (email_id in url) <br><br></li>" +                  
                   " <li> <b>2. Login </b>  GetMethod(), FromBody:{\"email_id\":\"induja26.1997\",\"Password\":\"22222\"}, https://floatspotserver.azurewebsites.net/api/Home/Login  (email_id in url) <br><br></li>" +
                    "<li> <b>3. Changepassword </b>  GetMethod()    FromBody:{\"email_id\":\"induja26.1997\",\"Password\":\"22222\",\"new_Password\":\"1111\"}, https://localhost:44386/api/ChangePassword <br><br></li>" +
                   "</ul>" +


                "<h1> Backup Module:</h1>" +
                 "<ul>" +
                   " <li> <b>1. Upload Backup </b>  PostMethod()<br> <br>FromBody: choose form-data : file=file_want_upload, <br><br> https://floatspotserver.azurewebsites.net/api/FileUpload/hi@gmail.com  (email_id in url) <br><br></li>" +
                   " <li> <b>2. Retriving Backup Files</b>  GetMethod(),<br><br> https://floatspotserver.azurewebsites.net/api/FileUpload/hi@gmail.com  (email_id in url) <br><br></li>" +
                    "</ul>" +
                   
                   "<h1> File Share Module:</h1>" +
                   "<ul>" +
                   " <li> <b>1. Upload Shared Files and save details</b> <br><br> PostMethod()  FromBody: choose form-data : from_mail_id=from@gmail.com, to_mail_id=to@gmail.com, file_to_share=file_want_upload, <br><br>https://floatspotserver.azurewebsites.net/api/FileUpload <br><br></li>" +
                   " <li> <b>2. Getting Shared Messages</b>  GetMethod(),<br><br> https://floatspotserver.azurewebsites.net/api/FileUpload/GetSharedMessage/higi@gmail.com <br><br></li>" +
                   " <li> <b>3. Retriving Exact File</b>  GetMethod(),<br><br> https://floatspotserver.azurewebsites.net/api/FileUpload/Download_file/20190506T122117656.zip   (file_name in url)<br><br></li>" +
                   "</ul>" +
                   "</body></html>",
                ContentType = "text/html",
            };
        }
    }
}