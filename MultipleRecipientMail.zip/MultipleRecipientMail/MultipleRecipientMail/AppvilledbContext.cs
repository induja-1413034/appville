﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace MultipleRecipientMail
{
    public partial class AppvilledbContext : DbContext
    {

        public AppvilledbContext()
        {
        }

        public AppvilledbContext(DbContextOptions<AppvilledbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<MultipleRecipients> MultipleRecipients { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                // optionsBuilder.UseMySql("Server=appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com;Database=appvilledb;user=appville_user;pwd=Appvilleiot1;Convert Zero Datetime=True;");
                optionsBuilder.UseMySql("Server=braiding-new.mysql.database.azure.com;Port=3306;Database=float_spot;Uid=braidinguser@braiding-new;Pwd=123Appville!;Convert Zero Datetime=True;");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<MultipleRecipients>(entity =>
            {
                entity.HasKey(e => e.id);

                entity.ToTable("multiplerecipients");

                entity.Property(e => e.id)
                    .HasColumnName("id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.email)
                    .HasColumnName("email")
                    .HasColumnType("varchar(45)");
            });
        }
    }
}
