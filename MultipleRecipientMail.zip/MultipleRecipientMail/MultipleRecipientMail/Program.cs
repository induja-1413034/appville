﻿using System;
using System.Net;
using System.Net.Mail;
using System.Linq;

namespace MultipleRecipientMail
{
    class Program
    {
        private static AppvilledbContext _context;
        public static void Main(string[] args)
        {
            
            try {

                _context = new AppvilledbContext();
                var details = _context.MultipleRecipients.Select(x => x.email);                                 
                var details1 = details.ToArray();
                for(int i=0;i<details1.Length;i++)
                {
                    Console.WriteLine(details1[i]);
                    MailMessage mail = new MailMessage();
                    mail.Body = "Test";
                    mail.IsBodyHtml = true;
                    //mail.To.Add(new MailAddress("nalla@appville.in"));
                    mail.To.Add(new MailAddress(details1[i]));
                    //mail.From = new MailAddress("tech@appville.in");
                    mail.From = new MailAddress("appvillecbe@gmail.com");
                    mail.Subject = "Multiple Recepients";
                    mail.SubjectEncoding = System.Text.Encoding.UTF8;
                    mail.Priority = MailPriority.Normal;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Credentials = new System.Net.NetworkCredential("appville", "App123Ville!");
                    smtp.Host = "smtp.sendgrid.net";
                    smtp.Send(mail);
                    Console.WriteLine("Mail Sent");
                    System.Threading.Thread.Sleep(30000);
                }                
                Console.ReadLine();            
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }       
    }
}
