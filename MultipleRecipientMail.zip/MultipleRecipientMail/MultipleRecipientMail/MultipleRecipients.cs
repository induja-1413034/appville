﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MultipleRecipientMail
{
    public class MultipleRecipients
    {
        public int id { get; set; }
        public string email { get; set; }
    }
}
