$(function () {
           $('#dat_val1').datetimepicker({
             step: 30,
             format: 'Y-m-d H:i',
             showSeconds: false,      
             //theme:'dark'
           });                    
         });     
         
function SetDate1() {
    var date_from = "";
    if (localStorage.getItem('date_from') != null) {        
        date_from = localStorage.getItem("date_from");    
        sno = localStorage.getItem("SNO");
        console.log(date_from);
    } else {
        var myDate = new Date();
        console.log(myDate);
        var day = myDate.getDate();
        var month = myDate.getMonth() + 1;
        var year = myDate.getFullYear();
        var h = myDate.getHours();
        var m = myDate.getMinutes();
        var s = myDate.getSeconds();
        var ampm = h >= 12 ? 'pm' : 'am';
        if (month < 10) month = "0" + month;
        if (day < 10) day = "0" + day;
        if (h < 10) month = "0" + h;
        if (m < 10) m = "0" + m;
        if (s < 10) s = "0" + s;
        var today = myDate.getFullYear() + "-" + month + "-" + day + "T" + h + ":" + m + ":" + s;       
        var dat1 = today.replace(/T/g, ' ');       
        date_from = dat1;
    }
    document.getElementById('dat_val1').value = date_from;
}

// function LoadPrice(){
     // $.ajax({
        // type: "POST",
        // url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/rem_v1/utl_maintanence_list.php",
        // data: ({			 
            // machine_serial: "UTL002"
        // }),
        // dataType: "json",
        // success: function(JSONObject) {
     
        // }
    // });
// }

function FetchMacDetails() {
	var dat1_orig = $('#dat_val1').val();
    var dat1 = dat1_orig.replace(/T/g, ' ');
	console.log(dat1);

    if (document.getElementById("name").value == "") {
        alert("Please fill Technician Name");
    } else {
        var price = document.getElementById("name").value;
    }    
    $.ajax({
        type: "POST",
        url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/changeprice.php",
        data: ({
			  dt1: dat1,
				price : price
        }),
        dataType: "json",
        success: function(JSONObject) {
    cons
        }
    });
//location.reload();   
FetchMacDetails();
  alert("Data Added Successfully");
}