<?php 
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
      
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $Sno = $_GET['Sno'];
      $phone = $_GET['phone'];
      $name = $_GET['name'];
      $address = $_GET['address'];
      $litres = $_GET['litres'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <link rel="icon" href="/rem_v1/assets/img/favicon.png">
    <title>
         registration-milk
    </title>
    <!--     Fonts and icons     -->
    <meta name="robots" content="noindex, nofollow">
			<link rel="stylesheet" href="registration.css"/>
			<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
			 <script type="text/javascript">
                
				$(document).ready(function(){
                    
				$("#submit").click(function(){
                var org_phone = $("#org_phone").val();    
                var Sno = $("#Sno").val();                 
				var name = $("#name").val();
				var phone = $("#phone").val();
				var address = $("#address").val();
				var consumption = $("#consumption").val();
				phone = phone.replace(/[^0-9]/g,'');
				if( name =='' || phone =='' || address =='' || consumption ==''){
				alert("Please fill all fields...!!!!!!");
				}
				else if (phone.length != 10)
				{
					alert('Phone number must be 10 digits.');
				}
				else {
				$.post("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v2/update_details.php", {
                Sno1: Sno,
				name1: name,
				phone1: phone,
                org_phone1: org_phone,
				address1: address,				
				consumption1:consumption
				}, function(data) {
				if (data == 'SUCCESS') {
				$("form")[0].reset();
				}
				alert(data);
                window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/view_report.php";
				});
				}
				});
				}) ;
			 </script>
		</head>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

  <script type="text/javascript"></script>
  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
</script>
<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 50px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
#submit {
    
   } 
</style>
</head>
<div class="main-panel">
<div class="content">
 <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12 col-sm-6">
                            <div class="card" style=" width: 70%;margin-left: 100px;">
                                <div class="card-header card-header-primary">
                                 <h4 class="card-title ">Customer Details</h4>
                                </div>
                                <div class="card-body">
                                <form class="form" method="post" action="#" id="form">
                                <input type="hidden" name="org_phone" id="org_phone" value="<?php echo $phone; ?>">
                                <input type="hidden" name="Sno" id="Sno" value="<?php echo $Sno; ?>">
                                <!--h2>CUSTOMER DETAILS</h2-->
                                <label>Name :</label>
                                <input type="text" name="dname" id="name" value="<?php echo $name; ?>">
                                <label>PhoneNumber :</label>
                                <input type="text" name="dphone" id="phone" value="<?php echo $phone; ?>">
                                <label>Address :</label>
                                <input type="text" name="daddress" id="address" value="<?php echo $address; ?>">				
                                <label>Consumption :</label>
                                <input type="text" name="dconsumption" id="consumption" value="<?php echo $litres; ?>">
                                <input action="action" onclick="window.history.go(-1); return false;" type="button" style="margin-left: 100px;background-color:purple;color:#fff;border-color:purple;float:left;padding:5px 50px;font-size:17px;border-radius:9px;" id="cancel" value="cancel">
                                <input type="button" name="submit" id="submit" style="margin-right: 100px;background-color:purple;color:#fff;border-color:purple;float:right;padding:5px 50px;font-size:17px;border-radius:9px;" value="submit">
				
                                  </div>
                                 </form>
                                 </div>
                                 
</div>
</div>
</div>
</div>
</div>
 </body>
</html>
