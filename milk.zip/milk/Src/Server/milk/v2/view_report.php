<!DOCTYPE html>
<head>
   <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <!--link rel="icon" href="/rem_v1/assets/img/favicon.png"-->
<title> View Report</title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
  <script type="text/javascript"></script>
  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
    //alert("loading");
  });
</script>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="http://cdn.datatables.net/1.10.16/css/dataTables.jqueryui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript"></script>
<script>
    $(document).ready(function(){
      $('#survey').DataTable( {
       "pageLength": 100
     })
    });
    $(document).ready(function() {
        
        var table = $('#survey').DataTable();
        $('#survey tbody').on( 'click', 'tr', function () {
            if ( $(this).hasClass('selected') ) {
                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        });
        
        $("#survey_wrapper").on("click", ".delete", function(e) {
            if(confirm('Are you sure you want to delete?')){   
            //var phone_id = table.row($('.selected')).data()[0];
            var phoneId = $(e.currentTarget).attr("id");
            phone_id = phoneId.split("_")[1] ? phoneId.split("_")[1] : "";
            $.ajax({url:" http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/delete_milk.php",
                method:"post",
                data: ({ phone:phone_id }),
                // dataType: 'json',
                success: function( data,status,xhr ) {
                    table.row('.selected').remove().draw(false);
                    alert(data);
                }
            });
            }
        });
       $("#survey_wrapper").on("click", ".edit", function(e) {
            var phoneId = $(e.currentTarget).attr("id");
            Sno = phoneId.split("_")[1] ? phoneId.split("_")[1] : "";
            phone_id = phoneId.split("_")[2] ? phoneId.split("_")[2] : "";
            name_id = phoneId.split("_")[3] ? phoneId.split("_")[3] : "";
            address_id = phoneId.split("_")[4] ? phoneId.split("_")[4] : "";
            litres_id = phoneId.split("_")[5] ? phoneId.split("_")[5] : "";
            window.location.href = " http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/edit_milk.php?Sno="+Sno+"&phone="+phone_id+"&name="+name_id+"&address="+address_id+"&litres="+litres_id
       });
       $("#survey_wrapper").on("click", ".billing", function(e) {
            var phoneId = $(e.currentTarget).attr("id");
            phone_id = phoneId.split("_")[1] ? phoneId.split("_")[1] : "";
            window.location.href = " http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/billing.php?phone="+phone_id
        });
    });
            
   </script>
  <script>
  
    function print_page() {
      window.print();
    }
   
  </script>
  <style>
  .se-pre-con {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
</style>
  </head>
 <body class="">
    <div class="se-pre-con"></div>
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="rem_v1/assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
       <div class="logo">
                <a href="/milk/v3/dashboard_milk.php" class="simple-text logo-normal">
                    The Good Cow
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item  ">
                        <a class="nav-link" href="/milk/v3/dashboard_milk.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="/milk/v3/register.php">
                            <i class="material-icons">person</i>
                            <p>Registration</p>
                        </a>
                    </li>
                    <li class="nav-item  active ">
                        <a class="nav-link " href="/milk/v3/view_report.php">
                            <i class="material-icons">content_paste</i>
                            <p>View Report</p>
                        </a>
                    </li>
                    <!--li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/rem_list.php">
                            <i class="material-icons">reorder</i>
                            <p>Remainder List</p>
                        </a>
                    </li-->
                    <!--<li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/icons.html">
                            <i class="material-icons">list</i>
                            <p>Others</p>
                        </a>
                    </li>-->
                    <!--li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/login.html">
                            <i class="material-icons">Logout</i>
                            <p>Logout</p>
                        </a>
                    </li-->
                    
                </ul>
            </div>
        </div>
  <div class="main-panel">
  <div class="content">
  
  <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card" style="width: 90%; margin-left: 50px;">
                                <div class="card-header card-header-primary">
                                <h4 class="card-title ">View Report</h4>
                                </div>
                                <div class="card-body">
  <table id="survey" class="table table-hover ">
    <thead class=" text-primary">
      <tr>
        <th>PHONE</th>
        <th>NAME</th>
        <th>ADDRESS</th>
        <th>LITRES</th>
        <th>EDIT</th>
        <th>DELETE</th>
        <th>BILLING</th>
      </tr>
    </thead>
    <tbody>
      <?php
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $check="select * from milk_survey ";
      $i=0;  
      $rs = mysqli_query($conn, $check);
	//echo mysqli_num_rows($rs);
      while($row = mysqli_fetch_assoc($rs))
      { $Sno= $row['Sno'];
        $phone= $row['phone'];
        $name=$row['name'];
        $address=$row['address'];
        $litres=$row['litres'];
        ?>
        <tr>
          <td ><center><?php echo $phone; ?></center></td>
          <td><center><?php echo $name; ?></center></td>
          <td><center><?php echo $address; ?></center></td>
          <td><center><?php echo $litres; ?></center></td>
          <td ><input type="button" id="edit_<?php echo $Sno; ?>_<?php echo $phone; ?>_<?php echo $name; ?>_<?php echo $address; ?>_<?php echo $litres; ?>" value="EDIT"  class="edit" style="background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;"  ></button></td>
          <td><input type="button" id="delete_<?php echo $phone; ?>" class="delete" value="DELETE" style="background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;"  ></button></td>
          <td><input type="button" id="billing_<?php echo $phone; ?>" class="billing" value="BILLING" style="background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;"  ></button></td>
         
        </tr>  
        <?php 
      }
      mysqli_close($conn);
      ?>
    </tbody>
  </table>
  <p align="right"><input type="button" id="print" value="Print" button onclick="print_page()"></button></p>
  <!--p align="top"><input type="button" id="delete_rows" value="Delete rows"></button></p-->
  </div> 
</div>
</div>
</div>
</div>
</body>
</html>

