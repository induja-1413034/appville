<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$name=$_POST['name1']; // Fetching Values from URL.
$phone=$_POST['phone1'];
$address= $_POST['address1'];
//$street= $_POST['street1'];
//$city= $_POST['city1'];
$consumption= $_POST['consumption1'];
$date_time = date('Y-m-d H:i:s');
$date =date('Y-m-d');
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection

if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 

if(preg_match("/^[0-9]{10}$/", $phone)) {
$check_query="SELECT * FROM milk_customer_det WHERE phone= '$phone'";
$result = mysqli_query($conn,$check_query);
$data=mysqli_num_rows($result);
if(($data)==0)
{
$sql="insert into milk_customer_det(phone,name,address)values('$phone','$name','$address');";
$sql1="insert into milk_litres_det(phone,litres)values('$phone','$consumption');";
$sql2="insert into milk_history_tab(phone,datetime,litres)values('$phone','$date_time','$consumption');";
$sql3="insert into milk_historydat_tab(phone,date,litres)values('$phone','$date','$consumption');";

    
if((mysqli_query($conn,$sql)==TRUE) && (mysqli_query($conn,$sql1)==TRUE) && (mysqli_query($conn,$sql2)==TRUE)&&(mysqli_query($conn,$sql3)==TRUE) ){
	echo "SUCCESS";
}
else{
	echo "Error:".mysqli_error($conn);
}
}
else{
echo "This Number is already registered";
}
}
else{
	echo "phone number should be 10 digits";
	}
mysqli_close($conn);
?>
