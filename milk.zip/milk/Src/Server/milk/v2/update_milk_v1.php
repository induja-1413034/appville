<?php
date_default_timezone_set('Asia/Kolkata');
define('CONST_SERVER_TIMEZONE', 'UTC');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
//$servername="arn:aws:rds:us-east-2:823391985321:db:appvilledb";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$phone=$_GET['phone'];
$litres= $_GET['litres'];
$today_date=date('Y-m-d H:i:s');
$time=date('H:i:s');
//echo $time;
$conn =mysqli_connect($servername,$username, $password,$dbname) ;
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 
if($time<'15:30:00')
	{
		$check="select *from milk_customer_det where phone='$phone'";
		//echo $check;
		$res=mysqli_query($conn,$check);
		$data=mysqli_num_rows($res);
		if(($data)==1)
		{
		
			$sql="update milk_litres_det set litres='$litres' where phone='$phone'";
			$sql1="insert into milk_history_tab(phone,litres,datetime)values('$phone','$litres','$today_date');";
			if((mysqli_query($conn,$sql) == TRUE)&&(mysqli_query($conn,$sql1) == TRUE))
			{
				echo "OK";
			}

			else
			{
				echo "Error:?? " .$conn->error;
			}
		}
		else
		{
			echo "Error:Number not registered";
		}
	}
	else
	{
        //ToDO: error for time cut off should be done.
		//echo "Error: Cannot update values after 3.30";
        $check="select *from milk_customer_det where phone='$phone'";
		//echo $check;
		$res=mysqli_query($conn,$check);
		$data=mysqli_num_rows($res);
		if(($data)==1)
		{
		
			$sql="update milk_litres_det set litres='$litres' where phone='$phone'";
			$sql1="insert into milk_history_tab(phone,litres,datetime)values('$phone','$litres','$today_date');";
			if((mysqli_query($conn,$sql) == TRUE)&&(mysqli_query($conn,$sql1) == TRUE))
			{
				echo "OK";
			}

			else
			{
				echo "Error:?? " .$conn->error;
			}
		}
		else
		{
			echo "Error:Number not registered";
		}
	}
	mysqli_close($conn);
	?>
