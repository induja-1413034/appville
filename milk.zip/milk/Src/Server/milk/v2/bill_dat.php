<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$dt1= $_GET['dt1'];
$dt2= $_GET['dt2'];
$date_time = date('Y-m-d H:i:s');
$phone =$_GET['phone']; 
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}
    
   $sql = "call appvilledb.all_billing('$dt1', '$dt2');";
   echo $sql;
    
    if((mysqli_query($conn,$sql)==TRUE))
    {
        echo "success";
    }
    else
    {
        echo "Error :".mysqli_error($conn);
    }


    $bill_dat = "call appvilledb.billing_proc('$phone');";
    echo $bill_dat;
    $res = mysqli_query($conn,$bill_dat);
    if(($res==TRUE))
    {
        echo "success";
    }
    else
    {
        echo "Error:".mysqli_error($conn);
    }
       // $row = mysqli_fetch_assoc($bill_dat);

    ?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="/assets/img/apple-icon.png">
    <link rel="icon" href="/assets/img/favicon.png">
    <title>
         Error calculation
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <!-- Documentation extras -->
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

  <script type="text/javascript"></script>
  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
</script>
<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
</style>
</head>
<body class=" ">
  <div class="se-pre-con"></div>
  <div class="wrapper">
    <div class="main-panel">
  <div class="container"> 
  
  
<div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title ">Billing calculation</h4>
                                    <p class="card-category"> Here is the updated litres</p>
                                </div>
                                <div class="card-body">
                                    <!--<div class="table-responsive">-->
     <table class="table table-hover">
     <thead class=" text-primary">
      <tr>
        <th><center>SNO</center></th>
        <th><center>DATE</center></th>
        <th><center>LITRES</center></th>
      </tr>
    </thead>
    <tbody>
     <?php

      $query_sel = "select * from temp_billing";  
      $rs_err_split = mysqli_query($conn, $query_sel);
       //$prev_err = '-1';
      $prev_lit = 0;
       while($row = mysqli_fetch_array($rs_err_split))
      {
        $curr_lit = $row['litres'];
        if($curr_lit !=null)
        {
          $prev_lit = $curr_lit;
        }
        $sno = $row['sno'];
        $date_val = $row['date_val'];
        $litres = $row['litres'];
        echo $litres;
        //echo 'pre'.$prev_lit."</br>";
        //echo 'curr'.$curr_lit."</br>";
        //echo 'sno '.$sno."</br>" ;
        //echo 'ltr'.$litres;
        $update_lit ="update temp_billing set litres = '$prev_lit' where sno ='$sno'";
       // echo $update_lit;
      }

    if((mysqli_query($conn,$update_lit)==TRUE))
    {
        echo "success";
    }
    else
    {
        echo "Error :".mysqli_error($conn);
      }
    
?>  <tr>
          <td><center><?php echo $sno; ?></center></td>
          <td><center><?php echo $date_val; ?></center></td>
          <td><center><?php echo $litres; ?></center></td>
        </tr>
        <?php 
      mysqli_close($conn);
      ?>
    </tbody>
  </table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
  <div id="line_top_x"></div>
</body>
</html>