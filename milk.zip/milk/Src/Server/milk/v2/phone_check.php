
<?php
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$get_phone=$_GET['phone'];
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 
$check_query="SELECT * FROM milk_customer_det WHERE phone= '$get_phone'";
$result = mysqli_query($conn,$check_query);
$data=mysqli_num_rows($result);
if(($data)==1)
{
	echo "OK";
}
else
{
	echo "Error:-Phone number not registered";
}
mysqli_close($conn);
	?>