<?php
    date_default_timezone_set('Asia/Kolkata');
    $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
    $username = "appville_user";
    $password = "Appvilleiot1";
    $dbname = "appvilledb";
    //$Sno=$_POST['Sno1'];
   // $name=$_POST['name1']; // Fetching Values from URL.
    $phone=$_GET['phone'];
    //$org_phone=$_GET['org_phone1'];
    //$address= $_POST['address1'];
    $consumption= $_GET['consumption'];
    $date_time = date('Y-m-d H:i:s');
    $date= date('Y-m-d');
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
$check_query="SELECT * FROM milk_customer_det WHERE phone= '$phone'";
$result = mysqli_query($conn,$check_query);
$data=mysqli_num_rows($result);
if(($data)==1)
{
    echo "OK";

    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
                if(preg_match("/^[0-9]{10}$/", $phone)) {

            $result= "insert into milk_history_tab(phone,datetime,litres) values ('$phone','$date_time','$consumption');";
          
            if((mysqli_query($conn,$result)==TRUE)){
                echo "SUCCESS";
            }
            else
            {
                echo "Error:".mysqli_error($conn);
            }
            $qry = "select * from milk_historydat_tab where date_val='$date' and phone ='$phone'";
           // echo $qry;
            $result = mysqli_query($conn,$qry);
            $check= mysqli_num_rows($result);
            if(($check)==0)
            {
                $res2= "insert into milk_historydat_tab(phone,date_val,litres) values('$phone','$date','$consumption');";
                if((mysqli_query($conn,$res2)==TRUE))
                {
                    echo "Insert Success";
                }
                else
                {
                    echo "Error:".mysqli_error($conn);

                }
            }
            else
            {
                $row = mysqli_fetch_array($result);
                $sno =$row['sno'];
                //echo $sno;
                $upd_qry= "update milk_historydat_tab set litres='$consumption',date_val='$date' where sno='$sno'";
                if((mysqli_query($conn,$upd_qry)==TRUE))
                {
                    echo "Update Success";
                }
                else
                {
                    echo "Error:".mysqli_error($conn);
                    
                }
            
            }
            $sql2="update milk_litres_det set phone='$phone',litres='$consumption' where phone='$phone'";
            if(mysqli_query($conn,$sql2)==TRUE) {
                echo "SUCCESS";
            }
        else{
            echo "Error:".mysqli_error($conn);
        }
    }

    else
    {
        echo "phone number is not 10 digits";
    }
}
else
{
    echo "Error:-Phone number not registered";
}

        
    mysqli_close($conn);
    ?>

