<?php
// Check connection
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username   = "appville_user";
$password   = "Appvilleiot1";
$dbname     = "appvilledb";
$dt1        = $_REQUEST['dt1'];
$dt2        = $_REQUEST['dt2'];
$phone      = $_REQUEST['phone'];
$total_sum  = 0;
$date_time  = date('Y-m-d H:i:s');
$conn       = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sum_qry = "select litres,price,litres*price as total_ltr_price,sum(litres) as tot_ltr from milk_bill where phone='$phone'and date>='$dt1' and date<='$dt2'";
$res_sum = mysqli_query($conn,$sum_qry);
while($row = mysqli_fetch_assoc($res_sum))
{
$tot_array['tot_ltr'] = $row['tot_ltr'];	
$total_ltr_price = $row["total_ltr_price"];
$total_sum = $total_ltr_price+$total_sum;
$tot_array['total_ltr_price'] = $total_sum;
}
$json_arr[] = $tot_array;
print json_encode($json_arr);
mysqli_close($conn);
?>