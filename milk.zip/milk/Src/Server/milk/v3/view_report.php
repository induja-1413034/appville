<!DOCTYPE html>
<head>
   <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <!--link rel="icon" href="/rem_v1/assets/img/favicon.png"-->
<title> View Report</title>
    <!--     Fonts and icons     -->
	
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="http://cdn.datatables.net/1.10.16/css/dataTables.jqueryui.css"> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="report_view.js"></script>
<!--script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

<!--Notifications-->

  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <!--script src="/milk/v4/assets/js/material-dashboard.js?v=2.1.1" type="text/javascript"></script>
<!--End of Notifications -->  
  
  <script type="text/javascript"></script>
  <script>
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
  });
  
// activate collapse right menu when the windows is resized

md = {
  misc: {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
  },

  checkSidebarImage: function() {
    $sidebar = $('.sidebar');
    image_src = $sidebar.data('image');

    if (image_src !== undefined) {
      sidebar_container = '<div class="sidebar-background" style="background-image: url(' + image_src + ') "/>';
      $sidebar.append(sidebar_container);
    }
  },

  showNotification: function(from, align) {
    type = ['', 'info', 'danger', 'success', 'warning', 'rose', 'primary'];

    color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: "add_alert",
      message: "Deleted successfully"

    }, {
      type: type[color],
      timer: 3000,
      placement: {
        from: from,
        align: align
      }
    });
  }
}	
	
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }
      });
    });
  
</script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
	   <!--script src="/milk/v4/assets/js/core/jquery.min.js"></script-->
	<script src="/milk/v4/assets/js/plugins/bootstrap-notify.js"></script> 
 
    
	
<script>


  /*  $(document).ready(function(){
      $('#survey').DataTable( {
      // "pageLength": 100
       "lengthMenu": [[-1, 25, 50, 10], ["All", 25, 50, 10]]

     })
    });*/
	
	
    /*$(document).ready(function() {
        
        var table = $('#survey').DataTable();
        $('#survey tbody').on( 'click', 'tr', function () {
            if ( $(this).hasClass('selected') ) {
                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        });
		});*/
        
    /*    $("#survey_wrapper").on("click", ".delete", function(e) {
            if(confirm('Are you sure you want to delete?')){   
            //var phone_id = table.row($('.selected')).data()[0];
            var phoneId = $(e.currentTarget).attr("id");
            phone_id = phoneId.split("_")[1] ? phoneId.split("_")[1] : "";
            $.ajax({url:" http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/delete_milk.php",
                method:"post",
                data: ({ phone:phone_id }),
                // dataType: 'json',
                success: function( data,status,xhr ) {
                    table.row('.selected').remove().draw(false);
				    md.showNotification('top','center');
                    //alert(data);
					/*$(document).ready(function(){
				    $('[data-toggle="popover"]').popover(); 
					});*/
             /*   }
            });
            }
        });*/
		
     /*  $("#survey_wrapper").on("click", ".edit", function(e) {
            var phoneId = $(e.currentTarget).attr("id");
            Sno = phoneId.split("_")[1] ? phoneId.split("_")[1] : "";
            phone_id = phoneId.split("_")[2] ? phoneId.split("_")[2] : "";
            name_id = phoneId.split("_")[3] ? phoneId.split("_")[3] : "";
            address_id = phoneId.split("_")[4] ? phoneId.split("_")[4] : "";
            litres_id = phoneId.split("_")[5] ? phoneId.split("_")[5] : "";
            zone_id = phoneId.split("_")[6] ? phoneId.split("_")[6]: "";
             zone_val = phoneId.split("_")[7] ? phoneId.split("_")[7]: "";
			 amount_paid =  phoneId.split("_")[8] ? phoneId.split("_")[8]: "";
			 date_of_pay = phoneId.split("_")[9] ? phoneId.split("_")[9]: "";
            window.location.href = " http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/edit_milk.php?Sno="+Sno+"&phone="+phone_id+"&name="+name_id+"&address="+address_id+"&litres="+litres_id+"&zone_id="+zone_id+"&zone="+zone_val+"&amount_paid="+amount_paid+"&date_of_pay="+date_of_pay;
       });*/
	   
      /* $("#survey_wrapper").on("click", ".billing", function(e) {
            var phoneId = $(e.currentTarget).attr("id");
            phone_id = phoneId.split("_")[1] ? phoneId.split("_")[1] : "";
            name= phoneId.split("_")[2] ? phoneId.split("_")[2] : "";
            window.location.href = " http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/bill_dat.php?phone="+phone_id+"&name="+name
        });
    });*/
            
   </script>
  <script>
  function optionSelect()
  {
 var e = document.getElementById("zone");
var zone = e.options[e.selectedIndex].value;

 window.open("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/print_tab.php?zone="+zone);

  }
    function print_page() {
      window.print();
    }
   
  </script>
  
  <style>
  .se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
</style>
  </head>
 <body class="" >
 <body onload = "report();">
    <div class="se-pre-con"></div>
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="rem_v1/assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
       <div class="logo">
                <a href="/milk/v3/dashboard_milk.php" class="simple-text logo-normal">
                    The Good Cow
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/milk/v3/dashboard_milk.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/milk/v3/register.php">
                            <i class="material-icons">person</i>
                            <p>Registration</p>
                        </a>
                    </li>
                    <li class="nav-item  active ">
                        <a class="nav-link " href="/milk/v3/view_report.php">
                            <i class="material-icons">content_paste</i>
                            <p>View Report</p>
                        </a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link " href="/milk/v3/changeprice.html">
                            <i class="material-icons">settings</i>
                            <p>Settings</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
  <div class="main-panel">
  <div class="content">
  
  <div class="container-fluid">

<center>
<label>Zone:</label>


<!-- use https://www.plus2net.com/php_tutorial/list-table.php-- for drop down list><!--input type ="text" list="zone" name="zone" id="zones"-->
<select name = "zone" id="zone">
<option>All zones</option>
  <option value="10">Alipur</option>
  <option value="11">Ballygunge</option>
  <option value="12">salt lake</option>
  <option value="13">Camac street</option>
  <option value="14">Garia</option>
    <option value="15">Kakurgachi</option>
      <option value="16">Hastings</option>


</select>
</center>
<!--p><input type = "button" onclick = "optionSelect()"> OK</button></p-->
  <p align="center"><input type="button" id="click" value="VIEW" button onclick="optionSelect()"></button></p>
 <!--div class="col-md-4">
 <button class="btn btn-primary btn-block" onclick="md.showNotification('top','center')">Top Center</button>
 </div-->

                    <div class="row">
                        <div class="col-md-12">
                            <div class="card" style="width: 90%; margin-left: 50px;">
                                <div class="card-header card-header-primary">
                                <h4 class="card-title ">View Report</h4>
                                </div>
                                <div class="card-body">
  <table id="survey" class="table table-hover ">
    <thead class=" text-primary">
      <tr>
        <th>PHONE</th>
        <th>NAME</th>
        <th>ADDRESS</th>
        <th>LITRES</th>
        <th>ZONE</th>
		<th>AMOUNT PAID</th>
		<th>PAID DATE</th>
         <th>Tot Lit</th>
        <th>Tot Amnt</th>
        <th> </th>
        <th> </th>
        <th> </th>
		<th style="display:none;">Zone id</th>
       
      </tr>
    </thead>
    <tbody>
     
       
    </tbody>
  </table>
  <p align="right"><input type="button" id="print" value="Print" button onclick="print_page()"></button></p>
  <!--p align="top"><input type="button" id="delete_rows" value="Delete rows"></button></p-->
  </div> 
</div>
</div>
</div>
</div>
</body>
</html>





