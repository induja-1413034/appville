 <!--?php
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $phone =$_GET['phone'];
      // $check="select datetime,litres from milk_history_tab where phone='$phone' "; 
      // $rs = mysqli_query($conn, $check);
      // ?-->
<!DOCTYPE html>
<head>
   <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <title> View Report</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
  <script type="text/javascript"></script>
  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
    //alert("loading");
     });
  
var phone=  getParameter('phone');
  //alert(phone);
   function getParameter(theParameter) { 
  var params = window.location.search.substr(1).split('&');
 
  for (var i = 0; i < params.length; i++) {
    var p=params[i].split('=');
	if (p[0] == theParameter) {
	  return decodeURIComponent(p[1]);
	}
  }
  return false;
}

   function billing(phone)
  {     // var queryString = url ? url.split('?')[1] : window.location.search.slice(1);
        var dat1 = document.getElementById("dat_val1").value;
     //var dat1 = dat1_orig.replace(/T/g,' ');
    var dat2 = document.getElementById("dat_val2").value;
    load_table(dat1,dat2,phone);
    //var dat2 = dat2_orig.replace(/T/g,' ');"
    // var popup = window.open("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/billing.php?phone="+<!--?php echo $phone ?-->, '_self', '');
     // popup.close();
    // var url="http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/tot_bill.php?dt1="+dat1+"&dt2="+dat2+"&phone="+<!--?php echo $phone ?-->;
     // window.open( url);
     tot_amount(dat1,dat2,phone);
     }
     function tot_amount(dat1,dat2,phone)
     {
       $(document).ready(function(){
        $.ajax({
		    type: "POST",
            url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/tot_bill.php",
            data: ({dt1:dat1,
            dt2:dat2,
            phone : phone
            }),
            dataType: "json",
            success: function (JSONObject) {
                JSONObject.forEach(function(json) { // <--- pass a function to forEach that takes a single object. This is called for every object in the array
                var total_ltr = json.total_ltr;
                document.getElementById("amount").innerHTML = total_ltr;
                });
            }
        });
        });
     }
 </script >
  </head>
 <body class="">
    <div class ="se-pre-con"></div>
    <div class="wrapper">
      <div class="main-panel">
  <div class="container"> 
      <div class='centered' >
      <h2><b>Billing Report</b></h2>  
         <table><tr>
           <th>FROM:</th>
          <td>
          	<!--<input type="datetime-local" name="bdaytime">-->
        <input type="date" id='dat_val1' placeholder="Enter Date1 (YYYY-MM-DD HH:mm:ss)" class="form-control" name="datefilter1" >
        </td>
        <th>TO:</th>
        <td>
        <input type="date" id='dat_val2' placeholder="Enter Date2 (YYYY-MM-DD HH:mm:ss)" class="form-control" name="datefilter2" >
         </td>
           <td>
         <button type="submit" class="btn btn-info" onclick="billing(phone)">Apply</button>         
        </td></tr>

        </table>
        <br/>
                       <h2>Total Amount of litres: <a id="amount"></a></h2>
                        <br/>
         </div>
<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  margin-left: 410px;
  margin-bottom:20px;
  width: 100px;
  height: 100px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;  
}

.hid
{
  display: none;
}
.centered{
  width:500px;
  margin:0 auto;
  
}
.centered_btn{
  width:150px;
  margin:0 auto;
}
label {
    display: inline-block;
    margin-bottom: 1em;
    color : #cc65fe;
    <!--margin-left:50px;-->
}
/*h2{
    color : #cc65fe;
}*/
input[type=text] {
    border: 1px solid black;
float: left;
margin: 0;
padding: 0;
padding-right:20px;
border-top: 0px;
border-left: 0px;
border-right: 0px;

}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
<div style="width:900px;">
 <div class="container"> 
  <div class="main-panel">
  <div class="content">
  
  <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card" style="width: 90%; margin-left: 50px;">
                                <div class="card-header card-header-primary">
                                <h4 class="card-title ">Billing</h4>
                                </div>
                                <div class="card-body">
  <table id="survey" class="table table-hover ">
    <thead class=" text-primary">
      <tr>
        <th><center>DATETIME</center></th>
        <th><center>LITRES<center></th>
      </tr>
    </thead>
    <tbody>
    
    </tbody>
  </table>
  <script type="text/javascript">
    function load_table(dt1,dt2,phone)
    {
     $(document).ready(function(){
        $.ajax({
		    type: "POST",
            url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/billing_json.php",
            data: ({dt1:dt1,
            dt2:dt2,
            phone:phone
            }),
            dataType: "json",
            success: function (JSONObject) {
                
                //data=json.parse(JSONObject);
                var tabhtml = "";
                for(var key in JSONObject){
                  if(JSONObject.hasOwnProperty(key)){
                      //tot_hours = "hours":"minutes":"seconds"
                      tabhtml +="<tr>";
                      tabhtml +="<td>"+ JSONObject[key]["datetime"]+"</td>";
                      tabhtml +="<td>"+ JSONObject[key]["litres"]+"</td>";
                      tabhtml +="</tr>";
                   }
                     //console.log(JSONresponse);
                  }
                   $("#survey tbody").html(tabhtml);
                   
                   
            }
     });
    });
    }
    </script>
  
  </div> 
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>  
