<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
$phone = $_REQUEST["phone"];
$data_array = array();
$json_arr = array();
//echo $phone;
$sql = "select * from milk_survey_bill where phone='$phone'";
$qry = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($qry))
{
    $data_array["address"] = $row['address'];
    $data_array["phone"] = $row['phone'];
    $data_array["zone"] = $row['zone'];
    $data_array["name"] = $row['name'];
	 $data_array["litres"] = $row['litres'];
    $data_array["zone_id"] = $row['zone_id'];
	 $json_arr[] =$data_array;

      }
 
 print json_encode($json_arr); 

/*$name = $_REQUEST["name"];
$address = $_REQUEST["address"];
$litres = $_REQUEST["litres"];
$zone = $_REQUEST["zone"];
$zone_id = $_REQUEST["zone_id"];

/*$_SESSION["phone"]=$phone;
$_SESSION["name"]=$name;
$_SESSION["address"]=$address;
$_SESSION["litres"]=$litres;
$_SESSION["zone"]=$zone;
$_SESSION["zone_id"]=$zone_id;
/*echo $_SESSION["phone"];
echo $_SESSION["name"];
echo $_SESSION["address"];
echo $_SESSION["litres"];
echo $_SESSION["zone"];*/
mysqli_close($conn);
?>