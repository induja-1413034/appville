<?php
// Check connection
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username   = "appville_user";
$password   = "Appvilleiot1";
$dbname     = "appvilledb";
$dt1        = $_REQUEST['dt1'];
$dt2        = $_REQUEST['dt2'];
$phone      = $_REQUEST['phone'];
$total_sum  = 0;
$date_time  = date('Y-m-d H:i:s');
$conn       = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query_sel    = "select litres,phone,date,price,litres * price as total from milk_bill where phone = '$phone' and date>='$dt1' and date<='$dt2'";
$rs_err_split = mysqli_query($conn, $query_sel);
$json_arr     = array();
$data_array   = array();
$tot_array    = array();
$prev_lit     = 0;
while ($row = mysqli_fetch_array($rs_err_split)) {
     $data_array["date_val"] = $row["date"];
	 $data_array["litres"] = $row['litres'];
	 $data_array["price"] = $row["price"];
	 $data_array["total"] = $row['total'];
	 $json_arr[] = $data_array;
}
print json_encode($json_arr);
mysqli_close($conn);

?>
