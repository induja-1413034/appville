<?php
date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
      
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $date = '2018-07-01';
      $sel = "select phone,litres from milk_survey";
      $sel1 = "select phone ,litres from milk_history_tab";
      if(mysqli_query($conn,$sel)==TRUE)
      {
      	//echo "success";
      }
      else

      {
      	//echo "Error".mysqli_error($conn);
      }
      $result = mysqli_query($conn,$sel);
      $result1 = mysqli_query($conn,$sel1);
      //$chk = 
       while($row = mysqli_fetch_array($result))
            {

            $phone = $row["phone"];
            $consumption = $row["litres"];
            //echo $phone;
            $flag=0;
               while($rows = mysqli_fetch_array($result1))
            {

            $phone1 = $rows["phone"];
            $consumption1 = $rows["litres"];
            //echo $phone1;
            if($phone == $phone1)
            {
            	//echo "phone".$phone;
            	//echo "phone1".$phone;
           $flag =1;
           break;
        }

        }
         //   echo "phone".$phone."<br/>";
           // echo "litres".$consumption."<br/>";

            if($flag==0)
           {
                $res1= "insert into milk_history_tab(phone,datetime,litres) values('$phone','$date','$consumption');";
                echo $res1;
                $res2= "insert into milk_historydat_tab(phone,date_val,litres) values('$phone','$date','$consumption');";
                
                if((mysqli_query($conn,$res1)==TRUE)&&(mysqli_query($conn,$res2)==TRUE))

                {
                    echo "Success";
                }
                else
                {
                    echo "Error:".mysqli_error($conn);

                }

             }
         
     }
         

         mysqli_close($conn);

?>