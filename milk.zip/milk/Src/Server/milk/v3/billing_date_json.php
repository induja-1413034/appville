<?php
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $dt1= $_REQUEST['dt1'];
      $dt2= $_REQUEST['dt2'];
      $phone =$_REQUEST['phone'];
      
      $check="select date,litres from milk_bill where phone='$phone' and date>='$dt1' and date<='$dt2'"; 
      $rs = mysqli_query($conn, $check);
      $json_arr = array();
      $data_array=array();
      
      while($row=mysqli_fetch_assoc($rs))
      {
         $data_array["date_val"]= $row["date"];
         $data_array["litres"]= $row["litres"]; 
         $json_arr[] =$data_array; 
      }
      print json_encode($json_arr) ;
     //print $json_arr;
      mysqli_close($conn);
    ?>      