<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$dt1= $_POST['dt1'];
$dt2= $_POST['dt2'];
$date_time = date('Y-m-d H:i:s');
$phone =$_POST['phone']; 

//$dt2= $_GET['dt2'];
//$phone =$_GET['phone']; 
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 

$sql = "call appvilledb.all_billing('$dt1', '$dt2');";
  // echo $sql;
    
    if((mysqli_query($conn,$sql)==TRUE))
    {
        //echo "success";
    }
    else
    {
        echo "Error :".mysqli_error($conn);
    }


    $bill_dat = "call appvilledb.billing_proc('$phone');";
   // echo $bill_dat;
    $res = mysqli_query($conn,$bill_dat);
    if(($res==TRUE))
    {
        //echo "success";
    }
    else
    {
        echo "Error:".mysqli_error($conn);
    }
       // $row = mysqli_fetch_assoc($bill_dat);


$query_sel = "select * from temp_billing";  
      $rs_err_split = mysqli_query($conn, $query_sel);
       //$prev_err = '-1';
      $json_arr = array();
      $data_array=array();
      $prev_lit = 0;
      $tot_lit=0;
       while($row = mysqli_fetch_array($rs_err_split))
      {
        $curr_lit = $row['litres'];
        if($curr_lit !=null)
        {
          $prev_lit = $curr_lit;
        }
       // $sno = $row["sno"];

        //$data_array["sno"] = $sno;
        //$data_array["date_val"] = $row["date_val"];
        //$data_array["litres"] = $prev_lit;

$tot_lit = $tot_lit+$prev_lit;
}
//$data_array["total_ltr"] =$tot_lit;

        //$json_arr[] = $data_array;

        //echo $litres;
        //echo 'pre'.$prev_lit."</br>";
        //echo 'curr'.$curr_lit."</br>";
        //echo 'sno '.$sno."</br>" ;
        //echo 'ltr'.$litres;
        //$update_lit ="update temp_billing set litres = '$prev_lit' where sno ='$sno'";    

//$sum_qry = "select sum(litres) as total_ltr from temp_billing";

//$res_sum = mysqli_query($conn,$sum_qry);
//$row = mysqli_fetch_assoc($res_sum);
//$litre = $row["total_ltr"];
$json_arr = array();
      $data_array=array();
     $data_array["total_ltr"] = $tot_lit;
      $json_arr[] = $data_array;


//print json_encode($data_array["total_ltr"];
print json_encode($json_arr);
mysqli_close($conn);
    
?>



