<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <link rel="icon" href="/rem_v1/assets/img/favicon.png">
    <title>
         Customer Details
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="rem_v1/assets/css/material-dashboard.css?v=2.0.0">
    <!-- Documentation extras -->
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="rem_v1/assets/assets-for-demo/demo.css" rel="stylesheet" />

    <!-- iframe removal -->
</head>

<body class="">
    
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="rem_v1/assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="logo">
                <a href="/rem_v1/dashboard.php" class="simple-text logo-normal">
                    Mac Due
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item  ">
                        <a class="nav-link" href="/rem_v1/dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/rem_v1/customer_det.php">
                            <i class="material-icons">person</i>
                            <p>Customer List</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/model_li.php">
                            <i class="material-icons">content_paste</i>
                            <p>Model List</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/rem_list.php">
                            <i class="material-icons">reorder</i>
                            <p>Remainder List</p>
                        </a>
                    </li>
                    <!--<li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/icons.html">
                            <i class="material-icons">list</i>
                            <p>Others</p>
                        </a>
                    </li>-->
                    <li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/login.html">
                            <i class="material-icons">Logout</i>
                            <p>Logout</p>
                        </a>
                    </li>
                    
                </ul>
            </div>
        </div>
<div class="main-panel">
<div class="content">
    <!--<div class="md-layout">
      <div class="md-layout-item md-medium-size-100 md-xsmall-size-100 md-size-100">
        <md-card>
          <md-card-header data-background-color="green">
            <h4 class="title">Simple Table</h4>
            <p class="category">Here is a subtitle for this table</p>
          </md-card-header>
          <md-card-content>
            <simple-table table-header-color="green"></simple-table>
          </md-card-content>
        </md-card>
      </div>-->

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title ">List of customers</h4>
                                    <p class="card-category"> Here is the list of various customers</p>
                                </div>
                                <div class="card-body">
                                    <!--<div class="table-responsive">-->
     <table class="table table-hover">
     <thead class=" text-primary">
      <tr>
        <th>NAME</th>
        <th>ADDRESS</th>
        <th>MAIL</th>
        <th>PHONE</th>
      </tr>
    </thead>
    <tbody>
      <?php
      date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $check="SELECT cli_id,name,address,mail,phone FROM appvilledb.rem_cli_det";
      $i=0;
      $rs = mysqli_query($conn, $check);
  //echo mysqli_num_rows($rs);
      while($row = mysqli_fetch_assoc($rs))
      {
        $cli_id       = $row['cli_id'];
        $name    = $row['name'];
        $address=$row['address'];
        $mail = $row['mail'];
        $phone    = $row['phone'];
      
        ?>
        <tr onclick="window.location='http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/rem_v1/cli_mac_list.php?cli_id=<?php echo $cli_id ?>'"> 
          <td><?php echo $name; ?></td>
          <td><?php echo $address; ?></td>
          <td><?php echo $mail; ?></td>
          <td><?php echo $phone; ?></td>
        </tr>
        <?php 
      }
      mysqli_close($conn);
      ?>
    </tbody>
  </table>
 </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
 </body>
</html>
  
