<?php
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $phone =$_GET['phone'];
      $check="select datetime,litres from milk_history_tab where phone='$phone' "; 
      $rs = mysqli_query($conn, $check);
      $json_arr = array();
      $data_array=array();
      
      while($row=mysqli_fetch_assoc($rs))
      {
         $data_array["datetime"]= $row["datetime"];
         $data_array["litres"]= $row["litres"]; 
         $json_arr[] =$data_array; 
      }
      print json_encode($json_arr) ;
     //print $json_arr;
      mysqli_close($conn);
    ?>      