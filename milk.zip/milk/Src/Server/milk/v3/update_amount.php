<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username   = "appville_user";
$password   = "Appvilleiot1";
$dbname     = "appvilledb";
//$Sno=$_POST['Sno1'];
// Fetching Values from URL.
$phone      = $_REQUEST['phone1'];
//$org_phone = $_REQUEST['org_phone1'];
$amount     = $_REQUEST['amount'];
$date_time  = date('Y-m-d H:i:s');
$date       = date('Y-m-d');
$conn       = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// $time = date('h:i:s');
//echo $time;
if (preg_match("/^[0-9]{10}$/", $phone)) {
    $sql2 = "update milk_amount_pay set amount_paid='$amount' and date_of_pay='$date_time' where phone='$phone'";
    //$sql4 = "update milk_historydat_tab set phone='$phone' where phone='$org_phone'";
    
    if ((mysqli_query($conn, $sql2) == true)) {
        echo "SUCCES";
    } else {
        echo "Error:" . mysqli_error($conn);
        
    }
} else {
    echo "phone number should be 10 digits";
}
mysqli_close($conn);
?>