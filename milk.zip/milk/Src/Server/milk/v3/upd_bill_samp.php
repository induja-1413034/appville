<?php
//TODO: 
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$today = date('Y-m-d');
$conn = mysqli_connect($servername, $username, $password, $dbname);
$upd_qry = "SELECT * FROM appvilledb.milk_history_tab;";
$upd_sql = mysqli_query($conn,$upd_qry);
while($row = mysqli_fetch_assoc($upd_sql))
{
      $litres = $row['litres'];
	  $phone = $row['phone'];	
$sql = "update milk_customer_det set litres = '$litres' where phone='$phone'";
$qry = mysqli_query($conn,$sql);
if($qry==TRUE)
{
	echo "success";
}
else
{
	echo "error";
}
}
mysqli_close($conn);
?>