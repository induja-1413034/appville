<?php 
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
      
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      //$Sno = $_GET['Sno'];
     $phone = $_GET['phone'];
  /*    $name = $_GET['name'];
      $address = $_GET['address'];
      $litres = $_GET['litres'];
      $zone = $_GET['zone'];
//echo $zone;
      $zone_id = $_GET['zone_id'];
	 // echo $zone_id;
	  //$amount = $_GET['amount_paid'];*/

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <link rel="icon" href="/rem_v1/assets/img/favicon.png">
    <title>
         Edit-milk
    </title>
    <!--     Fonts and icons     -->
    <meta name="robots" content="noindex, nofollow">
			<link rel="stylesheet" href="registration.css"/>
			<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	 <input type="hidden" id="ph" name="custId" value="<?php echo $phone; ?>">
	<script>
		
	</script>
			 <script type="text/javascript">
			   md = {
  misc: {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
  },

  checkSidebarImage: function() {
    $sidebar = $('.sidebar');
    image_src = $sidebar.data('image');

    if (image_src !== undefined) {
      sidebar_container = '<div class="sidebar-background" style="background-image: url(' + image_src + ') "/>';
      $sidebar.append(sidebar_container);
    }
  },

  showNotification: function(from, align) {
    type = ['', 'info', 'danger', 'success', 'warning', 'rose', 'primary'];

    color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: "add_alert",
      message: "Updated successfully"

    }, {
      type: type[color],
      timer: 3000,
      placement: {
        from: from,
        align: align
      }
    });
  }
}	  
				 function check(){
				$(document).on('click','#submit',function(){
                console.log("entered submit");					
				//$("#submit").click(function(){
               // var org_phone = $("#org_phone").val();    
                //var Sno = $("#Sno").val();                 
				var name = $("#name").val();
				var phone = $("#phone").val();
				var address = $("#address").val();
				var litres = $("#litres").val();
					var zone_id = $('#zone_id').val();
        var e = document.getElementById("zone");
        var zone = e.options[e.selectedIndex].value;
		//var amount = $("#amount").val();
       // var zone = e.options[e.selectedIndex].text;

				phone = phone.replace(/[^0-9]/g,'');
				if( name =='' || phone =='' || address =='' || litres =='' ){
				alert("Please fill all fields...!!!!!!");
				
				}
				else if (phone.length != 10)
				{
					alert('Phone number must be 10 digits.');
				}
				else {
				$.post("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/update_det_1.php", {
               // Sno1: Sno,
				name1: name,
				phone1: phone,
     //   org_phone1: org_phone,
				address1: address,				
				litres:litres,
				//amount:amount,
        zone1:zone,
					zone_id:zone_id
				}, function(data) {
				if (data == 'SUCCESS') {
				$("form")[0].reset();
				}
				 md.showNotification('top','center');
				});
				}
				});
				}
				
				 
				 var phone1 = document.getElementById("ph").value;
				 //console.log("phone"+phone);
		$(document).ready(function(){	
		$.ajax({
			type:"POST",
			url:"http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/edit_phone.php",
			dataType:"json",			
			data:({
			phone:phone1}),
			success:function(JSONObject){
				JSONObject.forEach(function(json){
			var phone = json.phone;				
			var name = json.name;
			var litres = json.litres;
					console.log(litres);
			var address = json.address;
			var zone  = json.zone;
			var zone_id = json.zone_id;
			document.getElementById("phone").defaultValue = phone;
			document.getElementById("name").defaultValue = name;
			document.getElementById("litres").defaultValue = litres;
			document.getElementById("address").defaultValue = address;					//document.getElementById("zone").defaultValue = zone;
			document.getElementById("zone_id").value = zone_id;
					 document.getElementById("hi").text = zone;
				})
			}
		})
			 
		})
			
			 </script>
		</head>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
<!--script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script-->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
<!--script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"=--></script>
<script src="/milk/v4/assets/js/plugins/bootstrap-notify.js"></script> 

  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
</script>
<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 50px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
#details{
    color:black;
   } 
</style>
</head>
<div class="main-panel">
<div class="content">
 <div class="container-fluid">
	
                    <div class="row">
                        <div class="col-md-12 col-sm-6">
                            <div class="card" style=" width: 70%;margin-left: 100px;">
                                <div class="card-header card-header-primary">
                                 <h4 class="card-title ">Customer Details</h4>
                                </div>
                                <div class="card-body">
                                <form class="form" method="post" action="#" id="form">
                               
                                <label><b id="details">Name :</b></label>
                                <input type="text" name="dname" id="name">
                                <label><b id="details">PhoneNumber :</b></label>
                                <input type="text" name="dphone" id="phone" readonly><p>NOTE:If you want to change phone number please delete the entry and create an new entry</p>
                                <label><b id="details">Address :</b></label>
                                <input type="text" name="daddress" id="address">				
                                <label><b id="details">Consumption :</b></label>
                                <input type="text" name="dconsumption" id="litres">
                                <label><b id="details">Zone: </b></label><br />
                         <select name = "zone" id="zone" style = "width:620px;border-color:#00FFFF;border-width: 3px;">
>
<option  id = "hi"></option>
  <option  value="10">Alipur</option>
  <option value="11">Ballygunge</option>
  <option  value="12">Salt lake and kakurgachi</option>
  <option  value="13">Camac street</option>
  <option  value="14">Garia and Kakurgachi</option>
    <option  value="15">Kakurgachi</option>
      <option  value="16">Hastings</option>
      <option  value="17">Ballygunge 1</option>
<option  id="zone_id" hidden></option>                        							 							 
</select>
<br/><br/>
<!--label>Amount Paid:</label>
<input type="text" name="amount" id="amount" value="<!--?php echo $amount; ?>"-->
<style>
.zone {float:left;}
</style>
								   <input action="action" onclick="window.history.go(-1); return false;" type="button" style="margin-left: 100px;background-color:purple;color:#fff;border-color:purple;float:left;padding:5px 50px;font-size:17px;border-radius:9px;" id="cancel" value="cancel">
                                <input type="button" name="submit" id="submit" style="margin-right: 100px;background-color:purple;color:#fff;border-color:purple;float:right;padding:5px 50px;font-size:17px;border-radius:9px;" value="submit" onclick="check()" data-dismiss="alert">
								
                                 </form>
                                 </div>
        </div>

</div>
</div>
</div>
</div>
</div>
 </body>
</html>


