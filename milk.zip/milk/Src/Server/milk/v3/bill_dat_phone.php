<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username   = "appville_user";
$password   = "Appvilleiot1";
$dbname     = "appvilledb";
$phone      = $_REQUEST['phone'];
$dt1        = $_REQUEST['dt1'];
$dt2        = $_REQUEST['dt2'];
$conn       = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$check_query = "SELECT * FROM milk_bill WHERE phone= '$phone'";
$result      = mysqli_query($conn, $check_query);
$data        = mysqli_num_rows($result);
$time        = date('H:i:s');
$time2       = date('H:i:s a');

//if (($data) == 1) {
    
    if (preg_match("/^[0-9]{10}$/", $phone)) {
        
        $query_sel    = "select litres,phone,date,price,litres*price as total from milk_bill where phone = '$phone' and date>='$dt1' and date<='$dt2'";
        $rs_err_split = mysqli_query($conn, $query_sel);
        $json_arr     = array();
        $data_item   = array();
        $tot_array    = array();
		$report		= array();
        $prev_lit     = 0;
        while ($row = mysqli_fetch_array($rs_err_split)) {
            $data_item["date_val"] = $row["date"];
            $data_item["litres"]   = $row['litres'];
            $data_item["price"]    = $row["price"];
			$data_item['total']    = $row['total'];
            $json_arr[]             = $data_item;
        }
        
		$sum_qry = "select litres,price,sum(litres*price) as total_ltr_price,sum(litres) as tot_ltr from milk_bill where phone='$phone'and date>='$dt1' and date<='$dt2'";
        $res_sum                      = mysqli_query($conn, $sum_qry);
        $row                          = mysqli_fetch_assoc($res_sum);
        $tot_array['total_litre']         = $row['tot_ltr'];
        $tot_array['total_litres_price'] = $row['total_ltr_price'];
        $json_arr[]                   = $tot_array;  
		$report['report'] = $json_arr;
		$report['total'] = $tot_array;
		
        print json_encode($report);
    } 
	else {
        echo "phone number is not 10 digits";
    }
    
//} 
// else {
    // echo "Error:Phone number not registered";
// }

mysqli_close($conn);
?>