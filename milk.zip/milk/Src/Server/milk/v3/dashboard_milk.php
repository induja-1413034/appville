<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="/assets/img/apple-icon.png">
    <link rel="icon" href="/assets/img/favicon.png">
    <title>
         Dashboard-The Good Cow
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <!-- Documentation extras -->
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
    <!-- iframe removal -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

	<script type="text/javascript"></script>
	<script >
		$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");
        });
    
</script>
<!--<script>
	$(".myBox").click(function() {
  window.location = $(this).find("a").attr("href"); 
  return false;
});
</script>-->

<!--
    <style>
h1{color:blue};
p{color:pink};
background-image: url("img_factory.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
</style>-->
<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
</style>
</head>

<body class="">
	<div class="se-pre-con"></div>

    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="/assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="logo">
                <a href="/milk/v3/dashboard_milk.php" class="simple-text logo-normal">
                    The Good Cow
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item active ">
                        <a class="nav-link" href="/milk/v3/dashboard_milk.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="/milk/v3/register.php">
                            <i class="material-icons">person</i>
                            <p>Registration</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="/milk/v3/view_report.php">
                            <i class="material-icons">content_paste</i>
                            <p>View Report</p>
                        </a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link " href="/milk/v3/changeprice.html">
                            <i class="material-icons">settings</i>
                            <p>Settings</p>
                        </a>
                    </li>
                    <!--li class="nav-item ">
                        <a class="nav-link" href="/milk/v3/zone_report.php">
                            <i class="material-icons">content_paste</i>
                            <p>Zone Report</p>
                        </a>
                    </li>
                    
                    <!--li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/rem_list.php">
                            <i class="material-icons">reorder</i>
                            <p>Remainder List</p>
                        </a>
                    </li-->
                    <!--<li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/icons.html">
                            <i class="material-icons">list</i>
                            <p>Others</p>
                        </a>
                    </li>-->
                    <!--li class="nav-item ">
                        <a class="nav-link" href="/milk/v3/login.html">
                            <i class="material-icons">Logout</i>
                            <p>Logout</p>
                        </a>
                    </li-->
        
                </ul>

      

            </div>
        </div>
<div class="main-panel">
            <!-- Navbar -->
            <!--<div class="jumbotron">
  <h1>Welcome to macdue dashboard</h1>
  <p><i>This dashboard is for viewing and managing the machineries from Macdue</i></p>
</div>-->

            <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute fixed-top">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <a class="navbar-brand" href="#pablo">Welcome to The Good Cow dashboard</a>
                        <!--<h3 class="navbar-brand" href="#pablo">This dashboard is for viewing and managing machineries</h3>-->
                    </div>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                    </button>
            </nav>
<!--nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute fixed-top">
<div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form class="navbar-form">
                            <div class="input-group no-border">
                                <input type="text" value="" class="form-control" placeholder="Search...">
                                <button type="submit" class="btn btn-white btn-round btn-just-icon">
                                    <!--i class="material-icons">search</i>
                                    <div class="ripple-container"></div>
                                </button>
                            </div>
                        </form>
</div>
</nav-->
<div class="content">
                <div class="container-fluid">
                    <div class="row">
                    
                        <div class="col-lg-3 col-md-3 col-sm-3">
                        	

                        	<!--<div class="panel panel-defaultcard-linked">
    <a class="card-link" href="rem_v1/customer_det"></a>
    <div class="card-title">
        <div class="card-title-texts">
            <h3>Heading</h3>
        </div>
    </div>
    <div class="card-actions">
        <button class="btn btn-link">
             Do stuff
        </button>
    </div>
    <div class="card-body">
          Content of panel
    </div>
</div>-->

                          <a href="/milk/v3/register.php">
                            <div class="card card-stats">
                            	<!--<a class="card-link" href="rem_v1/customer_det"></a>-->
                                <div class="card-header card-header-success card-header-icon">
                                    <div class="card-icon">
                                        <i class="material-icons">person</i>
                                    </div>
                                    <p class="card-category">Registration</p>
                                   <h3 class="card-title">Registration
                                        <!--<small>GB</small>-->
                                    </h3>
                                    <div class="card-body">
      
      <!--a class="card-link" href="/milk/v3/register.php">Details</a-->
    </div>
                                </div>
                                <!--<div class="card-actions">
                                <button class="btn btn-link">
                                Customer List
                                </button>
                                </div>-->

                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i>This page allows registration of new phone numbers.
                                        <!--<a href="#pablo">Get More Space...</a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a>
                        
                        <div class="col-lg-3 col-md-6 col-sm-6">
                        <a href="/milk/v3/view_report.php">
                            <div class="card card-stats">
                                <div class="card-header card-header-warning card-header-icon ">
                                    <div class="card-icon ">
                                        <i class="material-icons ">insert_emoticon</i>
                                    </div>
                                    <p class="card-category"><b>View Report</b></p>
                                    <h3 class="card-title">View Report</h3>
                                </div>
                                <div class="card-body">
      
      <!--a class="card-link" href="/milk/v3/view_report.php">Details</a-->
    </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i>This page displays the total customers and their required consumption in litres. This report can also be printed.
                                    </div>
                                </div>
                            </div>
							</a>
                        </div>
						
						  <div class="col-lg-3 col-md-6 col-sm-6">
                        <a href="/milk/v3/changeprice.html">
                            <div class="card card-stats">
                                <div class="card-header card-header-info card-header-icon ">
                                    <div class="card-icon ">
                                        <i class="material-icons ">settings</i>
                                    </div>
                                    <p class="card-category"><b>Settings</b></p>
                                    <h3 class="card-title">Settings</h3>
                                </div>
                                <div class="card-body">
      
      <!--a class="card-link" href="/milk/v3/view_report.php">Details</a-->
    </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i>This page allows to change the price of milk per litre
                                    </div>
                                </div>
                            </div>
							</a>
                        </div>
                        

                        <!--div class="col-lg-3 col-md-6 col-sm-6">
                        <a href="/milk/v3/zone_report.php">
                            <div class="card card-stats">
                                <div class="card-header card-header-info card-header-icon ">
                                    <div class="card-icon ">
                                        <i class="material-icons ">insert_emoticon</i>
                                    </div>
                                    <p class="card-category"><b>Zone Report</b></p>
                                    <h3 class="card-title">Zone Report</h3>
                                </div>
                                <div class="card-body">
      
      <!--a class="card-link" href="/milk/v3/view_report.php">Details</a-->
    <!--/div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i>This page displays the total customers,their zones and their required consumption in litres. This report can also be printed.
                                    </div>
                                </div>
                            </div>
                        </div>
                        </a-->
                        
                        <!--div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header card-header-danger card-header-icon ">
                                    <div class="card-icon ">
                                        <i class="material-icons">reorder</i>
                                    </div>
                                    <p class="card-category"><b>Remainder List</b></p>
                                    <h3 class="card-title">Reminder List</h3>
                                </div>
                                <div class="card-body">
      
      <a class="card-link" href="/rem_v1/rem_list.php">Details</a>
    </div>
                               <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i>Gives the remainders sent to customers
                                    </div>
                                </div>
                            </div>
                        </div>  
                        <!--<div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header card-header-info card-header-icon ">
                                    <div class="card-icon ">
                                        <i class="material-icons">menu</i>
                                    </div>
                                    <p class="card-category">Others</p>
                                   <h3 class="card-title">Others</h3>
                                </div>
                               <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i>Other items
                                    </div>
                                </div>
                            </div>
                        </div-->  
                     
</div>
</div>
</div>
</div>
</div>
</body>
</html>
