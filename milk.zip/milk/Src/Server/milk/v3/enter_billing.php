<!--?php 
   date_default_timezone_set('Asia/Kolkata');
   $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
   $username = "appville_user";
   $password = "Appvilleiot1";
   $dbname = "appvilledb";
   $conn = new mysqli($servername, $username, $password, $dbname);
   
   if ($conn->connect_error) 
   {
     die("Connection failed: " . $conn->connect_error);
   }
   
   $sql = "select * from ";
   $Sno = $_GET['Sno'];
   $phone = $_GET['phone'];
   //$name = $_GET['name'];
   //$address = $_GET['address'];
   //$litres = $_GET['litres'];
   //$zone = $_GET['zone_id'];
   //$zone_id = $_GET['zone'];
   $amount = $_GET['amount_paid'];
   
   ?-->
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta name="google-signin-client_id" content="598828684295-5v25a5ip2k28rcncg8d55dmhfufjj0io.apps.googleusercontent.com">
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
      <!-- Favicons -->
      <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
      <link rel="icon" href="/rem_v1/assets/img/favicon.png">
      <title>
         registration-milk
      </title>
      <!--     Fonts and icons     -->
      <meta name="robots" content="noindex, nofollow">
      <link rel="stylesheet" href="registration.css"/>
      <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
      <script type="text/javascript">
	     
		    md = {
  misc: {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
  },

  checkSidebarImage: function() {
    $sidebar = $('.sidebar');
    image_src = $sidebar.data('image');

    if (image_src !== undefined) {
      sidebar_container = '<div class="sidebar-background" style="background-image: url(' + image_src + ') "/>';
      $sidebar.append(sidebar_container);
    }
  },

  showNotification: function(from, align) {
    type = ['', 'info', 'danger', 'success', 'warning', 'rose', 'primary'];

    color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: "add_alert",
      message: "Added successfully"

    }, {
      type: type[color],
      timer: 3000,
      placement: {
        from: from,
        align: align
      }
    });
  }
}	  
         $(document).ready(function(){
          
         $(document).on('click','#submit',function(){		  
        // $("#submit").click(function(){
                          
         var phone = $("#phone").val();
         var amount = $("#amount").val();
         
         phone = phone.replace(/[^0-9]/g,'');
         if( phone =='' || amount =='' ){
         alert("Please fill all fields...!!!!!!");
         }
         else if (phone.length != 10)
         {
         	alert('Phone number must be 10 digits.');
         }
         else {
         $.post("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/insert_amount.php", {
                    // Sno1: Sno,
         //name1: name,
         phone1: phone,
         amount:amount,
         }, function(data) {
         if (data == 'SUCCESS') {
         $("form")[0].reset();
         }
		  md.showNotification('top','center');
         //alert(data);
                     //window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/view_report.php";
         });
         }
         });
         });
      </script>
   </head>
   <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
   <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
   <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
   <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
   <meta name="google-signin-scope" content="profile email">
   <!--meta name="google-signin-client_id" content="goodcowcompany.apps.googleusercontent.com"-->
   <script src="https://apis.google.com/js/platform.js" async defer></script>
   <script src="/milk/v4/assets/js/plugins/bootstrap-notify.js"></script> 
   
   <script type="text/javascript"></script>
   <script >
      $(window).load(function() {
      // Animate loader off screen
      $(".se-pre-con").fadeOut("slow");
      $("#col1").hide();
      
      });
   </script>
   <style>
      .no-js #loader { display: none;  }
      .js #loader { display: block; position: absolute; left: 50px; top: 0; }
      .se-pre-con {
      position: fixed;
      left: 0px;
      top: 0px;
      width: 100%;
      height: 100%;
      z-index: 9999;
      background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
      }
      #submit {
      }
      div#div_id_name {        /* this will hide div with id div_id_name */
      /*display:block;*/
      }   
      #signout
      {
      float:right;
      /*margin-left:150px;*/
      //background-color:purple;
      // background-color: #008CBA; /* blue */
      color:white;
      }
      #g-signin2
      {
      float:right; 
      /*margin-left:150px;*/
      }
      #col1{
      //visibility:hidden;
      }
      #details{
      color:black;
      } 
      .button {
      -webkit-transition-duration: 0.4s; /* Safari */
      transition-duration: 0.4s;
      }
      .button:hover {
      background-color: #4CAF50; /* Green */
      color: white;
      }
   </style>
   <body>
      <!--button onclick="signOut();" id ="signout">Sign out</button>
         <h3>Welcome to good cow company!!!!</h3>	
         <!--div class="content"-->
      <div class="container-fluid">
         <br/>
         <center>
            <div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark" id="g-signin2"></div>
         </center>
         <br/><br/>
         <center><button type="button" class="btn btn-info" onclick="signOut();" id ="signout">Sign out</button></center>
         <br/><br/><br/><br/>
         <!--center><div class="g-signin2"  id="div_id_name"></div></center><br/><br/-->	 
         <script>
            function onSignIn(googleUser) {
              $("#col1").hide();
              $("#col1").show();
                 // Useful data for your client-side scripts:
                 var profile = googleUser.getBasicProfile();
                 console.log("ID: " + profile.getId()); // Don't send this directly to your server!
                 console.log('Full Name: ' + profile.getName());
                 console.log('Given Name: ' + profile.getGivenName());
                 console.log('Family Name: ' + profile.getFamilyName());
                 console.log("Image URL: " + profile.getImageUrl());
                 console.log("Email: " + profile.getEmail());
                 //window.reload("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/enter_billing.php");
                 // The ID token you need to pass to your backend:
                 var id_token = googleUser.getAuthResponse().id_token;
                 console.log("ID Token: " + id_token);
            $("#g-signin2").show();
            //window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/enter_billing.php";
               };
            
            
            function signOut() {
             var auth2 = gapi.auth2.getAuthInstance();
             auth2.signOut().then(function () {
               console.log('User signed out.');
            //$("#g-signin2").show();
            $("#col1").hide();
            //window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/google_sign_in.html";
            
             });
            }
         </script>
         <div class="row">
            <div class="col-md-12 col-sm-6" id="col1">
               <!--div class="card" style=" width: 70%;margin-left: 100px;"-->
               <div class="card">
                  <div class="card-header card-header-primary">
                     <h4 class="card-title ">Amount Paid Details</h4>
                  </div>
                  <div class="card-body">
                     <form class="form" method="post" action="#" id="form">
                        <label><b id="details">PhoneNumber :</b></label>
                        <input type="text" name="dphone" id="phone"><!--p>NOTE:If you want to change phone number please delete the entry and create an new entry</p-->
                        <label><b id="details">Amount Paid:</b></label>
                        <input type="text" name="amount" id="amount" >
                        <style>
                           .zone {float:left;}
                        </style>
                        <!--div class ="title_div" id = "outer">
                           <input action="action" onclick="window.history.go(-1); return false;" type="button" style="margin-left: 100px;background-color:purple;color:#fff;border-color:purple;padding:5px 50px;font-size:17px;border-radius:9px;" id="cancel" value="cancel">
                           <input type="button" name="submit" id="submit" style="margin-left: 80px;background-color:purple;color:#fff;border-color:purple;float:right;padding:5px 50px;font-size:17px;border-radius:9px;" value="submit">
                           
                             </div-->
                        <div class="row">
                           <div class="col-lg-12">
                              <center>
                                 <input action="action" onclick="window.history.go(-1); return false;" type="button" id="cancel" value="cancel" style="background-color:purple;color:#fff;border-radius:9px;border-color:purple;padding:5px;width:30%">
                                 <input type="button" name="submit" id="submit" value="submit" style="background-color:purple;color:#fff;border-radius:9px;border-color:purple;padding:5px;width:30%">
                              </center>
                     </form>
                     </div>
                     </div>
                  </div>
                  <!--/div-->
               </div>
            </div>
         </div>
      </div>
   </body>
</html>
