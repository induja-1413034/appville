<!--?php 
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
      
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
	  
	  $sql = "select * from ";
      $Sno = $_GET['Sno'];
      $phone = $_GET['phone'];
      //$name = $_GET['name'];
      //$address = $_GET['address'];
      //$litres = $_GET['litres'];
      //$zone = $_GET['zone_id'];
      //$zone_id = $_GET['zone'];
	  $amount = $_GET['amount_paid'];

?-->

<!DOCTYPE html>
<html lang="en">

<head>
<meta name="google-signin-client_id" content="598828684295-5v25a5ip2k28rcncg8d55dmhfufjj0io.apps.googleusercontent.com">
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <link rel="icon" href="/rem_v1/assets/img/favicon.png">
    <title>
         registration-milk
    </title>
    <!--     Fonts and icons     -->
    <meta name="robots" content="noindex, nofollow">
			<link rel="stylesheet" href="registration.css"/>
			<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
			 <script type="text/javascript">
                
				$(document).ready(function(){
                    
				$("#submit").click(function(){
                //var org_phone = $("#org_phone").val();    
                //var Sno = $("#Sno").val();                 
				//var name = $("#name").val();
				var phone = $("#phone").val();
				//var address = $("#address").val();
				//var consumption = $("#consumption").val();
        //var e = document.getElementById("zone");
       // var zone = e.options[e.selectedIndex].value;
		var amount = $("#amount").val();
       // var zone = e.options[e.selectedIndex].text;

				phone = phone.replace(/[^0-9]/g,'');
				if( phone =='' || amount =='' ){
				alert("Please fill all fields...!!!!!!");
				}
				else if (phone.length != 10)
				{
					alert('Phone number must be 10 digits.');
				}
				else {
				$.post("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/insert_amount.php", {
               // Sno1: Sno,
				//name1: name,
				phone1: phone,
       // org_phone1: org_phone,
				//address1: address,				
				//consumption1:consumption,
				amount:amount,
        //zone1:zone
				}, function(data) {
				if (data == 'SUCCESS') {
				$("form")[0].reset();
				}
				alert(data);
                //window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/view_report.php";
				});
				}
				});
				}) ;
			 </script>
		</head>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

	
   <meta name="google-signin-scope" content="profile email">
    <!--meta name="google-signin-client_id" content="goodcowcompany.apps.googleusercontent.com"-->
	
    <script src="https://apis.google.com/js/platform.js" async defer></script>
  <script type="text/javascript"></script>
  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
</script>
<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 50px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
#submit {
    
   }
div#div_id_name {        /* this will hide div with id div_id_name */
  display:none;
}   

#signout
{
	/*float:right;*/
	margin-left:800px;
	background-color:purple;
	color:white;
}
</style>
</head>
<div class="main-panel">

 <button onclick="signOut();" id ="signout">Sign out</button>
 <h3>Welcome to good cow company!!!!</h3>	
 <!--div class="content"-->
 <div class="container-fluid">
	 <center><div class="g-signin2"  id="div_id_name"></div></center><br/><br/>	 
	  <script>
	  function onSignIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        console.log("ID: " + profile.getId()); // Don't send this directly to your server!
        console.log('Full Name: ' + profile.getName());
        console.log('Given Name: ' + profile.getGivenName());
        console.log('Family Name: ' + profile.getFamilyName());
        console.log("Image URL: " + profile.getImageUrl());
        console.log("Email: " + profile.getEmail());
 
        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;
        console.log("ID Token: " + id_token);
		window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/edit_amount.php";
      };
	  
	
  function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
      console.log('User signed out.');
	  
	window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/google_sign_in.html";
	
    });
  }
  </script>

                    <div class="row">
				
                        <div class="col-md-12 col-sm-6">
                            <div class="card" style=" width: 70%;margin-left: 100px;">
							
                                <div class="card-header card-header-primary">
                                 <h4 class="card-title ">Amount Paid Details</h4>
                                </div>
                                <div class="card-body">
                                <form class="form" method="post" action="#" id="form">
                                <label>PhoneNumber :</label>
                                <input type="text" name="dphone" id="phone"><!--p>NOTE:If you want to change phone number please delete the entry and create an new entry</p-->
<label>Amount Paid:</label>
<input type="text" name="amount" id="amount" >
<style>
.zone {float:left;}
</style>
<div class ="title_div" id = "outer">

                                <input action="action" onclick="window.history.go(-1); return false;" type="button" style="margin-left: 100px;background-color:purple;color:#fff;border-color:purple;float:left;padding:5px 50px;font-size:17px;border-radius:9px;" id="cancel" value="cancel">
                                <input type="button" name="submit" id="submit" style="margin-right: 100px;background-color:purple;color:#fff;border-color:purple;float:right;padding:5px 50px;font-size:17px;border-radius:9px;" value="submit">
				
                                  </div>
                                 </form>
                                 </div>
        <!--/div-->

</div>
</div>
</div>
</div>
</div>
 </body>
</html>
