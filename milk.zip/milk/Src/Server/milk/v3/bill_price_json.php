<?php

date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$conn = new mysqli($servername, $username, $password, $dbname);
//$dt1 = $_REQUEST['dt1'];
//$price = $_REQUEST['price'];
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}
$data_array = array();
$json_arr = array();
$price_qry = "select * from milk_price order by sno desc";
$price_sql = mysqli_query($conn,$price_qry);
while($price_row = mysqli_fetch_assoc($price_sql))
{
	$data_array["date_time"] = $price_row["date_time"];
	$data_array["price"] = $price_row["price"];
	$json_arr[] = $data_array;
}
print json_encode($json_arr);
mysqli_close($conn);
?>