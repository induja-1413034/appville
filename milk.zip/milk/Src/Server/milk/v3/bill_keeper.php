<?php
//TODO: 
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
//$today = date('Y-m-d');
$today = date("Y-m-d");
$today = date('Y-m-d', strtotime("-6 days"));
$conn = mysqli_connect($servername, $username, $password, $dbname);
$bill_price_sql = "select * from milk_price order by sno desc limit 1";
$price_qry = mysqli_query($conn,$bill_price_sql);

$price_row = mysqli_fetch_assoc($price_qry);
$price = $price_row['price'];
$bill_sql = "select * from milk_customer_det";
$bill_qry = mysqli_query($conn,$bill_sql);
while($row = mysqli_fetch_assoc($bill_qry))
{
        $phone = $row['phone'];
        $litres = $row['litres'];
        $bill_dat_sql = "insert into milk_bill(phone,litres,date,price)values('$phone','$litres','$today','$price')";
        echo $bill_dat_sql.'<br />';
        //mysqli_query($conn,$bill_dat_sql);
         if(mysqli_query($conn,$bill_dat_sql)==TRUE)
         {
             echo "success";
         }
         else
         {
             echo "error:".mysqli_error($conn).'<br />';
         }
}
mysqli_close($conn);
	
?>
