<html>
<head><title>VIEW REPORT</title>
<meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <!--link rel="icon" href="/rem_v1/assets/img/favicon.png"-->
<title> View Report</title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
  <script type="text/javascript"></script>
  <script>
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
    //alert("loading");
  });

var url_string = window.location.href; //window.location.href
var url = new URL(url_string);
var zone = url.searchParams.get("zone");


</script>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="http://cdn.datatables.net/1.10.16/css/dataTables.jqueryui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript"></script>
<script>
    $(document).ready(function(){
      $('#survey').DataTable( {
       //"pageLength": 100
       "lengthMenu": [[-1, 25, 50, 10], ["All", 25, 50, 10]]

     })
    });
    $(document).ready(function() {
        
        var table = $('#survey').DataTable();
        $('#survey tbody').on( 'click', 'tr', function () {
            if ( $(this).hasClass('selected') ) {
                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        });
});

function tot_litres()
{
  /*var hide = document.getElementById('hide').style.display='none';
  var button = document.getElementById('click');
    button.addEventListener('click',hideshow,false);
   // hide.addEventListener('click',hideshow,false);
    function hideshow() {
        document.getElementById('hide_click').style.display = 'block'; 
        this.style.display = 'none'
    }   */


  var url_string = window.location.href; //window.location.href
var url = new URL(url_string);
var zone = url.searchParams.get("zone");

    document.getElementById("amount").innerHTML = " ";
    $(document).ready(function(){
    $.ajax({
    type: "POST",
    url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/total_zone_litres.php",
    data: ({zone :zone
          //  phone : phone
          }),
        dataType: "json",
        success: function (JSONObject) {
        JSONObject.forEach(function(json) { // <--- pass a function to forEach that takes a single object. This is called for every object in the array
        var total_ltr = json.total_ltr;
        document.getElementById("amount").innerHTML = total_ltr;
        });
        }
        });
        });
}

setInterval('tot_litres()',20000); 


/*function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}*/

        function print_page() 
        {

      window.print();
    }
   
        
   </script>

</head>
<body onload="tot_litres();">
	  <p align="right"><input type="button" id="print" value="Print" button onclick="print_page()"></button></p>
<!--center><h2>Zone name :<script> document.write(zone) </script></h2></center-->
<center><h2>Total amount of litres:<a id = "amount"></a></h2></center>
<!--p align="center"><input type="button" id="click" value="VIEW LITRES" button onclick="tot_litres(); getElementById('hide_click').style.display = 'block'; this.style.display = 'none'"></button></p>
<center><h4 id="hide">Click VIEW LITRES to view total litres for each zone!!! </h4></center-->
   <div class="row">
                        <div class="col-md-12">
                            <div class="card" style="width: 90%; margin-left: 50px;">
                                <div class="card-header card-header-primary">
                                <h4 class="card-title ">View Report</h4>
                                </div>
                                <div class="card-body">
  <table id="survey" class="table table-hover ">
    <thead class=" text-primary">
      <tr>
        <th><center>PHONE</center></th>
        <th><center>NAME</center></th>
        <th><center>ADDRESS</center></th>
        <th><center>LITRES</center></th>
        <th><center>ZONE</center></th>
        <!--th><center>ZONE_ID</center></th-->
         </tr>
    </thead>
    <tbody>
      <?php
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
      $zone = $_REQUEST['zone'];
      //$zone_id = $_REQUEST['zone_id'];

      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $check="select * from milk_survey where zone_id = '$zone' ";
      $i=0;  
      $rs = mysqli_query($conn, $check);
  //echo mysqli_num_rows($rs);
      while($row = mysqli_fetch_assoc($rs))
      { $Sno= $row['Sno'];
        $phone= $row['phone'];
        $name=$row['name'];
        $address=$row['address'];
        $litres=$row['litres'];
        $zone = $row['zone'];
      //  $zone_id = $row['zone_id'];
        ?>
        <tr>
          <td ><center><?php echo $phone; ?></center></td>
          <td><center><?php echo $name; ?></center></td>
          <td><center><?php echo $address; ?></center></td>
          <td><center><?php echo $litres; ?></center></td>
          <td><center><?php echo $zone;?></center>
          <!--td><center><?php //echo $zone_id;?></center-->


</td>
</tr>
<?php
}
mysqli_close($conn);
?>
</tbody>
</table>
<div class="loader" id="hide_click" style="margin-left:300px;"></div>
<div class="loader" id="hide" style="margin-left:300px;"></div>
</div>
</div>
</div>
</div>
</body>
</html>
