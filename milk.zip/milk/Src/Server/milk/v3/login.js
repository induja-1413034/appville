 function GotoDashboard () {
        location.href = "dashboard.php";
    };