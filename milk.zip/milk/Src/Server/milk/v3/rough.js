
  
md = {
  misc: {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
  },

  checkSidebarImage: function() {
    $sidebar = $('.sidebar');
    image_src = $sidebar.data('image');

    if (image_src !== undefined) {
      sidebar_container = '<div class="sidebar-background" style="background-image: url(' + image_src + ') "/>';
      $sidebar.append(sidebar_container);
    }
  },

  showNotification: function(from, align) {
    type = ['', 'info', 'danger', 'success', 'warning', 'rose', 'primary'];

    color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: "add_alert",
      message: "Deleted successfully"

    }, {
      type: type[color],
      timer: 3000,
      placement: {
        from: from,
        align: align
      }
    });
  }
}	 			

function report()
{
	$(window).on('load', function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
  });
	
    $.ajax({
        type: "POST",
        url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/viewreport.php",
        data: ({			
           // machine_serial: serial,			
        }),
        dataType: "json",
        success: function(JSONObject) {
            var tabhtml = "";
			
            for (var key = 0; key < JSONObject.length; key++) {
				/*var phone = JSONObject.phone;
				var name  = JSONObject.name;
				var address  = JSONObject.address;
				var litres  = JSONObject.litres;
				var zone  = JSONObject.zone;
				var amount_paid  = JSONObject.amount_paid;
				var tot_ltr  = JSONObject.tot_ltr;
				var tot_amount  = JSONObject.tot_amount;
				var date_of_pay = JSONObject.date_of_pay;
				var zone_id     = JSONObject.zone_id;*/
				//console.log(zone);
				/*if(phone === "null" || name === null || address === null || litres === null || zone === null ||amount_paid === "null" || tot_ltr === "null" || tot_amount === "null" || date_of_pay === "null" )
				{
					phone='';name='';address='';litres='';
					zone='';
					amount_paid='';
					tot_ltr='';
					tot_amount = '';
					date_of_pay = '';
				}
				*/
                //  console.log("key is" + key);
                if (JSONObject.hasOwnProperty(key)) {
					if(JSONObject[key]["amount_paid"] === null)
					{
						JSONObject[key]["amount_paid"] = '';
						console.log(JSONObject[key]["amount_paid"]);
					}
					
					
                    tabhtml += "<tr id = ' " +JSONObject[key]["phone"]+" '>";
					tabhtml += "<td>" + JSONObject[key]["phone"] + "</td>";
                    tabhtml += "<td>" + JSONObject[key]["name"] + "</td>";
                    tabhtml += "<td>" + JSONObject[key]["address"] + "</td>";
                    tabhtml += "<td>" + JSONObject[key]["litres"] + "</td>";
                    tabhtml += "<td>" + JSONObject[key]["zone"] + "</td>";
                    tabhtml += "<td>" + JSONObject[key]["amount_paid"] + "</td>";
					tabhtml += "<td>" + JSONObject[key]["date_of_pay"]+"</td>";
                    tabhtml += "<td>" + JSONObject[key]["tot_ltr"] + "</td>";
                    tabhtml += "<td>" + JSONObject[key]["tot_amount"] + "</td>";
				

					   
					          tabhtml+="<center><td><input type='image' src='edit.png'  alt='Submit' width='18' height='18' name='edit' value='edit' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;' onclick='edit(this);'></td></center>";
						   
					      tabhtml+="<center><td><input type='image' src='delete.png'  alt='Submit' width='18' height='18' name='delete' class='btndelete' value='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;' onclick='del(this);'></td></center>";
                  
                  tabhtml+="<center><td><input type='image' src='billing.jpeg'  alt='Submit' width='18' height='18' name='delete' class='btndelete' value='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;' onclick='billing(this);'></td></center>";
						 
				    	tabhtml += "<td style=display:none;>" + JSONObject[key]["zone_id"] + "</td>";
							  
						 
                    tabhtml += "</tr>";
                }
            }
            //console.log(tabhtml);
            if (tabhtml != "") {
                $("#survey tbody").html(tabhtml);
				  $('#survey').DataTable( {
      // "pageLength": 100
       "lengthMenu": [[-1, 25, 50, 10], ["All", 25, 50, 10]]
            });
			
        var table = $('#survey').DataTable();
        $('#survey tbody').on( 'click', 'tr', function () {
            if ( $(this).hasClass('selected') ) {
                $(this).removeClass('selected');
            }
            else {
                table.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
            }
        });		

		
        }		
    }
	});
}

	
/*function del(curr){
 $("#survey").on("click", ".delete", function(e) {
            if(confirm('Are you sure you want to delete?')){   
			   var $row = $(this).closest("tr"),       // Finds the closest row <tr> 
          $tds = $row.find("td");  
          var val_arry=0;
          var temp = new Array();          // Finds all children <td> elements
      $.each($tds, function() { 
      val_arry+=','+
      $(this).text();
      
      });
	   var seperate_val = val_arry; 
      console.log(val_arry);
      console.log(seperate_val);
       temp = seperate_val.split(',');
       console.log(temp);	     
	      var phone  = temp[1];
		   console.log(phone);	   
            //var phone_id = table.row($('.selected')).data()[0];
           // var phoneId = $(e.currentTarget).attr("id");
          //  phone_id = phoneId.split("_")[1] ? phoneId.split("_")[1] : "";
            $.ajax({url:" http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/delete_milk.php",
                method:"post",
                data: ({ phone:phone }),
                // dataType: 'json',
                success: function( data,status,xhr ) {
                    table.row('.selected').remove().draw(false);
				   // md.showNotification('top','center');
                    alert(data);
					/*$(document).ready(function(){
				    $('[data-toggle="popover"]').popover(); 
					});*/
              /*  }
            });
            }
        });
	}*/
		
function del(curr){
		$("#survey tr").click(".delete", function(e) {
	var td_item= curr.parentElement;
	console.log(td_item);
	var tr_item = td_item.parentElement.id;
 
     if(confirm('Are you sure you want to delete?'))
			{   
			
		//	var sno = $(evt.currentTarget).attr("id");
			console.log("Confirm");
			   var $row = $(this).closest("tr"),       // Finds the closest row <tr> 
          $tds = $row.find("td");  
          var val_arry=0;
          var temp = new Array();          // Finds all children <td> elements
      $.each($tds, function() { 
      val_arry+=','+
      $(this).text();
      
      });
      
      var seperate_val = val_arry; 
      console.log(val_arry);
      console.log(seperate_val);
       temp = seperate_val.split(',');
       console.log(temp);	     
	      var phone  = temp[1];
		   console.log(phone);	   
             //$(this).closest('tr').remove();
            $.ajax({url:" http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/delete_milk.php",
                method:"post",
                data: ({ phone:phone }),
                // dataType: 'json',
                success: function( data,status,xhr ) {
					 var table = $('#survey').DataTable();
                  table.row('.selected').remove().draw(false);
                    //alert(data);
					
                }
				
            });
			md.showNotification('top','center');
		//report();	
		
			}
			
				//report();	
   });
  // 	report();	
		
}


 function edit(curr) {
      	$("#survey tr").click(".edit", function(e) {
      	console.log("you clicked edit button");
      // var client = $(e.currentTarget).attr("id");
                  // console.log(client);
				   var sno = $(e.currentTarget).attr("id");
                  console.log(sno);
         // var td_item= curr.parentElement;
	// var tr_item = td_item.parentElement.id;
	
          var $row = $(this).closest("tr"),       // Finds the closest row <tr> 
          $tds = $row.find("td");  
          var val_arry=0;
          var temp = new Array();          // Finds all children <td> elements
      $.each($tds, function() { 
      val_arry+=','+
      $(this).text();
      
      });
      
      var seperate_val = val_arry; 
      console.log(val_arry);
      console.log(seperate_val);
       temp = seperate_val.split(',');
       console.log(temp);
	     
	      var phone  = temp[1];
          var name  = temp[2];
          var address = temp[3];
          var litres = temp[4];
          var zone = temp[5];
		  var amount_paid = temp[6];
          var date_of_pay = temp[7];
		  var tot_ltr = temp[8];
		  var tot_amount = temp[9];
		  var zone_id = temp[13];
		   
			console.log("phone"+phone);
			console.log("name"+name);
			console.log("address"+address);
			console.log("zone_id"+zone_id);
		
       window.location.href = " http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/edit_milk.php?phone="+phone+"&name="+name+"&address="+address+"&litres="+litres+"&zone="+zone+"&zone_id="+zone_id+"&date_of_pay="+date_of_pay+"&tot_ltr="+tot_ltr+"&tot_amount="+tot_amount;
          
      }); 
 }

function billing(curr)
{
		$("#survey tr").click(".edit", function(e) {
      	console.log("you clicked edit button");
      // var client = $(e.currentTarget).attr("id");
                  // console.log(client);
				   var sno = $(e.currentTarget).attr("id");
                  console.log(sno);
         // var td_item= curr.parentElement;
	// var tr_item = td_item.parentElement.id;
	
          var $row = $(this).closest("tr"),       // Finds the closest row <tr> 
          $tds = $row.find("td");  
          var val_arry=0;
          var temp = new Array();          // Finds all children <td> elements
      $.each($tds, function() { 
      val_arry+=','+
      $(this).text();
      
      });
      
      var seperate_val = val_arry; 
      console.log(val_arry);
      console.log(seperate_val);
       temp = seperate_val.split(',');
       console.log(temp);
	     
	      var phone  = temp[1];
        var name  = temp[2];
		   
		
       window.location.href = "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/bill_dat.php?phone="+phone+"&name="+name;
          
      }); 
 }