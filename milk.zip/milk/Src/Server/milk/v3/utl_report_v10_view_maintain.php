<?php
include ('session.php');
$cli_id = $_SESSION['cli_id'];
$role   = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon.png">
    <title>View Maintanence</title>
    <!-- Bootstrap Core CSS -->
	<link href="/rem_v3/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="/rem_v3/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="/rem_v3/assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="/rem_v3/assets/plugins/chartist-js/dist/chartist-init.css" rel="stylesheet">
    <link href="/rem_v3/assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <link href="/rem_v3/assets/plugins/css-chart/css-chart.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <script>
var url_string = window.location.href; //window.location.href
var url = new URL(url_string);
var cli_id = url.searchParams.get("cli_id");
console.log("client"+cli_id);
if (localStorage.getItem('sno') != null) {
var local_cli1 = localStorage.getItem("local_cli");
console.log("local"+local_cli1);
}

localStorage.setItem("local_cli",cli_id);
console.log("cli_html"+cli_id);
   
</script>
<style>
.<style>
/* For width smaller than 400px: */
body {
  background-repeat: no-repeat;
  background-image: url('macdue_title_image.jpeg'); s
}

/* For width 400px and larger: */
@media only screen and (min-width: 400px) {
  body { 
     background-image: url('macdue_title_image.jpeg'); 
  }
}

#img1 {
  width:auto;
  height:auto;
  object-fit:cover;
  margin-right:1000px;
}
.navbar-brand 
{
    padding-top: 0;
}
</style>
</head>
<body class="fix-header fix-sidebar card-no-border logo-center">
      <input type="hidden" id="cli" name="custId" value="<?php echo $cli_id; ?>">
    
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <div id="main-wrapper">
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">
					
                        <!-- Logo icon --><b>
							<!--center>MacDue</center-->
							<!--center--><!--img id="img1" src = "macdue_title_image.jpeg"><!--/center-->
                        </b>
                        <!-- Logo text --><span></span> </a>
                </div>
				<center>
				<div class="navbar-collapse">
				<!--img id="img1" src = "macdue_title_image.jpeg" width="100%" height="auto"-->
				<!--img id="img2" src = "macdue_title_image.jpeg" width="auto" height="100%"-->
				<center><img id="img3" src = "macdue_title_image.jpeg" width="90%" height="auto"></center>
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                    </ul>
                </div>
				</center>
            </nav>
        </header>
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
					<br><br><br>
                        <li class="nav-small-cap">PERSONAL</li>
                        <li>
                            <a class="has-arrow " href="utl_report_v10_mqttlivestatus.php" aria-expanded="false"><i class="mdi mdi-bullseye"></i><span class="hide-menu">Machine Live status</span></a>
                        </li>
                        <li class="three-column">
                            <a class="has-arrow" href="combinereports.php"  aria-expanded="false"><i class="mdi mdi-chart-bubble"></i><span class="hide-menu">Machine & Alarm  report</span></a>
                        </li>
                        <li class="three-column">
                            <a class="has-arrow" href="format.php" aria-expanded="false"><i class="mdi mdi-chart-bubble"></i><span class="hide-menu">Machine & alarm report based on recipe</span></a>
                          
                        </li>
                        <li class="nav-small-cap">PERSONAL</li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><i class="mdi mdi-gauge"></i><span class="hide-menu">Maintenance Report </span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="utl_report_v10_addmaintenance.php">Add Maintenance</a></li>
                                <li><a href="utl_report_v10_view_maintain.php">View Maintenance</a></li>                               
                            </ul>
                        </li>
						 <li>
                            <a class="has-arrow " href="alarm_details.php" aria-expanded="false"><i class="mdi mdi-bullseye"></i><span class="hide-menu">Alarm Details</span></a>
                        </li>
                        <li>
                        <li>
                            <b><?php
							if($role == "user")
							{
							?>
							<a class="has-arrow " href="dashboard_utl.php" aria-expanded="false" id="main" hidden><i class="mdi mdi-table"></i><span class="hide-menu" style="color:#C71585;font-size:16px">Main Dashboard</span></a>
							<?php
							}
							else if($role == "admin")
							{
							?>
							<a class="has-arrow " href="dashboard_utl.php" aria-expanded="false" id="main"><i class="mdi mdi-table"></i><span class="hide-menu" style="color:#C71585;font-size:16px">Main Dashboard</span></a>
							<?php
							}
							?>
							</b>                           
                        </li>
                        <li>
                            <b><a class="has-arrow " href="changepassword.php" aria-expanded="false"><i class="mdi mdi-table"></i><span class="hide-menu">Change Password</span></a></b>                           
                        </li>
                        <li> <a class="has-arrow " href="logout.php" aria-expanded="false"><i class="mdi mdi-table"></i><span class="hide-menu">Logout</span></a> 
						</li>
					</ul>	                        
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <div class="page-wrapper">
            <div class="container-fluid">   
                <br><br><br><br><br>
				 <div class="row">
                 <div class="col-lg-12 col-md-12">
                 <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Maintainance Details</h4>
                                <div class="row form-material">
									 <div class="col-lg-12 col-md-12">
                                        <label class="m-t-20">Serial Number</label>
                                       <select id="serial" value="serial" class="form-control">
                                       </select> 
                                    </div>
									 </div>
									 </div>
									<div class="row">
											
											<div class="col-lg-6 col-md-12">
											<center><div class="col-lg-4 col-md-12">
                                        <button type="button" class="btn btn-block btn-info" onclick="FetchMacDetails()"><b>Apply</b></button>
                                         </div></center>	
										 </div>
										 <br/>
										 <br/>
										 <div class="col-lg-6 col-md-12">
		                                 <div class="col-lg-4 col-md-12">
                                        <button type="button" class="btn btn-block btn-info" onclick="deleteall()"><b>Delete All</b></button>
                                             <br><br>
                                    </div>
											<!-- </div> -->
												<!-- <div class="col-sm-3"> -->
									</div>
                         <br/>
						<br/>   
                        </div>
			     </div>
                </div>
				</div>			
                    <!-- Column -->
					   <div class="row">   
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Maintanence History</h4>
                           <thead class=" text-primary">
                 <table class="table table-hover table-striped" cellspacing="0" id="err_details">
                                
                            <col width="10%">
                            <col width="10%">
                            <col width="10%">
							<col width="10%">
                            <col width="30%">
                            <col width="10%">
							<col width="10%">
							<col width="10%">
                            <col width="10%">
                            <col width="10%">
                                   <col width="5%">
                           <thead class="text-primary">
                              <th>Date</th>
                              <th>Serial Number</th>
                              <th>Maintanence Type</th>
                              <th>Maintenance Cycle</th>
							  <th>Work Done</th>
							  <th>Technician Name</th>
							  <th>Replaced Parts</th>
							  <th>Cause</th>
                                <th>Status</th>
							   <th>Edit</th>
                               <th>Delete</th>
							  
                               <!--<th>Edit</th>-->
                           </thead>
                           <tbody> 
                                      <!--
                               
                                <tr>
                               <td>2018-03-09 15:00:00</td>
                               <td>UTL002</td>
                               <td>Standard</td>
                               <td>7000</td>
                               <td>Maintenance of welding carriage</td>
                               <td></td>
                               <td></td>
                               <td></td>
                                    <td style = "color:red"><b>Pending</b></td>
                             <td><input type="image" src="delete.png"  alt="Submit" width='25' height='28' name='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;'></td>                              
                              <td><input type="image" src="edit.png"  alt="Submit" width='25' height='28' name='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;'></td>
                                    
                               </tr>
                               <tr>
                               <td>2018-10-16 04:04:00</td>
                               <td>UTL002</td>
                               <td>Extraordinary</td>
                               <td>12853</td>
                               <td>TEST</td>
                               <td>Petonio Pasquale</td>
                               <td>TEST</td>
                               <td>n.4 slide bearings cod. 000302974 , n.2 guide</td>
                                   <td style = "color:green"><b>Done</b></td>
                               <td><input type="image" src="delete.png"  alt="Submit" width='25' height='28' name='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;'></td>                              
                              <td><input type="image" src="edit.png"  alt="Submit" width='25' height='28' name='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;'></td>                                    
                               </tr>
                               
                                 <tr>
                               <td>2018-03-09 15:00:00</td>
                               <td>UTL002</td>
                               <td>Fault</td>
                               <td>12853</td>
                               <td>Gear</td>
                               <td>Bianchi</td>
                               <td>TEST</td>
                               <td>n.4 slide bearings cod. 000302974 , n.2 guide</td>
                                      <td style = "color:green"><b>Done</b></td>
                              <td><input type="image" src="delete.png"  alt="Submit" width='25' height='28' name='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;'></td>                              
                              <td><input type="image" src="edit.png"  alt="Submit" width='25' height='28' name='delete' ''style='background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;'></td>                                   
                        -->
                               
                           </tbody>
                 </table>
                
                </div>
              </div>
             </div>
            </div>
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a></li>
                                <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-theme="red" class="red-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme working">4</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a></li>
                                <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme">7</a></li>
                                <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-theme="red-dark" class="red-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme ">12</a></li>
                            </ul>                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/rem_v3/assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="/rem_v3/assets/plugins/popper/popper.min.js"></script>
    <script src="/rem_v3/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="/rem_v3/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="/rem_v3/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!--stickey kit -->
    <script src="/rem_v3/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="/rem_v3/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="/rem_v3/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="/rem_v3/assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="/rem_v3/assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
	<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
            <script src="/rem_v3/assets/plugins/moment/moment.js"></script>
    <link href="/rem_v3/assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
	<!-- Date picker plugins css -->
    <link href="/rem_v3/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker plugins css -->
    <link href="/rem_v3/assets/plugins/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
    <link href="/rem_v3/assets/plugins/daterangepicker/daterangepicker.css" rel="stylesheet">
    <script src="/rem_v3/assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>	
	 <script src="/rem_v3/assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
	 <script src="js/serialwisemaintenance_1.js"></script>
            <script>
	 <!-- <link rel="stylesheet" href="jquery.datetimepicker.min.css"> -->
      <!-- <script src="jquery.js"></script>
      <!-- <script src="jquery.datetimepicker.full.js"></script>  -->
</body>
</html>