// $(function () {
           // $('#dat_val1').datetimepicker({
             // step: 30,
             // format: 'Y-m-d H:i',
             // showSeconds: false,      
           // });                    
         // });              
function SetDate1() {
    var date_from = "";
        var myDate = new Date();
        console.log(myDate);
        var day = myDate.getDate();
        var month = myDate.getMonth() + 1;
        var year = myDate.getFullYear();
        var h = myDate.getHours();
        var m = myDate.getMinutes();
        var s = myDate.getSeconds();
        var ampm = h >= 12 ? 'pm' : 'am';
        if (month < 10) month = "0" + month;
        if (day < 10) day = "0" + day;
        if (h < 10) month = "0" + h;
        if (m < 10) m = "0" + m;
        if (s < 10) s = "0" + s;
        var today = myDate.getFullYear() + "-" + month + "-" + day + "T" + h + ":" + m + ":" + s;       
       // var dat1 = today.replace(/T/g, ' ');       
        //date_from = dat1;
    //document.getElementById('dat_val1').value = date_from;
    }
function changeprice() {
	//var dat1_orig = $('#dat_val1').val();
    //var dat1 = dat1_orig.replace(/T/g, ' ');
	
    if (document.getElementById("name").value === "") {
        alert("Please fill Price");
		//md1.showNotification('top','center');
    } else {
        var price = document.getElementById("name").value;
        
    $.ajax({
        type: "POST",
        url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/changeprice.php",
        data: ({
			  //dt1: dat1,
				price : price
        }),
        dataType: "json",
        success: function(JSONObject) {
 //   md.showNotification('top','center');
        }
    });
	//location.reload();   
 alert("Data Added Successfully");
	load_table();
	}
	
}
md = {
  misc: {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
  },

  checkSidebarImage: function() {
    $sidebar = $('.sidebar');
    image_src = $sidebar.data('image');

    if (image_src !== undefined) {
      sidebar_container = '<div class="sidebar-background" style="background-image: url(' + image_src + ') "/>';
      $sidebar.append(sidebar_container);
    }
  },
  showNotification: function(from, align) {
    type = ['', 'info', 'danger', 'success', 'warning', 'rose', 'primary'];

    color = Math.floor((Math.random() * 6) + 1);

    $.notify({
     // icon: "add_alert",
      message: "Data Added Successfully"

    }, {
      type: type[4],
      timer: 500,
      placement: {
        from: from,
        align: align
      }
    });
  }
 }


md1 = {
  misc: {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
  },

  checkSidebarImage: function() {
    $sidebar = $('.sidebar');
    image_src = $sidebar.data('image');

    if (image_src !== undefined) {
      sidebar_container = '<div class="sidebar-background" style="background-image: url(' + image_src + ') "/>';
      $sidebar.append(sidebar_container);
    }
  },
  showNotification: function(from, align) {
    type = ['', 'info', 'danger', 'success', 'warning', 'rose', 'primary'];

    color = Math.floor((Math.random() * 6) + 1);

    $.notify({
     // icon: "add_alert",
      message: "Please fill all fields"

    }, {
      type: type[4],
      timer: 500,
      placement: {
        from: from,
        align: align
      }
    });
  }
 }


function load_table()
{
    document.getElementById('load').style.display='block';
    $("#survey tbody").empty();
    $(document).ready(function(){
                      $.ajax({
                             type: "POST",
                             url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/bill_price_json.php",
                             // data: ({dt1:dt1,
                                    // dt2:dt2,
                                    // phone:phone
                                    // }),
                             dataType: "json",
                             success: function (JSONObject) {
                                 $("#survey tbody").empty();
                             console.log(JSONObject);
                             // JSONObject.forEach(function(json) { // <--- pass a function to forEach that takes a single object. This is called for every object in the array
                             // var total_ltr_price = json.total_ltr_price;
                             // document.getElementById("amount").innerHTML = total_ltr_price;
                             // });
                             //data=json.parse(JSONObject);
                             var tabhtml = "";
                             for(var key in JSONObject){
                             if(JSONObject.hasOwnProperty(key)){
                              var tabRow = "";
                             //tot_hours = "hours":"minutes":"seconds"
                             tabRow +="<tr>";
                             tabRow +="<td><center>"+ JSONObject[key]["date_time"]+"</center></td>";
                             tabRow +="<td><center>"+ JSONObject[key]["price"]+"</center></td>";
                             tabRow +="</tr>";
                             console.log(tabRow);
                             tabhtml += tabRow;

                             }
                             }
                              document.getElementById('load').style.display='none';
                             $("#survey tbody").html(tabhtml);
                                                      
                             }
                             });
                      });
}

