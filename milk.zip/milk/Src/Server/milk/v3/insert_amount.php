<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
//$Sno=$_POST['Sno1'];
// Fetching Values from URL.
$phone = $_REQUEST['phone1'];
//$org_phone = $_REQUEST['org_phone1'];
$amount = $_REQUEST['amount'];
$date_time = date('Y-m-d H:i:s');
$date = date('Y-m-d');
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
$sel_qry = "select phone from milk_customer_det where phone='$phone'";
$sel_sql = mysqli_query($conn,$sel_qry);
if(mysqli_num_rows($sel_sql) == 1)
{	
$sql3 = "insert into milk_amount_pay(phone,amount_paid,date_of_pay)values('$phone','$amount','$date_time');";
$upd_qry = "update milk_customer_det set date_of_pay='$date_time' , amount_paid = '$amount' where phone ='$phone'";
//echo $upd_qry;
if((mysqli_query($conn,$sql3)==TRUE ) && (mysqli_query($conn,$upd_qry)==TRUE)) {
	echo "SUCCESS";
}
else {
	echo "Error:".mysqli_error($conn);
}
}
else
{
	echo "Number not registered";
}
mysqli_close($conn);
?>