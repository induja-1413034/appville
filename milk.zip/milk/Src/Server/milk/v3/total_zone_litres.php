<?php
// Check connection
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$date_time = date('Y-m-d H:i:s');
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
$zone_id=$_REQUEST['zone'];		    
$json_arr = array();
$data_array=array();

$zone_sql = "select sum(litres) as total_ltr from milk_survey where zone_id='$zone_id'";
//echo $zone_sql;
$zone_tot = mysqli_query($conn,$zone_sql);

while($row = mysqli_fetch_array($zone_tot))
{
$data_array["total_ltr"] = $row["total_ltr"];

$json_arr[] = $data_array;
}
print json_encode($json_arr);
mysqli_close($conn);
?>

