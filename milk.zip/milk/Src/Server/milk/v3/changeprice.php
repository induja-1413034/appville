<?php

date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$conn = new mysqli($servername, $username, $password, $dbname);
//$dt1 = $_REQUEST['dt1'];
$price = $_REQUEST['price'];
$today = date('Y-m-d H:i:s');
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}

$maintain_table_qry = "insert into milk_price(date_time,price)values('$today','$price');";
$maintain_table_sql = mysqli_query($conn,$maintain_table_qry);
if($maintain_table_sql == TRUE)
{
	echo "success";
}
else
{
	 mysqli_error();
}
mysqli_close($conn);
?>