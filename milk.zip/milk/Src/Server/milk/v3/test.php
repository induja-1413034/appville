<?php
$uname=$_POST['uname'];
echo $uname;
$password=$_POST['password'];
$con mysqli_connect("localhost","root","","login");
$result=mysqli_query($con,"SELECT * FROM `login_info` WHERE `uname`='uname' && `password`='password'");
$count=mysqli_num_rows($result);
if($count==1)
{
    echo "login success";
    //header(refresh:2;url=welcome.php);
    //header('location:welcome.php');
}
else{
echo "incorrect info";
//header(refresh:2;url=index.php);
}
?>
