<?php
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
        $myval = $_POST['zone'];

      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
      $check="select * from milk_survey";


     //$check2 = "select * from milk_survey where zone = '$myval'";

      $i=0;  
      $json = array();
      $data = array(); 

      $rs = mysqli_query($conn, $check);
  //echo mysqli_num_rows($rs);
      while($row = mysqli_fetch_assoc($rs))
      { $data['Sno']= $row['Sno'];
        $data['phone']= $row['phone'];
        $data['name']=$row['name'];
        $data['address']=$row['address'];
        $data['litres']=$row['litres'];
        $data['zone'] = $row['zone'];
       
       $sno = $data["Sno"];
       $phone = $data["phone"];
       $name = $data["name"];
       $address = $data["address"];
       $litres = $data["litres"];
       $zone = $data["zone"];
  $json[] = $data;

      }
print json_encode($data);

      mysqli_close($conn);


      
        ?>
      