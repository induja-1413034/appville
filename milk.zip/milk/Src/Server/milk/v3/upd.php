<?php
    date_default_timezone_set('Asia/Kolkata');
    $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
    $username = "appville_user";
    $password = "Appvilleiot1";
    $dbname = "appvilledb";
    //$Sno=$_POST['Sno1'];
    $name=$_GET['name1']; // Fetching Values from URL.
    $phone=$_GET['phone1'];
    $org_phone=$_GET['org_phone1'];
    $address= $_GET['address1'];
    $consumption= $_GET['consumption1'];
    $date_time = date('Y-m-d H:i:s');
    $date= date('Y-m-d');
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
    
    if(preg_match("/^[0-9]{10}$/", $phone)) {
        $sql="update milk_customer_det set phone='$phone', name='$name', address = '$address' where phone='$org_phone'";
        $sql3 = "update milk_history_tab set phone='$phone' where phone='$org_phone'";
        $sql4 = "update milk_historydat_tab set phone='$phone' where phone='$org_phone'";

        if((mysqli_query($conn,$sql)==TRUE) && (mysqli_query($conn,$sql3)==TRUE) &&(mysqli_query($conn,$sql4)==TRUE)) {
            $result= "insert into milk_history_tab(phone,datetime,litres) values ('$phone','$date_time','$consumption');";
          
            if((mysqli_query($conn,$result)==TRUE)){
                echo "SUCCESS";
            }
            $qry = "select * from milk_historydat_tab where date_val='$date' and phone ='$phone'";
           // echo $qry;
            $result = mysqli_query($conn,$qry);
            $check= mysqli_num_rows($result);
            if(($check)==0)
            {
                $res2= "insert into milk_historydat_tab(phone,date_val,litres) values('$phone','$date','$consumption');";
                
            }
            else
            {
                $row = mysqli_fetch_array($result);
                $sno =$row['sno'];
                echo $sno;
                $upd_qry= "update milk_historydat_tab set litres='$consumption',date_val='$date' where sno='$sno'";
                
            
            }
            $sql2="update milk_litres_det set phone='$phone',litres='$consumption' where phone='$org_phone'";
            if((mysqli_query($conn,$result)==TRUE)&&(mysqli_query($conn,$result)==TRUE)&&(mysqli_query($conn,$sql2)==TRUE)&&(mysqli_query($conn,$res2)==TRUE)&&(mysqli_query($conn,$upd_qry)==TRUE))  
            {
                echo "SUCCESS";
            }
        else{
            echo "Error:".mysqli_error($conn);
        }
        }
    }
    else{
        echo "phone number should be 10 digits";
    }
    mysqli_close($conn);
    ?>

