 <?php
      date_default_timezone_set('Asia/Kolkata');
      $servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
      $username = "appville_user";
      $password = "Appvilleiot1";
      $dbname = "appvilledb";
      $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
      if ($conn->connect_error) 
      {
        die("Connection failed: " . $conn->connect_error);
      }
	  $data_array = array();
	  $json_arr = array();
	  $sel_first_day = "SELECT 
    DATE_ADD(DATE_ADD(LAST_DAY(now()),
            INTERVAL 1 DAY),
        INTERVAL - 1 MONTH) - interval 1 month as last_month;";		
		$sel_qry = mysqli_query($conn,$sel_first_day);
		$row1 = mysqli_fetch_assoc($sel_qry);
		$last_month_first = $row1['last_month'];
		$sel_last_day = "SELECT LAST_DAY('$last_month_first') as last_day;";
		$sel_qry_last = mysqli_query($conn,$sel_last_day);
		$last = mysqli_fetch_assoc($sel_qry_last);
		$last_month_last = $last['last_day'];
		$sum = 0;
		
      $check="select * from milk_survey_bill";
      $i=0;  
      $rs = mysqli_query($conn, $check);
  //echo mysqli_num_rows($rs);
      while($row = mysqli_fetch_assoc($rs))
      { $Sno= $row['Sno'];
        $phone = $row['phone'];
		$data_array['phone'] = $phone;
        $data_array['name']  = $row['name'];
        $data_array['address']=$row['address'];
        $data_array['litres'] =$row['litres'];
        $data_array['zone']   = $row['zone'];
        $data_array['zone_id'] = $row['zone_id']; 
		$data_array['amount_paid'] = $row['amount_paid'];
		
        //$tot_ltr = $row['tot_ltr'];
        //$tot_amount = $row['tot_amount'];		
		
		$last_month_bill = "select sum(litres) as tot_ltr,sum(litres*price) as tot_amount from milk_bill where date>='$last_month_first' and date<='$last_month_last' and phone='$phone'";
		$last_bill_qry = mysqli_query($conn,$last_month_bill);
		$row1 = mysqli_fetch_assoc($last_bill_qry);
		$tot_amount= $row1['tot_amount'];
		$tot_ltr = $row1['tot_ltr'];
		if($row1['tot_amount'] != '' || $row1['tot_ltr'] != '' || $row['amount_paid'] !='')
		{
		$data_array['tot_amount'] = $row1['tot_amount'];
		$data_array['tot_ltr'] = $row1['tot_ltr'];
		$data_array['amount_paid'] = $row['amount_paid'];
		}
		else{
			$data_array['tot_amount'] = "";
		    $data_array['tot_ltr'] = "";
			$data_array['amount_paid'] = "";
		}
       		
        if($row['date_of_pay'] != '' )
        {
            $data_array['date_of_pay'] = date("Y-M-d", strtotime($row['date_of_pay']));
			
			
        }
        else
        {
            $data_array['date_of_pay'] = "";
			
        }
       $json_arr[] = $data_array;		
      }
	  print json_encode( $json_arr);
      mysqli_close($conn);
      ?>