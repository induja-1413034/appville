<?php
date_default_timezone_set('Asia/Kolkata');
$servername  = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username    = "appville_user";
$password    = "Appvilleiot1";
$dbname      = "appvilledb";
$phone       = $_GET['phone'];
$consumption = $_GET['consumption'];
$date_time   = date('Y-m-d H:i:s');
$date        = date('Y-m-d');
$conn        = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
$check_query = "SELECT * FROM milk_customer_det WHERE phone= '$phone'";
$result      = mysqli_query($conn, $check_query);
$data        = mysqli_num_rows($result);
$time        = date('H:i:s');
$time2       = date('H:i:s a');

if (($data) == 1) 
{
    
    if (preg_match("/^[0-9]{10}$/", $phone)) 
	{
        
        if ($time >= '05:00:00' && $time <= '17:00:00') 
		{
            
            $result = "insert into milk_history_log(phone,datetime,litres) values ('$phone','$date_time','$consumption');";
            
            if ((mysqli_query($conn, $result) == TRUE)) 
			{
                //echo "SUCCESS";
            } else 
			{
                echo "Error:" . mysqli_error($conn);
            }
            
            //TODO: Remove the below insertion of data into the historydat_tab
            //$sql2 = "update milk_litres_det set phone='$phone',litres='$consumption' where phone='$phone'";
			$sql2 = "update milk_customer_det set phone='$phone',litres='$consumption' where phone='$phone'";
            if (mysqli_query($conn, $sql2) == TRUE) 
			{
                 echo "SUCCESS";
            }
			else 
			{
                echo "Error:" . mysqli_error($conn);
            }
        }
        
        else 
		{
            echo "Error:Cannot Update litres after 5 PM !!!";
        }
        
    }
	else 
	{
        echo "phone number is not 10 digits";
    }
    
}
else 
{
    echo "Error:Phone number not registered";
}

mysqli_close($conn);
?>
