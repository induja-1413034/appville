<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}
$phone = $_REQUEST["phone"];
$name = $_REQUEST["name"];
$address = $_REQUEST["address"];
$litres = $_REQUEST["litres"];
$zone = $_REQUEST["zone"];
$zone_id = $_REQUEST["zone_id"];

$_SESSION["phone"]=$phone;
$_SESSION["name"]=$name;
$_SESSION["address"]=$address;
$_SESSION["litres"]=$litres;
$_SESSION["zone"]=$zone;
$_SESSION["zone_id"]=$zone_id;
/*echo $_SESSION["phone"];
echo $_SESSION["name"];
echo $_SESSION["address"];
echo $_SESSION["litres"];
echo $_SESSION["zone"];*/
mysqli_close($conn);
?>