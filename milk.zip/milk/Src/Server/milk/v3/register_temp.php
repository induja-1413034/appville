<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="rem_v1/assets/img/apple-icon.png">
    <link rel="icon" href="/rem_v1/assets/img/favicon.png">
    <title>
         registration-milk
    </title>
    <!--     Fonts and icons     -->
    <meta name="robots" content="noindex, nofollow">
			<link rel="stylesheet" href="registration.css"/>

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

			<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
			<!--script src = "https://code.jquery.com/jquery-3.1.1.slim.min.js"></script-->
			<script type="text/javascript">
	
			md = {
  misc: {
    navbar_menu_visible: 0,
    active_collapse: true,
    disabled_collapse_init: 0,
  },

  checkSidebarImage: function() {
    $sidebar = $('.sidebar');
    image_src = $sidebar.data('image');

    if (image_src !== undefined) {
      sidebar_container = '<div class="sidebar-background" style="background-image: url(' + image_src + ') "/>';
      $sidebar.append(sidebar_container);
    }
  },

  showNotification: function(from, align) {
    type = ['', 'info', 'danger', 'success', 'warning', 'rose', 'primary'];

    color = Math.floor((Math.random() * 6) + 1);

    $.notify({
      icon: "add_alert",
      message: "Added successfully"

    }, {
      type: type[color],
      timer: 3000,
      placement: {
        from: from,
        align: align
      }
    });
  }
}	   //$("#survey_wrapper").on("click", ".delete", function(e) {
       	$(document).ready(function(){	
				$("#submit").click(function(){

				var name = $("#name").val();
				var phone = $("#phone").val();
				var address = $("#address").val();
///////////////

				var consumption = $("#consumption").val();
         //$.ajax({
      //  type: "POST",
          //  url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/zone.php",
          //  data: ({dt1:dt_from,
            //dt2:dt_to,
           // machine_serial:serial
            //}),
           // dataType: "json",
            //success: function (JSONObject) {
                
       //JSONObject.forEach(function(json) { // <--- pass a function to forEach that takes a single object. This is called for every object in 
  //var zone = json.zone;
  //alert(zone);
//});
  //   }
   //});

      
               // var e = document.getElementById("zone");
                //var zone = e.options[e.selectedIndex].value;
//$.getJSON("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/zone.php", function(return_data){
	//$.each(return_data.data, function(key,value){
		//var zone = $("#zone").append("<datalist><option value=" + value.zone +"></option></datalist>");
	
//var zone = document.getElementById("zones").value;
//var zone = document.querySelector("#zone option[value='"+shownVal+"']").dataset.value;

//var e = document.getElementById("ddlViewBy");
//var strUser = e.options[e.selectedIndex].value;
var e = document.getElementById("zone");
var zone = e.options[e.selectedIndex].value;
var amount = $("#amount").val();
       // var zone = $("#zone").val();
				phone = phone.replace(/[^0-9]/g,'');
	if( name =='' || phone =='' || address =='' || consumption ==''){
				alert("Please fill all fields...!!!!!!");
				}
				else if (phone.length != 10)
				{
					//alert('Phone number must be 10 digits.');
					md.showNotification('top','center');
				}
				else {
				$.post("http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/insert_details.php", {
				name1: name,
				phone1: phone,
				address1: address,				
				consumption1:consumption,
				//amount:amount,
                zone1:zone
				}, function(data) {
				if (data == 'SUCCESS') {
				$("form")[0].reset();
				}
				
				alert(data);
				});
				}
				});
				});*/
			
//});
//});

			</script>
		</head>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />


	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script src="/milk/v4/assets/js/plugins/bootstrap-notify.js"></script> 

  <script type="text/javascript"></script>
  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
</script>
<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 50px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
#submit {
    
   } 
   #details{
	   color:black;
   }
</style>
<!--script >
  $document.ready(function(){
  $("#test").click(function() {
    alert("click");
});
});
</script-->


    <!-- iframe removal -->
</head>

<body class="">
    <div class="se-pre-con"></div>
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="rem_v1/assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
        <div class="logo">
                <a href="/milk/v3/dashboard_milk.php" class="simple-text logo-normal">
                    The Good Cow
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item  ">
                        <a class="nav-link" href="/milk/v3/dashboard_milk.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/milk/v3/register.php">
                            <i class="material-icons">person</i>
                            <p>Registration</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="/milk/v3/view_report.php">
                            <i class="material-icons">content_paste</i>
                            <p>View Report</p>
                        </a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link " href="/milk/v3/changeprice.html">
                            <i class="material-icons">settings</i>
                            <p>Settings</p>
                        </a>
                    </li>
                     <!--li class="nav-item ">
                        <a class="nav-link" href="/milk/v3/zone_report.php">
                            <i class="material-icons">content_paste</i>
                            <p>Zone Report</p>
                        </a>
                    </li-->
                   
                    <!--li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/rem_list.php">
                            <i class="material-icons">reorder</i>
                            <p>Remainder List</p>
                        </a>
                    </li-->
                    <!--<li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/icons.html">
                            <i class="material-icons">list</i>
                            <p>Others</p>
                        </a>
                    </li>-->
                    <!--li class="nav-item ">
                        <a class="nav-link" href="/rem_v1/login.html">
                            <i class="material-icons">Logout</i>
                            <p>Logout</p>
                        </a>
                    </li-->
                    
                </ul>
            </div>
        </div>
<div class="main-panel">
<div class="content">
 <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12 col-sm-6">
                            <div class="card" style=" width: 70%;margin-left: 100px;">
                                <div class="card-header card-header-primary">

                                    

                                 <h4 class="card-title ">Customer Details</h4>
                                </div>
                                <div class="card-body">
                                <form class="form" method="post" action="#" id="form">
                                    <!--div class="navbar">
                            <div class="dropdown">
                            <button class="dropbtn">Zone 
                            <i class="fa fa-caret-down"></i>
                            </button>

                           <div class="dropdown-content">
                            <a href="#">Zone 1</a>
                            <a href="#">Zone 2</a>
                            <a href="#">Zone 3</a>
                           </div>
                            </div> 
                           </div-->
                                <!--h2>CUSTOMER DETAILS</h2-->
                                <label><b id="details">Name :</b></label>
                                <input type="text" name="dname" id="name">
                                <label><b id="details">PhoneNumber :</b></label>
                                <input type="text" name="dphone" id="phone">
                                <label><b id="details">Address :</b></label>
                                <input type="text" name="daddress" id="address">				
                                <label><b id="details">Consumption :</b></label>
                                <input type="text" name="dconsumption" id="consumption">
                                <label><b id="details">Zone:</b></label><br />
                                <!--input type ="text" list="zone" name="zone" id="zones"-->
<select name = "zone" id="zone" style = "width:620px;border-color:#00FFFF;border-width: 3px;">
  <option value="10">Alipur</option>
  <option value="11">Ballygunge</option>
  <option value="12">Salt lake and kakurgachi</option>
  <option value="13">Camac street</option>
  <option value="14">Garia and Kakurgachi</option>
    <option value="15">Kakurgachi</option>
      <option value="16">Hastings</option>
      <option value="17">Ballygunge 1</option>
</select>
<!--label>Amount to pay:</label>
<input type="text" name="amount" id="amount"-->
<!--select id="zone">
  <option value="1">zone1</option>
  <option value="2" selected="selected">zone2</option>
  <option value="3">zone3</option>
  <option value="4">zone4</option>
</select-->


                                <!--select>
                               <option value="volvo" id="zone">Zone1</option>
  <option value="saab">Saab</option>
  <option value="opel">Opel</option>
  <option value="audi">Audi</option>

</select-->
<style type>
.outer{width:100%;}
.zone {
    float:left;
    display: block;
    width: 100%;
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
    text-align: center;

}


</style>
<div class ="title_div" id = "outer">
                                <input action="action" onclick="window.history.go(-1); return false;" type="button" style="margin-left: 50px;background-color:purple;color:#fff;border-color:purple;float:left;padding:5px 50px;font-size:17px;border-radius:9px;" id="cancel" value="cancel" >
                                <input type="reset" style="margin-left: 50px;background-color:purple;color:#fff;border-color:purple;float:left;padding:5px 50px;font-size:17px;border-radius:9px;" id="clear" value="clear">
								
                                <button type="button" name="submit" id="submit" style="margin-right: 80px;background-color:purple;color:#fff;border-color:purple;float:right;padding:5px 50px;font-size:17px;border-radius:9px;" class="submit" value="submit">submit</button>
								
								<!--button type="button" data-toggle="popover" title="Popover title" data-content="And here's some amazing content"  id="delete_<!?php echo $phone; ?>" class="delete" value="DELETE" style="background-color: purple; border-radius: 5px; color: #fff;height: 30px;width: 80px;" >Delete</button-->
				</div>
                                  </div>
                                 </form>
                                 </div>
                                 
</div>
</div>
</div>
</div>
</div>
 </body>
</html>