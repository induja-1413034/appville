<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="/assets/img/apple-icon.png">
    <link rel="icon" href="/assets/img/favicon.png">
    <title>
         Billing calculation
    </title>
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/material-dashboard.css?v=2.0.0">
    <!-- Documentation extras -->
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="assets/assets-for-demo/demo.css" rel="stylesheet" />
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

  <script type="text/javascript"></script>
  <script >
    $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");
    
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    var yyyy = today.getFullYear();
    if(dd<10) {
        dd = '0'+dd
    } 
    
    if(mm<10) {
        mm = '0'+mm
    } 
    
    today = yyyy + '-' + mm + '-' + dd ;
    first_day = yyyy + '-' + mm + '-01';
    
    document.getElementById("dat_val1").value = first_day;
    document.getElementById("dat_val2").value = today;
    ph = phone;
    billing(ph);
  });

var phone = getQueryVariable("phone");
var name1 = getQueryVariable("name");
var name = name1.replace(/%20/g, " ");
 // or use .trim()
//document.getElementById("name").value= name;
function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) 
       {
            var pair = vars[i].split("=");
            if(pair[0] == variable)
            {
                return pair[1];
            }
       }
       return(false);
}
// document.getElementById("name").innerHTML = name1;

// function getParameter(theParameter) {
    // var params = window.location.search.substr(1).split('&');
    
    // for (var i = 0; i < params.length; i++) {
        // var p=params[i].split('=');
        // if (p[0] == theParameter) {
            // return decodeURIComponent(p[1]);
        // }
    // }
    // return false;
// }
// function processUser(phone)
  // {
    // var parameters = location.search.substring(1).split("&");

    // var temp = parameters[0].split("=");
    // phone = unescape(temp[1]);
    // temp = parameters[1].split("=");
    // name = unescape(temp[1]);
   // // document.getElementById("phone").innerHTML = phone;
    // document.getElementById("name").innerHTML = name;
  // }
//document.getElementById("phone").innerHTML=phone;

function billing(phone)
{
    var dat1 = document.getElementById("dat_val1").value;
    //var dat1 = dat1_orig.replace(/T/g,' ');
    var dat2 = document.getElementById("dat_val2").value;
    //var dat2 = dat2_orig.replace(/T/g,' ');"
    var phone1 = phone;
    load_table(dat1,dat2,phone1);
    tot_amount(dat1,dat2,phone1);
}
function tot_amount(dat1,dat2,phone)
{
    document.getElementById("amount").innerHTML = " ";
	 document.getElementById("amount1").innerHTML = " ";
    $(document).ready(function(){
    $.ajax({
    type: "POST",
    url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/tot_bill.php",
    data: ({dt1:dat1,dt2:dat2,
            phone : phone
          }),
        dataType: "json",
        success: function (JSONObject) {
        JSONObject.forEach(function(json) { // <--- pass a function to forEach that takes a single object. This is called for every object in the array
        var total_ltr_price = json.total_ltr_price;
        document.getElementById("amount").innerHTML = total_ltr_price;
		document.getElementById("amount1").innerHTML = total_ltr_price;
		var tot_ltr = json.tot_ltr;
        document.getElementById("litres").innerHTML = tot_ltr;
        });
        }
        });
        });
}
</script>
</head>
<!--script type="text/javascript">
function SetDate1()
{
  //var phone = <a id = "phone"/>;
var myDate = new Date();
var day = myDate.getDate();
var month = myDate.getMonth() + 1;
var year = myDate.getFullYear();
//var h = myDate.getHours();
//var m = myDate.getMinutes();
//var s = myDate.getSeconds();
//var ampm = h >= 12 ? 'pm' : 'am';
if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;
//if (h < 10) month = "0" + h;
//if (m < 10) m = "0" + m;
//if (s < 10) s = "0" + s;
//var today1=dateFormat(new Date(), "yyyy-mm-dd h:MM:ss TT"); 
var today =  myDate.getFullYear()+ "-" + month + "-" + "01"; 
//var today =  "2018"+ "-" + "07" + "-" + "01" + "T" + "12" + ":" + "00" + ":" + "00";
var today2 =  myDate.getFullYear()+ "-" + month + "-" + "30";
//var dat1 = today.replace(/T/g,' ');
//var dat2 = today2.replace(/T/g,' ');
document.getElementById('dat_val1').value = today;
document.getElementById('dat_val2').value = today2;
//var sno="UTL0001"
//document.getElementById('sno').value = sno;
 billing(today,today2,phone);
 load_table(today,today2,phone);
}
</script>

<body onload="SetDate1();"-->

<body class=" ">
  <div class="se-pre-con"></div>
  <div class="wrapper">
    <div class="main-panel">
  <div class="container"> 
<div class='centered' >
<h2><b>Total Billing Report</b></h2>
<table><tr>
<th>FROM:</th>
<td>
<!--<input type="datetime-local" name="bdaytime">-->
<input type="date" id='dat_val1' placeholder="Enter Date1 (YYYY-MM-DD HH:mm:ss)" class="form-control" name="datefilter1" >
</td>
<th>TO:</th>
<td>
<input type="date" id='dat_val2' placeholder="Enter Date2 (YYYY-MM-DD HH:mm:ss)" class="form-control" name="datefilter2" >
</td>
<td>
<button type="submit" class="btn btn-info" onclick="billing(phone)">Apply</button>
</td></tr>

</table>
<br/>
<h3><b>Name :<script> document.write(name)</script></b></h3> 
<h3><b>Total amount of litres :<a id = "litres"></a></b></h3>
<h3><b>Total Amount: <a id = "amount"></a></b></h3>
 <!--h2>Total Amount: <a id = "amount"></a></h2-->
<!--h4>Click Apply to Fetch Details!!!</h4-->
<br/>
</div>

<style>
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
position: fixed;
left: 0px;
top: 0px;
width: 100%;
height: 100%;
    z-index: 9999;
background: url(images/loader-64x/Preloader_2.gif) center no-repeat #fff;
}
</style>
<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  margin-left: 410px;
  margin-bottom:20px;
  width: 100px;
  height: 100px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;  
  display: none;
}
.hid
{
display: none;
}
.centered{
width:500px;
margin:0 auto;
    
}
.centered_btn{
width:150px;
margin:0 auto;
}
label {
display: inline-block;
    margin-bottom: 1em;
    color : #cc65fe;
    <!--margin-left:50px;-->
}
/*h2{
 color : #cc65fe;
 }*/
input[type=text] {
border: 1px solid black;
    float: left;
margin: 0;
padding: 0;
    padding-right:20px;
    border-top: 0px;
    border-left: 0px;
    border-right: 0px;
    
}

/* Safari */
@-webkit-keyframes spin {
    0% { -webkit-transform: rotate(0deg); }
    100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
#amt
{
	margin-left:600px;
}
#amount
{
	
}
</style>
<div style="width:900px;">
<div class="container">
<div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header card-header-primary">
                                    <h4 class="card-title ">Billing calculation</h4>
                                    <p class="card-category"> Here is the total litres</p>
                                </div>
                                <div class="card-body">
                                    <!--<div class="table-responsive">-->
     <table id="survey" class="table table-hover">
     <thead class=" text-primary">
      <tr>
        
        <th><center>DATE</center></th>
        <th><center>LITRES</center></th>
		<th><center>PRICE(per litre)</center></th>
		<th><center>TOTAL</center></th>
      </tr> 
    </thead>
    <tbody>
    
    </tbody>
</table>
<script type="text/javascript">
function load_table(dt1,dt2,phone)
{
    document.getElementById('load').style.display='block';
    $("#survey tbody").empty();
    $(document).ready(function(){
                      $.ajax({
                             type: "POST",
                             url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/billdat_json.php",
							 //  url: "http://ec2-18-218-162-68.us-east-2.compute.amazonaws.com/milk/v3/bill_dat_phone.php",
							 
                             data: ({dt1:dt1,
                                    dt2:dt2,
                                    phone:phone
                                    }),
                             dataType: "json",
                             success: function (JSONObject) {
                                 $("#survey tbody").empty();
                             console.log(JSONObject);
                             // JSONObject.forEach(function(json) { // <--- pass a function to forEach that takes a single object. This is called for every object in the array
                             // var total_ltr_price = json.total_ltr_price;
                             // document.getElementById("amount").innerHTML = total_ltr_price;
                             // });
                             //data=json.parse(JSONObject);
                             var tabhtml = "";
                             for(var key in JSONObject){
                             if(JSONObject.hasOwnProperty(key)){
								 
                              var tabRow = "";
                             //tot_hours = "hours":"minutes":"seconds"
                             tabRow +="<tr>";
                             tabRow +="<td><center>"+ JSONObject[key]["date_val"]+"</center></td>";
                             tabRow +="<td><center>"+ JSONObject[key]["litres"]+"</center></td>";
							 tabRow +="<td><center>"+ JSONObject[key]["price"]+"</center></td>";
							 tabRow +="<td><center>"+ JSONObject[key]["total"]+"</center></td>";
                             tabRow +="</tr>";
                             console.log(tabRow);
                             tabhtml += tabRow;

                             }
                             }
                              document.getElementById('load').style.display='none';
                             $("#survey tbody").html(tabhtml);
                             
                             
                             }
                             });
                      });
}
</script>
<div class="loader" id="load" style="margin-left:300px;">
</div>
<h4 id = "amt"><b>Total Amount: <a id = "amount1"></a></b></h4>
 </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
