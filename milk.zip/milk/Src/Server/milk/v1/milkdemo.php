<?php
date_default_timezone_set('Asia/Kolkata');
$servername= "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password= "Appville@iot1";
$dbname= "ibcndb";
$today_date =date('Y-m-d H:i:s');
$get_phone=$_GET['phone'];
$get_name=$_GET['name'];
$get_address=$_GET['address'];
$get_litres=$_GET['litres'];
$get_str=$_GET['str'];
$get_city=$_GET['city'];
$conn= mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}
$db=mysqli_connect($servername, $username, $password, $dbname);
$sql="insert into customer_det(phone,name,address,street,city)values('$get_phone','$get_name','$get_address','$get_str','$get_city');";

$sql .="insert into litres_det(phone,litres,date_time)values('$get_phone','$get_litres','$today_date');";
if(mysqli_multi_query($db,$sql))
{
echo "created successfully";
}
else
{
echo "error".$sql."<br>".mysqli_error($conn);
}
$sql1="update litres_det set litres='$litres' where phone='$phone'";

if($conn->query($sql1)==TRUE)
	{
	echo "SUCCESS";
	}
	else
	{
    echo "Error updating table: ".$conn->error;
}

mysqli_close($conn);
?>