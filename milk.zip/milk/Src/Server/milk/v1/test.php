<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password = "Appville@iot1";
$dbname = "ibcndb";
$get_phone=$_GET['phone'];
$get_name=$_GET['name'];
$get_address=$_GET['address'];
$get_litres=$_GET['litres'];
$get_str=$_GET['str'];
$get_city=$_GET['city'];
$today_date=date('Y-m-d H:i:s');
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection

if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 

if(preg_match("/^[0-9]{10}$/", $get_phone)) {
$sql1="insert into customer_det(phone,name,address,street,city)values('$get_phone','$get_name','$get_address','$get_str','$get_city');";
$sql ="insert into litres_det(phone,litres)values('$get_phone','$get_litres');";
$sql2="insert into history_tab(phone,datetime,litres)values('$get_phone','$today_date','$get_litres');";
if(($conn->query($sql1) == TRUE)&& ($conn->query($sql) == TRUE) && ($conn->query($sql2) == TRUE))
{
	echo "SUCCESS";
}
else
{
	echo "Error inserting table: " .$conn->error;
}
}
else
{
	echo "Phone number should be 10 digits";
}
mysqli_close($conn);
	?>