<?php
$servername = "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password = "Appville@iot1";
$dbname = "ibcndb";
//$shift_date = $_GET['shift_date']
$shift_date = date("Y-m-d");
//echo $shift_date;
$up_time = $_GET['up_time'];
$idle_time = $_GET['idle_time'];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


// sql to create table
$sql ="INSERT INTO MyGuests2 (shift_date, up_time, idle_time)
VALUES ('$shift_date',$up_time,$idle_time);";
echo $sql;
if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests inserted successfully";
} else {
    echo "Error inserting table: " . $conn->error;
}

$conn->close();
?>