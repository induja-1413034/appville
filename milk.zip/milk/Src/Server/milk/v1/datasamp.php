<!DOCTYPE html>
<head>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.2.5/css/select.dataTables.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.5/js/dataTables.select.min.js"></script>
<script>
$(document).ready(function(){
    $('#survey').DataTable();
});
</script>
</head>
<body>
<br><br>

<script>
function myFunction() {
    window.print();
}
</script>
<table id="survey" class="table table-striped table-bordered" cellspacing="0" width="100%" border="1">
<thead>
<tr>
<th>PHONE</th>
<th>NAME</th>
<th>ADDRESS</th>
<th>STREET</th>
<th>CITY</th>
<th>LITRES</th>
</tr>
</thead>
<tbody>
<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password = "Appville@iot1";
$dbname = "ibcndb";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
die("Connection failed: " . $conn->connect_error);
}
	$check="select * from survey order by name asc";
    $i=0;
	$rs = mysqli_query($conn, $check);
while($row = mysqli_fetch_array($rs))
  {
  $phone= $row['phone'];
  $name=$row['name'];
  $address=$row['address'];
  $street=$row['street'] ;
  $city=$row['city'];
  $litres=$row['litres'];
  ?>
  <tr>
  <td><?php echo $phone; ?></td>
  <td><?php echo $name; ?></td>
  <td><?php echo $address; ?></td>
  <td><?php echo $street; ?></td>
  <td><?php echo $city; ?></td>
  <td><?php echo $litres; ?></td>
  </tr>
  <?php 
  }
 mysqli_close($conn);
 ?>
 </tbody>
 </table>
 <p align="right"><input type="button" id="print" value="print" button onclick="myFunction()"></button></p>
</body>
</html>
             
     