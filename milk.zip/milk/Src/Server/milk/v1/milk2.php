<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password = "Appville@iot1";
$dbname = "ibcndb";
$today_date =date('Y-m-d H:i:s');
$get_phone=$_GET['phone'];
$get_litres=$_GET['litres'];
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 
$sql1="insert into litres_det(phone,litres)values('$get_phone','$get_litres');";
if ($conn->query($sql1) ==TRUE)
	{
		echo "SUCCESS";
	} 
	else
	{
		echo "Error inserting table: " . $conn->error;
	}
	?>