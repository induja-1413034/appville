<!DOCTYPE html>
<head>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.16/css/dataTables.jqueryui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function(){
    $('#survey').DataTable( {
	"pageLength": 100
})
});
$(document).ready(function() {
    var table = $('#survey').DataTable();
 
    $('#survey tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
 
    $('#button').click( function () {
        table.row('.selected').remove().draw( false );
    } );
} );
/*$('#example').dataTable( {
  "pageLength": 50
} );*/
</script>
</head>
<body>
<br><br>
<script>
function myFunction() {
    window.print();
}
</script>
<table id="survey" class="table table-striped table-bordered" cellspacing="0" width="100%">
<thead>
<tr>
<th>PHONE</th>
<th>NAME</th>
<th>ADDRESS</th>
<th>STREET</th>
<th>CITY</th>
<th>LITRES</th>
</tr>
</thead>
<tbody>
<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
die("Connection failed: " . $conn->connect_error);
}
	$check="select * from survey ";
    $i=0;
	$rs = mysqli_query($conn, $check);
	//echo mysqli_num_rows($rs);
while($row = mysqli_fetch_assoc($rs))
  {
  $phone= $row['phone'];
  $name=$row['name'];
  $address=$row['address'];
  $street=$row['street'] ;
  $city=$row['city'];
  $litres=$row['litres'];
  ?>
  <tr>
  <td><center><?php echo $phone; ?></center></td>
  <td><center><?php echo $name; ?></center></td>
  <td><center><?php echo $address; ?></center></td>
  <td><center><?php echo $street; ?></center></td>
  <td><center><?php echo $city; ?></center></td>
  <td><center><?php echo $litres; ?></center></td>
  </tr>
  <?php 
  }
 mysqli_close($conn);
 ?>
 </tbody>
 </table>
 <p align="right"><input type="button" id="print" value="Print" button onclick="myFunction()"></button></p>
 <p align="top"><input type="button" id="button" value="Delete rows"></button></p>
</body>
</html>
             
     