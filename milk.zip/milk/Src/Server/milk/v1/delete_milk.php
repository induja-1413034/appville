<?php
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$phone=$_REQUEST['phone'];
//$litres= $_GET['litres'];
$today_date=date('Y-m-d H:i:s');
$conn =mysqli_connect($servername,$username, $password,$dbname) ;
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 
$check="select*from survey where phone='$phone'";
$res=mysqli_query($conn,$check);
$data1=mysqli_num_rows($res);
//echo $data1;
//$messages = array();
//foreach ( $_GET['phone'] as $row ) {
    // DELETE IT HEREs
if(($data1)==1)
{
	$sql1="delete from customer_det where phone='$phone'";
	$sql2="delete from history_tab where phone='$phone'";
	$sql="delete from litres_det where phone='$phone'";
	if((mysqli_query($conn,$sql1) == TRUE)&&(mysqli_query($conn,$sql2) == TRUE)&&(mysqli_query($conn,$sql)))
	{
		echo "SUCCESSFULLY DELETED";
	}
	else
	{
		echo "Error".$conn->error;
	}
}
else
{
	echo "Error:Number not registered";
}
?>