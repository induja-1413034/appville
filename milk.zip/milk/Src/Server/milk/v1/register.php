<?php
$servername = "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password = "Appville@iot1";
$dbname = "ibcndb";
$name=$_POST['name1']; // Fetching Values from URL.
$phone=$_POST['phone1'];
$address= $_POST['address1'];
$street= $_POST['street1'];
$city= $_POST['city1'];
$consumption= $_POST['consumption1'];
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 
$db= mysqli_connect($servername, $username, $password, $dbname);
$check_query="SELECT * FROM customer_det WHERE phone= '$phone'";
$result = mysqli_query($db,$check_query);
$data=mysqli_num_rows($result);
if(($data)==0)
{
$sql="insert into customer_det(phone,name,address,street,city)values('$phone','$name','$address','$street','$city');";
$sql .="insert into litres_det(phone,litres)values('$phone','$consumption');";
if(mysqli_multi_query($db,$sql)){
	echo "SUCCESS";
}
else{
	echo "Error:".$sql."<br>".mysqli_error($conn);
}
}
else{
echo "This Number is already registered";
}
mysqli_close($conn);
?>