<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password = "Appville@iot1";
$dbname = "ibcndb";
$today_date =date('Y-m-d H:i:s');
$get_phone=$_GET['phone'];
$get_name=$_GET['name'];
$get_address=$_GET['address'];
$get_sno=$_GET['Sno'];
$get_litres=$_GET['litres'];
$get_str=$_GET['str'];
$get_city=$_GET['city'];

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 

$sql="insert into customer_det(Sno,phone,name,address,street,city)values('$get_sno','$get_phone','$get_name','$get_address','$get_str','$get_city');";
$sql1="insert into litres_det(phone,litres)values('$get_phone','$get_litres');";
//$sno=mysql_insert_id();
//$sql1=mysql
if ($conn->query($sql) ==TRUE && $conn->query($sql1)==TRUE)
	{
		echo "SUCCESS";
	} 
	else
	{
		echo "Error inserting table: " . $conn->error;
	}
	
	
$conn->close();
	?>
