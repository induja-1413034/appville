<?php
$servername = "appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com";
$username = "appville_user";
$password = "Appvilleiot1";
$dbname = "appvilledb";
$name=$_POST['name1']; // Fetching Values from URL.
$phone=$_POST['phone1'];
$address= $_POST['address1'];
$street= $_POST['street1'];
$city= $_POST['city1'];
$consumption= $_POST['consumption1'];
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection

if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
} 

if(preg_match("/^[0-9]{10}$/", $phone)) {
$check_query="SELECT * FROM customer_det WHERE phone= '$phone'";
$result = mysqli_query($conn,$check_query);
$data=mysqli_num_rows($result);
if(($data)==0)
{
$sql="insert into customer_det(phone,name,address,street,city)values('$phone','$name','$address','$street','$city');";
$sql1="insert into litres_det(phone,litres)values('$phone','$consumption');";
if((mysqli_query($conn,$sql)==TRUE) && (mysqli_query($conn,$sql1)==TRUE) ){
	echo "SUCCESS";
}
else{
	echo "Error:".$sql."<br>".mysqli_error($conn);
}
}
else{
echo "This Number is already registered";
}
}
else{
	echo "phone number should be 10 digits";
	}
mysqli_close($conn);
?>