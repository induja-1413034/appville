
<?php
date_default_timezone_set('Asia/Kolkata');
$servername = "ibcndb.db.11170066.hostedresource.com";
$username = "ibcndb";
$password = "Appville@iot1";
$dbname = "ibcndb";
$today_date =date('Y-m-d H:i:s');
$get_phone=$_GET['phone'];
$get_litres=$_GET['litres'];
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
	
	}
	$check="select * from survey order by name asc";
    $i=0;
	$rs = mysqli_query($conn, $check);
echo "<table border='2'><H1>
<tr>
<th>PHONE</th>
<th>NAME</th>
<th>ADDRESS</th>
<th>STREET</th>
<th>CITY</th>
<th>LITRES</th></H1>
</tr>";
while($row = mysqli_fetch_array($rs))
  {
  echo "<tr>";
  echo "<td>" . $row['phone'] . "</td>";
  echo "<td>" . $row['name'] . "</td>";
  echo "<td>" . $row['address'] ."</td>";
  echo "<td>" . $row['street'] ."</td>";
  echo "<td>" . $row['city']."</td>";
  echo "<td>" . $row['litres']."</td>";
  echo "</tr>";
  }
echo "</table>";
 mysqli_close($conn);
/*$fetch_arr = array();
	while($row=mysqli_fetch_assoc($rs))
	{
		$fetch_arr[$i]['phone']=$row['phone'];
		$fetch_arr[$i]['name']=$row['name'];
	$fetch_arr[$i]['address']=$row['address'];
	$fetch_arr[$i]['litres']=$row['litres'];
	$i++;
	}
	print json_encode($fetch_arr);*/
	?>
	