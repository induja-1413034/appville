-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com    Database: appvilledb
-- ------------------------------------------------------
-- Server version	5.6.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hos_mac_det`
--

DROP TABLE IF EXISTS `hos_mac_det`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hos_mac_det` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `data_id` int(11) DEFAULT NULL,
  `machine_serial` varchar(45) DEFAULT NULL,
  `machine_speed` varchar(45) DEFAULT NULL,
  `production_speed` varchar(45) DEFAULT NULL,
  `actual_path` varchar(45) DEFAULT NULL,
  `hose_diameter` varchar(45) DEFAULT NULL,
  `tape_width` varchar(45) DEFAULT NULL,
  `tape_thickness` varchar(45) NOT NULL,
  `spool_tension_wrap` varchar(45) DEFAULT NULL,
  `control_tension_wrap` varchar(45) DEFAULT NULL,
  `brand_tension_unwrap` varchar(45) DEFAULT NULL,
  `overlap` varchar(45) DEFAULT NULL,
  `pitch_wrap` varchar(45) DEFAULT NULL,
  `pitch_unwrap` varchar(45) DEFAULT NULL,
  `actual_dwell_angle` varchar(45) DEFAULT NULL,
  `wrap_unwrap_button` varchar(45) DEFAULT NULL,
  `jog_speed` varchar(45) DEFAULT NULL,
  `low_speed` varchar(45) DEFAULT NULL,
  `run_speed` varchar(45) DEFAULT NULL,
  `stop_speed` varchar(45) DEFAULT NULL,
  `homing_done` varchar(45) DEFAULT NULL,
  `set_jog_speed` varchar(45) DEFAULT NULL,
  `set_low_speed` varchar(45) DEFAULT NULL,
  `set_run_speed` varchar(45) DEFAULT NULL,
  `cummulative_run_length` varchar(45) DEFAULT NULL,
  `machine_healthy_time` varchar(45) DEFAULT NULL,
  `machine_running_shift_time` varchar(45) DEFAULT NULL,
  `machine_fault_shift_time` varchar(45) DEFAULT NULL,
  `plc_time` varchar(45) DEFAULT NULL,
  `machine_number` varchar(45) DEFAULT NULL,
  `flag_run_active` varchar(45) DEFAULT NULL,
  `spool_tension_unwrap` varchar(45) DEFAULT NULL,
  `brand_tension_wrap` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`sno`,`tape_thickness`)
) ENGINE=InnoDB AUTO_INCREMENT=575 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-15  8:15:42
