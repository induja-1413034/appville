-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com    Database: appvilledb
-- ------------------------------------------------------
-- Server version	5.6.37-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `milk_bill_aggregate_view`
--

DROP TABLE IF EXISTS `milk_bill_aggregate_view`;
/*!50001 DROP VIEW IF EXISTS `milk_bill_aggregate_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `milk_bill_aggregate_view` AS SELECT 
 1 AS `phone`,
 1 AS `litres`,
 1 AS `price`,
 1 AS `total_ltr_price`,
 1 AS `tot_ltr`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `milk_survey_bill`
--

DROP TABLE IF EXISTS `milk_survey_bill`;
/*!50001 DROP VIEW IF EXISTS `milk_survey_bill`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `milk_survey_bill` AS SELECT 
 1 AS `Sno`,
 1 AS `phone`,
 1 AS `name`,
 1 AS `address`,
 1 AS `street`,
 1 AS `city`,
 1 AS `litres`,
 1 AS `zone`,
 1 AS `zone_id`,
 1 AS `amount_paid`,
 1 AS `date_of_pay`,
 1 AS `tot_amount`,
 1 AS `tot_ltr`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `milk_bill_aggregate_view`
--

/*!50001 DROP VIEW IF EXISTS `milk_bill_aggregate_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`appville_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `milk_bill_aggregate_view` AS select `milk_bill`.`phone` AS `phone`,`milk_bill`.`litres` AS `litres`,`milk_bill`.`price` AS `price`,sum((`milk_bill`.`litres` * `milk_bill`.`price`)) AS `total_ltr_price`,sum(`milk_bill`.`litres`) AS `tot_ltr` from `milk_bill` group by `milk_bill`.`phone` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `milk_survey_bill`
--

/*!50001 DROP VIEW IF EXISTS `milk_survey_bill`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`appville_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `milk_survey_bill` AS select distinct `s`.`Sno` AS `Sno`,`s`.`phone` AS `phone`,`s`.`name` AS `name`,`s`.`address` AS `address`,`s`.`street` AS `street`,`s`.`city` AS `city`,`s`.`litres` AS `litres`,`z`.`zone` AS `zone`,`s`.`zone_id` AS `zone_id`,`s`.`amount_paid` AS `amount_paid`,`s`.`date_of_pay` AS `date_of_pay`,`bill`.`total_ltr_price` AS `tot_amount`,`bill`.`tot_ltr` AS `tot_ltr` from ((`milk_customer_det` `s` left join `milk_zone` `z` on((`s`.`zone_id` = `z`.`sno`))) left join `milk_bill_aggregate_view` `bill` on((`s`.`phone` = `bill`.`phone`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping routines for database 'appvilledb'
--
/*!50003 DROP PROCEDURE IF EXISTS `all_billing` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `all_billing`(in startdate date,in enddate date)
BEGIN
  declare id_val int;
  declare x int;
    declare y int;
    declare dat1 date;
    declare dat2 date;
  declare aday int;
set x = 0;
  set aday = 24*3600;
  set id_val = 15;
  #set dat1 = '2018-07-03';
set dat1 = startdate;
set dat2 = enddate;
set y = datediff(dat2,dat1);
  #set dd = now();
   
    DROP temporary table IF EXISTS `temp_billing_value`;
  create temporary table temp_billing_value(id int(10) not null primary key auto_increment,date_val date not null) ;
  while x <= y   do
    insert into temp_billing_value(id,date_val) values (id_val,dat1);
      #set dat1 = dat1 + aday;
     set x = x+1;
   set dat1 = date_add(dat1 , interval 1 day);
    set id_val = id_val+1;
end while;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `all_det_billing` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `all_det_billing`(in id_val varchar(10),in startdate date,in enddate date)
    NO SQL
BEGIN
declare x date;
declare y date;
set x= startdate;
set y = enddate;
while x<=y
do
/*set x = (select ADDDATE(date,interval 1 day) from temp_billing_value);
/*SELECT TOP (DATEDIFF(MONTH, CONVERT(DATE, x, 105),CONVERT(DATE, y, 105))+1)
    DATEADD(MONTH, ROW_NUMBER() OVER (ORDER BY name)-1, CONVERT(DATE, x, 105))
    FROM temp_billing_value*/
insert into temp_billing_value values(id_val,x);
set x = DATE_ADD(x,INTERVAL 1 DAY);
#select  t.date_val,m.litres from temp_billing_value t left join milk_historydat_tab m  on (m.date_val=t.date_val) and m.phone='9994293232';

#set x =(select DATEADD(DAY,1,x));
/*set x = (select DATE_ADD(x,interval 1 day)as date_1);*/ 
#set x = x+1;  
end while;
select  t.date_val,m.litres from temp_billing_value t left join milk_historydat_tab m  on (m.date_val=t.date_val) and m.phone='9994293232';

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `billing_proc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `billing_proc`(in phone varchar(10))
BEGIN
  
DROP  temporary table IF EXISTS `temp_billing`;
#SELECT datetime,litres from milk_history_tab where datetime>=dat1 and datetime<=dat2 and phone=phone_no;
create temporary table temp_billing (`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as
#while x < y   do
	#if exists(select datetime,litres from milk_history_tab where date(datetime) = dat1)
    #then
    select  t.date_val,m.litres from temp_billing_value  t left join  milk_historydat_view m  on (m.date_val=t.date_val) and m.phone=phone  order by date_val;

	#select datetime as dt1,litres as ltr from appvilledb.milk_history_tab where phone=phone_no and date(datetime) = dat1 order by datetime desc limit 1 ;
    #insert into temp_billing(date_time,litres) values (dat1,'5');
    #set dat1 = date_add(dat1 , interval 1 day);  
   # else 
	#select datetime as dt1,litres as ltr from appvilledb.milk_history_tab where phone=phone_no and date(datetime) =  dat1 order by datetime desc limit 1 ;
    #insert into temp_billing(date_time,litres) values (dat1,ltr);
    #set dat1 = date_add(dat1 , interval 1 day);
    #end if; 
    #select * from temp_billing_value  left join milk_historydat_tab  on  milk_historydat_tab.sno = temp_billing_value.pid
#end while;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_err_table` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `create_err_table`(IN dat_from datetime, IN dat_to datetime, IN err_code varchar(25), IN mac_serial varchar(10) )
BEGIN

DROP table IF EXISTS `temp_error_report_for_code`;
create table temp_error_report_for_code (`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as
SELECT  dat.time_recv,dat.time, err.error_code, dat.sno as group_num, err_info.error_details as error_details FROM utl_data dat 
	left join utl_mac_error err on dat.sno = err.data_id AND err.error_code = err_code
    left join utl_mac_det mac on dat.sno = mac.data_id
    left join utl_error_info err_info on err_info.error_code = err.error_code
where (dat.time_recv) >= dat_from and dat.time_recv <=dat_to  and mac.machine_serial= mac_serial and dat.time <1000
order by dat.time_recv asc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_err_table_v2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `create_err_table_v2`(IN dat_from datetime, IN dat_to datetime, IN err_code varchar(25), IN mac_serial varchar(10))
BEGIN

create table temp_error_report_for_code_v2 (`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as
SELECT  dat.time_recv,dat.time, err.error_code, dat.sno as group_num FROM utl_data dat 
	left join utl_mac_error err on dat.sno = err.data_id AND err.error_code = err_code 
    left join utl_mac_det mac on dat.sno = mac.data_id
where (dat.time_recv) >= dat_from and dat.time_recv <=dat_to and mac.machine_serial= mac_serial and dat.time <1000
order by dat.time_recv asc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `create_recipe_table` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `create_recipe_table`(IN dat_from datetime, IN dat_to datetime, IN recipe_name varchar(25), IN mac_serial varchar(10))
BEGIN

DROP table IF EXISTS `temp_recipe_report_for_code`;
create table temp_recipe_report_for_code (`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as
SELECT  dat.time_recv,dat.time,recipe.recipe_name,dat.sno as group_num FROM utl_data dat 
	left join utl_mac_det recipe on dat.sno = recipe.data_id
where (dat.time_recv) >= dat_from and dat.time_recv <=dat_to  and mac.machine_serial= mac_serial and dat.time <1000
order by dat.time_recv asc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ital_bird_proc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `ital_bird_proc`(IN dat_from datetime, IN dat_to datetime)
BEGIN
DROP  table IF EXISTS `temp_is_error`;
create table temp_is_error(`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as
    SELECT 
        `dat`.`sno` AS `is_error`,
        `dat`.`date_time` AS `date_time`,
        ROUND((`dat`.`time` / 60), 2) AS `time_in_min`,
        GROUP_CONCAT(`err`.`error_code`
            SEPARATOR ',') AS `err_concat`
    FROM
        (`appvilledb`.`ital_data` `dat`
        LEFT JOIN `appvilledb`.`ital_error_detail` `err` ON ((`dat`.`sno` = `err`.`data_id`)))
   
   where (dat.date_time) >= dat_from and dat.date_time <=dat_to
   GROUP BY `dat`.`sno`
    ORDER BY `dat`.`date_time` DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ital_create_err_table` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `ital_create_err_table`(IN dat_from datetime, IN dat_to datetime, IN err_code varchar(25) )
BEGIN

DROP temporary table IF EXISTS `ital_error_report_for_code`;
create temporary  table ital_error_report_for_code (`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as
SELECT  dat.date_time,dat.time, err.error_code,err_info.error_detail, dat.sno as group_num FROM ital_data dat 
	left join ital_error_detail err on dat.sno = err.data_id AND err.error_code = err_code
    left join ital_error_info   err_info on err.error_code = err_info.error_code
where (dat.date_time) >= dat_from and dat.date_time <=dat_to 
order by dat.date_time asc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `milk` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `milk`(in x datetime,in y datetime,out date_timeout datetime,out litres_out int)
BEGIN
/*declare z int;
set z=x;
while (z<y) do
begin
select date_time into date_timeout from diff_table where id=z;
select data_time into date_timeout1 from diff_table order by id limit 1;
set z=z+1;
end;
end while;*/
declare a int;
declare b int;
set a=1;
set b=60;
while(a<=b)
do
begin
select datetime,litres into date_timeout,litres_out from history_tab where datetime=x; /*and datetime<=y;*/
set a=a+1;
end;
end while;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `milk_server` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `milk_server`()
BEGIN
declare cur_id int;
declare cur_date datetime;
declare cur_lit float;
declare done int default false;
declare cur_i cursor for select id,date_time,litres from mi_tab;
declare continue handler for not found set done=true;
open cur_i;
read_loop:loop
fetch cur_i into cur_id,cur_date,cur_lit;
if done then 
leave read_loop;
end if;
/*insert into mil_tab(id,date_time,litres)values(cur_id,cur_date,cur_lit);*/
update mil_tab set litres=1 where (select count(litres) from mi_tab);
end loop;
close cur_i;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `organize_error_table` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `organize_error_table`()
BEGIN
declare prev_err int;
/*declare next_1 int;*/
declare count int; declare icount int; declare max_count int;
declare err_code int; declare grp_num int; declare s_no int;
/*set prev_err = 0;*/
declare first_Cursor cursor for select  error_code,sno from temp_error_report_for_code_v2 ;
set icount = (select count(*) from temp_error_report_for_code_v2);
/*declare var varchar (10);*/
select icount;
set prev_err=0; set grp_num = 1; 
open first_Cursor ;
while icount >0
do
      begin
         fetch first_Cursor into err_code, s_no;
         if (err_code != prev_err)
         then
			begin
				set grp_num = grp_num +1;	
                set prev_err = err_code;
			end;
         end if;
     
         update  temp_error_report_for_code_v2 set  group_num = grp_num where sno=s_no;
         set icount = icount -1;
         select icount;
		end;
		
end while;
close first_Cursor ;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `organize_error_table_unused` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `organize_error_table_unused`()
BEGIN

DECLARE counter INTEGER DEFAULT 0;
DECLARE v_finished INTEGER DEFAULT 0;
DECLARE v_sno int;
DECLARE v_err varchar(25) default '0';
DECLARE prev_error varchar(25) default '-1';
DECLARE cursor_sno CURSOR FOR SELECT sno, error_code FROM temp_error_report_for_code;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_finished = 1;

OPEN cursor_sno;
 
 iterate_error: LOOP
 
 FETCH cursor_sno INTO v_sno, v_err;
 
 IF v_finished = 1 THEN 
 LEAVE iterate_error;
 END IF;
 
 update temp_error_report_for_code set group_num=counter where sno = v_sno;
 -- build email list
 -- update 
 IF @prev_error != v_err then
 SET counter = counter + 1;
 end if;
 
 SET @prev_error = v_err;
 
 END LOOP iterate_error;
 
 CLOSE cursor_sno;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `temporary_table` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `temporary_table`(IN dat_from datetime, IN dat_to datetime, IN err_code varchar(25))
BEGIN
drop temporary table if exists temp_tab;
create temporary table temp_tab (`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as

SELECT  dat.time_recv, dat.time, err.error_code, dat.sno as group_num FROM utl_data dat 
	left join utl_mac_error err on dat.sno = err.data_id AND err.error_code = err_code
where (dat.date_time) >= dat_from and dat.date_time <=dat_to
order by time_recv asc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `test_proc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`appville_user`@`%` PROCEDURE `test_proc`(IN dat VARCHAR(25), IN err_code varchar(25))
BEGIN

DECLARE counter INTEGER DEFAULT 0;
DECLARE v_finished INTEGER DEFAULT 0;
DECLARE v_sno int;
DECLARE cursor_sno CURSOR FOR SELECT sno FROM temp_error_report_for_code;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_finished = 1;

DROP table IF EXISTS `temp_error_report_for_code`;

create table temp_error_report_for_code (`sno` int(11) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`sno`))
as

SELECT  dat.time_recv, dat.time, err.error_code, dat.sno as group_num FROM utl_data dat 
	left join utl_mac_error err on dat.sno = err.data_id AND err.error_code = err_code
where date(dat.date_time) = dat
order by time_recv asc;

OPEN cursor_sno;
 
 iterate_error: LOOP
 
 FETCH cursor_sno INTO v_sno;
 
 IF v_finished = 1 THEN 
 LEAVE iterate_error;
 END IF;
 
 update temp_error_report_for_code set group_num=counter where sno = v_sno;
 -- build email list
 -- update 
 SET counter = counter + 1;
 
 END LOOP iterate_error;
 
 CLOSE cursor_sno;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-15  9:07:46
