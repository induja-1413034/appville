﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models2;
using Microsoft.AspNetCore.Mvc;
using milk.Models2;
//using static milk.Models2.Bill;

namespace milk.Controllers
{
    public class BillingController : Controller
    {
        private appvilledbContext _context;

        public IActionResult BillingMobile(string id)
        {
            _context = new appvilledbContext();
            if (id == null)
            {
                ViewBag.Message = "Phone Number Cannot Be null";
            }
            var billlist1 = _context.MilkCustomerDet.Where(x => x.phone == id).FirstOrDefault();
            if (billlist1 == null)
            {
                ViewBag.Message = "Phone Number does not Exist";
            }
            else
            {               
                var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(id));
                string format = "₹#,##0.00;-₹#,##0.00;₹0";              
            }
            return View();
        }

        [HttpPost]
        public IActionResult BillingMobile(string id, string Month)
        {
            try
            {
                ViewBag.MonthPicker = Month;
                _context = new appvilledbContext();
                if (id == null)
                {
                    ViewBag.Message = "Phone number does not Exist";
                }
                else
                {
                    string format = "";                    
                    var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(id));
                    format = "₹#,##0.00;-₹#,##0.00;₹0";
                    
                   
                    string[] dateString = Month.Split('-');
                    string[] month_array = new string[13] { "default","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
                    int month = 0;
                    for(int i = 0; i < month_array.Length; i++)
                    {
                        if (month_array[i].Equals(dateString[0]))
                        {
                                month = i;
                        }
                    }                    
                    DateTimeFormatInfo mn = new DateTimeFormatInfo();
                    int year = Convert.ToInt32(dateString[1]);                 
                    int days = DateTime.DaysInMonth(year, month);
                    int month_next = 0;
                    if (month == 12) { 
                    month_next = 0 + 1;
                    }
                    else
                    {
                        month_next = month + 1;
                    }
                    int days_next_month = DateTime.DaysInMonth(year, month_next);
                   

                    List<Bill> Billlist = new List<Bill>();       
                    
                    DateTime enter_date = Convert.ToDateTime(year + "/" + month + "/" + 01);
                    DateTime end_date = Convert.ToDateTime(year + "/" + month + "/" + days);

                    DateTime enter_date_next_month = Convert.ToDateTime(year + "/" + month_next + "/" + 01);
                    DateTime end_date_next_month = Convert.ToDateTime(year + "/" + month_next + "/" + days_next_month);

                    var details1 = _context.MilkBill.Where(y => y.phone.Equals(id) && (y.date>= enter_date && y.date<= end_date)).Select(x => x.price * x.litres).ToList();
                    var total_amount = details1.Sum();
                    var details3 = _context.MilkAmountPay.Where(y => y.phone.Equals(id) && (y.date_of_pay >= enter_date_next_month && y.date_of_pay <= end_date_next_month)).Select(x => x.amount_paid).ToList();
                    var amount_paid = details3.Sum();
                    var balance = total_amount - amount_paid;
                    //ViewBag.Balance = details.balance_amount_to_pay.ToString(format);
                  //  ViewBag.Date = DateTime.Now.ToShortDateString();
                    ViewBag.Balance = balance.ToString(format);
                    ViewBag.Month = mn.GetMonthName(month);
                    var billlist2 = _context.MilkAmountPay.Where(x => x.phone == id & x.date_of_pay >= enter_date_next_month & x.date_of_pay <= end_date_next_month).Select( x=> new BillPay { date_of_pay = x.date_of_pay.Date.ToString("dd'/'MM'/'yyyy"), amount_paid =x.amount_paid.ToString(format) });                    

                    ViewBag.Payment = billlist2;
                    ViewBag.Count = billlist2.Count();

                    var billlist1 = _context.MilkBill.Where(x => x.phone == id & x.date >= enter_date & x.date <= end_date).Select(x => new Bill { litres = x.litres, price = x.price, date = x.date.Date.ToString("dd'/'MM'/'yyyy"), Total = x.litres * x.price }).ToList();
                    ViewBag.Name = _context.MilkCustomerDet.Where(x => x.phone == id).Select(x => x.name).FirstOrDefault();
                    string Totallitres = billlist1.Sum(x => x.litres).ToString();
                    ViewBag.Totallitres = string.Format("{0} litres", Totallitres);
                    format = "₹#,##0.00;-₹#,##0.00;₹0";
                    ViewBag.TotalAmount = billlist1.Sum(x => x.Total).ToString(format);                   
                    ViewBag.Bill = billlist1;
                }
                return View();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public class Bill
        {
            public int litres;
            public int price;
            //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}",
            //  ApplyFormatInEditMode = true)]
            public string date;
            public int Total;
        }

        public class BillPay
        {
            //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}",
            //  ApplyFormatInEditMode = true)]
            public string date_of_pay;
            public string amount_paid;
        }


        [HttpGet]
        public IActionResult MilkRequirement(string id, string fromdate, string todate)
        {
            try
            {
                MilkSchedule milkscheduleinstance = null;
                if (fromdate == null & todate == null)
                {
                    return View();
                }
                else
                {                   
                    string[] dateString = fromdate.Split('-');
                    string[] dateString1 = todate.Split('-');
                    DateTime enter_date = Convert.ToDateTime(dateString[2] + "/" + dateString[1] + "/" + dateString[0]);
                    DateTime end_date = Convert.ToDateTime(dateString1[2] + "/" + dateString1[1] + "/" + dateString1[0]);                    
                    _context = new appvilledbContext();
                    List<MilkSchedule> Req_list = new List<MilkSchedule>();
                    var Req_list1 = _context.MilkSchedule.Where(x => x.date >= enter_date & x.date <= end_date & x.phone == id).ToList();
                    var litresdetails = _context.MilkCustomerDet.Where(x => x.phone == id).Select(x => x.litres).FirstOrDefault();
                    if (litresdetails == 0)
                    {
                        ViewBag.Message = "Phone number does not exist";
                    }
                    else
                    {
                        for (DateTime i = enter_date; i <= end_date; i = i.AddDays(1))
                        {
                            milkscheduleinstance = new MilkSchedule();
                            milkscheduleinstance.phone = id;
                            var litres_det = Req_list1.Where(x => x.date == i).Select(x => x.litres).FirstOrDefault();
                            if (litres_det == 0)
                            {
                                milkscheduleinstance.litres = litresdetails;
                            }
                            else
                            {
                                milkscheduleinstance.litres = litres_det;
                            }
                            milkscheduleinstance.date = i;
                            Req_list.Add(milkscheduleinstance);
                        }
                    }
                    MilkScheduleDetail milkschedule = new MilkScheduleDetail();
                    milkschedule.MilkScheduleDetails = Req_list;

                    return View(milkschedule);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult MilkRequirement(string id, [Bind("MilkScheduleDetails")]MilkScheduleDetail milk)
        {
            try
            {
                _context = new appvilledbContext();
                if (milk.MilkScheduleDetails != null)
                {
                    var litresdetails = _context.MilkCustomerDet.Where(x => x.phone == id).Select(x => x.litres).FirstOrDefault();
                    var Billlist = milk.MilkScheduleDetails.Where(x => x.litres != litresdetails).ToList();
                    foreach (var item in Billlist)
                    {
                        item.phone = id;
                        var details = _context.MilkSchedule.Where(x => x.phone == id & x.date == item.date).FirstOrDefault();
                        if (details != null)
                        {
                            details.litres = item.litres;
                            _context.MilkSchedule.Update(details);
                            _context.SaveChanges();
                        }
                        else
                        {
                            _context.MilkSchedule.Add(item);
                            _context.SaveChanges();
                        }
                    }
                    ViewBag.Message = "Success; Your Requirement Saved";
                }
                else
                {
                    ViewBag.Message = "No data";
                }
                return View();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public IActionResult PaymentHistory(string id)
        {
            _context = new appvilledbContext();
            var billlist1 = _context.MilkCustomerDet.Where(x => x.phone == id).FirstOrDefault();
            if (billlist1 == null)            
                ViewBag.Message = "Phone Number does not Exist";           
            return View();
        }

        [HttpPost]
        public IActionResult PaymentHistory(string id, string fromdate, string todate)
        {
            _context = new appvilledbContext();
            string[] dateString = fromdate.Split('-');
            string[] dateString1 = todate.Split('-');
            DateTime enter_date = Convert.ToDateTime(dateString[2] + "/" + dateString[1] + "/" + dateString[0]);
            DateTime end_date = Convert.ToDateTime(dateString1[2] + "/" + dateString1[1] + "/" + dateString1[0]);
            if (id == null)
            {
                ViewBag.Message = "Phone Number Cannot Be null";
            }
            var billlist1 = _context.MilkCustomerDet.Where(x => x.phone == id).FirstOrDefault();
            if (billlist1 == null)
            {
                ViewBag.Message = "Phone Number does not Exist";
            }
            else
            {
                var billlist2 = _context.MilkAmountPay.Where(x => x.phone == id & x.date_of_pay >= enter_date & x.date_of_pay <= end_date).ToList();               
                ViewBag.Payment = billlist2;
                ViewBag.Count = billlist2.Count;
                var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(id));
                string format = "₹#,##0.00;-₹#,##0.00;₹0";
                ViewBag.Balance = details.balance_amount_to_pay.ToString(format);
            }
            return View();
        }
        public class payment
        {
            public string date;
            public string amount_paid;
        }
    }
}

