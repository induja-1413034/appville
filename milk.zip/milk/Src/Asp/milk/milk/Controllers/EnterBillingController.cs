﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models2;
using Microsoft.AspNetCore.Mvc;
using milk.Models2;

namespace milk.Controllers
{
    public class EnterBillingController : Controller
    {
        private appvilledbContext _context;

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ViewBalance([Required]string phone)           
        {
            try
            {
                if (phone == null)
                {
                    return View("Index");
                }
                else
                {
                    _context = new appvilledbContext();
                    var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(phone));
                    if (details != null)
                    {
                        string format = "₹#,##0.00;-$#,##0.00;Zero";
                        ViewBag.Balance = (details.balance_amount_to_pay).ToString(format);                       
                    }
                    else
                    {
                        ViewBag.Message = "Phone number does not exist";
                    }
                }
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            if (ViewBag.Message != null)
            {
                ModelState.Clear();
            }
            return View("Index");
        }


        [HttpGet]
        public IActionResult ViewBalancejson(string id)
        {
            try
            {
                string Bal = null;
                if (id == null)
                {
                    return Ok("Phone number cannot be null");
                }
                else
                {
                    _context = new appvilledbContext();
                    var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(id));
                    if (details != null)
                    {
                        string format = "₹#,##0.00;-$#,##0.00;Zero";
                        Bal = (details.balance_amount_to_pay).ToString(format);
                    }
                    else
                    {
                        return Ok(new { status=false,
                            Message = "Phone number does not exist" });
                    }
                }
                return Ok(new
                {
                    status = true,
                    Message = Bal
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }                    
        }

        //[ValidateAntiForgeryToken]
        public IActionResult Collection(string phone, [Range(0, double.MaxValue, ErrorMessage = "Please enter valid Number")]double amount_paid)
        {
            try
            {
                if (amount_paid == 0)
                {
                    return View("Index");
                }
                else if (phone == null)
                {
                    return View("Index");                   
                }
                else
                {
                    _context = new appvilledbContext();
                    var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(phone));
                    if (details != null)
                    {
                        MilkAmountPay amountPay = new MilkAmountPay();
                        amountPay.phone = phone;
                        amountPay.date_of_pay = DateTime.Now;
                        amountPay.amount_paid = amount_paid;
                        _context.MilkAmountPay.Add(amountPay);
                        _context.SaveChanges();
                        ViewBag.Message = "Added Successfully";
                    }
                    else
                    {
                        ViewBag.Message = "Phone number does not exist";
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            ModelState.Clear();
            return View("Index");
        }
    }
}