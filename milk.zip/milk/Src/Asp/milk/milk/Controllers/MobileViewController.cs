﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models2;
using Microsoft.AspNetCore.Mvc;
using milk.Models2;

namespace milk.Controllers
{
    public class MobileViewController : Controller
    {
        private appvilledbContext _context;

        public IActionResult Login(string phone)
        {
            _context = new appvilledbContext();
            var details = _context.MilkCustomerDet.Where(x => x.phone == phone).FirstOrDefault();
            if (details != null)
            {
                return Ok("OK");
            }
            else
            {
                return Ok("Error:-Phone number not registered");
            }
        }

        public IActionResult Update_litres(string phone, int consumption)
        {
            try
            {
                _context = new appvilledbContext();
                TimeSpan time = DateTime.Now.TimeOfDay;
                if (phone.Length == 10)
                {
                    var details = _context.MilkCustomerDet.Where(x => x.phone == phone).FirstOrDefault();
                    if (details != null)
                    {
                        if (time.CompareTo(new TimeSpan(05, 00, 00)) == 1 && time.CompareTo(new TimeSpan(17, 00, 00)) == -1)
                        {
                            MilkHistoryLog history = new MilkHistoryLog();
                            history.phone = phone;
                            history.litres = consumption;
                            history.datetime = DateTime.Now;
                            _context.Add(history);
                            _context.SaveChanges();

                            details.litres = consumption;
                            _context.Update(details);
                            _context.SaveChanges();
                            return Ok("Success");
                        }
                        else
                        {
                            return Ok("Error:Cannot Update litres after 5 PM !!!");
                        }
                    }
                    else
                    {
                        return Ok("Error:Phone number not registered");
                    }
                }
                else
                {
                    return Ok("phone number is not 10 digits");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}