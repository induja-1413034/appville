﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models2;
using Microsoft.AspNetCore.Mvc;
using milk.Models2;

namespace milk.Controllers
{
    public class RegistrationController : Controller
    {
        private appvilledbContext _context;

        public IActionResult Registration()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Registration([Bind("Sno,phone,name,address,zone_id,litres,Is_Active,Ref_Sno")] MilkCustomerDet MilkCustomerDet)
        {
            try
            {
                    _context = new appvilledbContext();
                     MilkCustomerDet.contact_no = MilkCustomerDet.phone;
                    _context.Add(MilkCustomerDet);
                    await _context.SaveChangesAsync();
                    MilkHistoryLog history = new MilkHistoryLog();
                    history.sno = MilkCustomerDet.Sno;
                    history.phone = MilkCustomerDet.phone;
                    history.litres = MilkCustomerDet.litres;
                    history.datetime = DateTime.Now;
                    _context.Add(history);
                    await _context.SaveChangesAsync();
                    ViewBag.Message = "Added Successfully";
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            ModelState.Clear();
            return View("Registration");
        }

        public IActionResult DefaultInsert(DateTime date)
        {
            try
            {
                _context = new appvilledbContext();
                if(date==null)
                {
                    date = DateTime.Now;
                }
                List<MilkBill> milk_Bills = new List<MilkBill>();
                var price = _context.MilkPrice.OrderByDescending(x => x.sno).Select(y => y.price).FirstOrDefault();
                var cust_phonelist = _context.MilkCustomerDet.Where(x=>x.Is_Active==true).Select(x => x.phone).ToList();
                foreach (var phne in cust_phonelist)
                {
                    var cust_schedule_details = _context.MilkSchedule.Where(x => x.phone == phne & x.date == date).Select(p => new MilkBill()
                    {
                        phone = p.phone,
                        litres = p.litres,
                        price = price,
                        date = date
                    }).FirstOrDefault();
                    if (cust_schedule_details == null)
                    {
                        var cust_details = _context.MilkCustomerDet.Where(x => x.phone == phne).Select(p => new MilkBill()
                        {
                            phone = p.phone,
                            litres = p.litres,
                            price = price,
                            date = date
                        }).FirstOrDefault();
                        _context.MilkBill.Add(cust_details);
                        _context.SaveChanges();                       
                    }
                    else
                    {
                        _context.MilkBill.Add(cust_schedule_details);
                        _context.SaveChanges();
                    }
                }            
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return Content("Added successfully");
        }
    }
}

    
  
