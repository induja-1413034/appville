﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models2;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using milk.Models2;

namespace template1.Controllers
{
    public class ViewReportController : Controller
    {
        private appvilledbContext _context;

        public IActionResult ViewReport()
        {
            return View();
        }


        public ActionResult Index()
        {
            ModelState.Clear();
            return View("EditReport");
        }

        [HttpPost]
        public ActionResult<MilkSurveyBill> ViewReport(string zone, double balance)
        {
            try
            {
                _context = new appvilledbContext();
                List<MilkSurveyBill> milk = new List<MilkSurveyBill>();
                if (zone == null && balance == 0)
                {
                    milk = _context.MilkSurveyBill.ToList();
                }
                else
                {
                    milk = _context.MilkSurveyBill.Where(x => x.zone.Equals(zone) && x.balance_amount_to_pay > balance).ToList();
                }
                return Ok(milk);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        public async Task<IActionResult> EditReport(string id)
        {
            try
            {
                _context = new appvilledbContext();
                ViewResult viewRes = View(await _context.MilkCustomerDet.ToListAsync());
                if (id.Equals(null))
                {
                    return NotFound();
                }
                var details = _context.MilkCustomerDet.FirstOrDefault(x => x.phone.Equals(id));
                return View(details);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditReport(string id, [Bind("Sno,name,address,phone,litres,zone_id")] MilkCustomerDet MilkCustomerDet)
        {
            _context = new appvilledbContext();
            if (ModelState.IsValid)
            {
                try
                {
                    var details = _context.MilkCustomerDet.FirstOrDefault(x => x.phone.Equals(id));
                    details.litres = MilkCustomerDet.litres;
                    details.name = MilkCustomerDet.name;
                    details.phone = MilkCustomerDet.phone;
                    details.contact_no = MilkCustomerDet.phone;
                    details.address = MilkCustomerDet.address;
                    details.zone_id = MilkCustomerDet.zone_id;
                    _context.Update(details);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            return RedirectToAction("ViewReport");
        }


        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                _context = new appvilledbContext();
                var details = _context.MilkCustomerDet.FirstOrDefault(x => x.contact_no.Equals(id));
                details.Is_deleted = true;
                _context.MilkCustomerDet.Update(details);
                await _context.SaveChangesAsync();
                return RedirectToAction("ViewReport");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public IActionResult Billing(string id)
        {
            return View();
        }

        [HttpPost]
        public IActionResult Billing(string id, [Bind("date,date1")]MilkBill milk)
        {
            try
            {
                List<Bill> Billlist = new List<Bill>();
                _context = new appvilledbContext();
                var billlist1 = _context.MilkBill.Where(x => x.phone == id & x.date >= milk.date & x.date <= milk.date1);
                Billlist = billlist1.Select(x => new Bill { litres = x.litres, price = x.price, date = x.date, Total = x.litres * x.price }).ToList();
                ViewBag.Name = _context.MilkCustomerDet.Where(x => x.phone == id).Select(x => x.name).FirstOrDefault();
                string Totallitres = Billlist.Sum(x => x.litres).ToString();
                ViewBag.Totallitres = string.Format("{0} litres", Totallitres);
                string format = "₹#,##0.00;-$#,##0.00;Zero";
                ViewBag.TotalAmount = Billlist.Sum(x => x.Total).ToString(format);
                //ViewBag.TotalAmount =String.Format(new CultureInfo("en-IN"), "{0:C0}", TotalAmount);
                ViewBag.Bill = Billlist;
                return View();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public class Bill
        {
            public int litres;
            public int price;
            public DateTime date;
            public int Total;
        }

        public IActionResult PaymentHistory(string id)
        {
            _context = new appvilledbContext();
            var billlist1 = _context.MilkCustomerDet.Where(x => x.phone == id).FirstOrDefault();
            if (billlist1 == null)
            {
                ViewBag.Message = "Phone Number does not Exist";
            }
            else
            {
                var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(id));
                ViewBag.Balance = details.balance_amount_to_pay;
            }
            return View();
        }

        [HttpPost]
        public IActionResult PaymentHistory(string id, [Bind("date,date1")]MilkBill milk)
        {
            _context = new appvilledbContext();
            if (id == null)
            {
                ViewBag.Message = "Phone Number Cannot Be null";
            }
            var billlist1 = _context.MilkCustomerDet.Where(x => x.phone == id).FirstOrDefault();
            if (billlist1 == null)
            {
                ViewBag.Message = "Phone Number does not Exist";
            }
            else
            {
                var billlist2 = _context.MilkAmountPay.Where(x => x.phone == id & x.date_of_pay >= milk.date & x.date_of_pay <= milk.date1).ToList();
                if (billlist2.Count == 0)
                {
                    ViewBag.Message = "No Payment done on particular date";
                }
                ViewBag.Payment = billlist2;
                ViewBag.Count = billlist2.Count;
                var details = _context.MilkSurveyBill.FirstOrDefault(x => x.phone.Equals(id));
                string format = "₹#,##0.00;-$#,##0.00;Zero";
                ViewBag.Balance = details.balance_amount_to_pay.ToString(format);
            }
            return View();
        }
        public class payment
        {
            public string date;
            public string amount_paid;
        }
    }
}

