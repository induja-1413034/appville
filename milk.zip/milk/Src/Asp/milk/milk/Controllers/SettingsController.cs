﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MaterialDashboard.Models2;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using milk.Models2;

namespace template1.Controllers
{
    public class SettingsController : Controller
    {
        private appvilledbContext _context;
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Settings()
        {
            try
            {
                _context = new appvilledbContext();
                var vals = _context.MilkPrice.ToList();
                ViewBag.MilkPrice = _context.MilkPrice.ToList();
                var val2 = _context.MilkPrice.OrderByDescending(x => x.date_time).ToList();
                ViewBag.MilkPrice = val2;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Settings([Bind("price")] MilkPrice MilkPrice)
        {
            try
            {
                _context = new appvilledbContext();
                DateTime date = DateTime.Now;
                string dt = date.ToString("yyyy-MM-dd H:mm:ss");
                MilkPrice.date_time = date;
                _context.Add(MilkPrice);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Settings));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
