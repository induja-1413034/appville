﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace milk.Models2
{
    public partial class MilkBill
    {
            public int id { get; set; }
            public string phone { get; set; }
            public int litres { get; set; }        
            public DateTime date { get; set; }
            public int price { get; set; }
            public DateTime date1 { get; set; }
    }
}
