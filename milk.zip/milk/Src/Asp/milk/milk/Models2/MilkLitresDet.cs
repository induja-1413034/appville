﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace milk.Models2
{
    public class MilkLitresDet
    {
        public string phone { get; set; }
        public float litres { get; set; }
    }
}
