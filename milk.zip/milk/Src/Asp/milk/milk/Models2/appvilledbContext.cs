using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using milk.Models2;

namespace MaterialDashboard.Models2
{
    public partial class appvilledbContext : DbContext
    {
        public appvilledbContext()
        {
        }

        public appvilledbContext(DbContextOptions<appvilledbContext> options)
            : base(options)
        {
        }

		public virtual DbSet<MilkSurveyBill> MilkSurveyBill { get; set; }
		public virtual DbSet<MilkPrice> MilkPrice { get; set; }
		public virtual DbSet<MilkCustomerDet> MilkCustomerDet { get; set; }
		public virtual DbSet<MilkHistoryLog> MilkHistoryLog { get; set; }
        public virtual DbSet<MilkLitresDet> MilkLitresDet { get; set; }
        public virtual DbSet<MilkBill> MilkBill { get; set; }
        public virtual DbSet<MilkAmountPay> MilkAmountPay { get; set; }        
        public virtual DbSet<MilkSchedule> MilkSchedule { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("Server=braiding-new.mysql.database.azure.com; Port=3306; Database=milkdb; Uid=braidinguser@braiding-new; Pwd=123Appville!; SslMode=Preferred;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
			modelBuilder.Entity<MilkSurveyBill>(entity =>
			{
				entity.HasKey(e => e.Sno);

				entity.ToTable("milk_survey_bill");

				entity.Property(e => e.Sno).HasColumnName("Sno");

				entity.Property(e => e.phone)
					.HasColumnName("phone")
					.HasColumnType("varchar(20)");

				entity.Property(e => e.name)
					.HasColumnName("name")
					.HasColumnType("varchar(50)");

				entity.Property(e => e.address)
					.HasColumnName("address")
					.HasColumnType("varchar(100)");

				entity.Property(e => e.litres)
					.HasColumnName("litres")
					.HasColumnType("smallint(20)");

				entity.Property(e => e.zone)
					.HasColumnName("zone")
					.HasColumnType("varchar(45)");

                entity.Property(e => e.balance_amount_to_pay)
                    .HasColumnName("balance_amt_to_pay")
                    .HasColumnType("double");

          });

            modelBuilder.Entity<MilkAmountPay>(entity =>
            {
                entity.HasKey(e => e.sno);

                entity.ToTable("milk_amount_pay");

                entity.Property(e => e.sno).HasColumnName("sno");


                entity.Property(e => e.date_of_pay)
                    .HasColumnName("date_of_pay")
                    .HasColumnType("datetime");

                entity.Property(e => e.amount_paid)
                    .HasColumnName("amount_paid")
                    .HasColumnType("double");

                entity.Property(e => e.phone)
                   .HasColumnName("phone")
                   .HasColumnType("varchar(20)");
            });

            modelBuilder.Entity<MilkPrice>(entity =>
			{
				entity.HasKey(e => e.sno);

				entity.ToTable("milk_price");

				entity.Property(e => e.sno).HasColumnName("sno");
				

				entity.Property(e => e.date_time)
					.HasColumnName("date_time")
					.HasColumnType("datetime");
				
				entity.Property(e => e.price)
					.HasColumnName("price")
					.HasColumnType("int(11)");
			});

			modelBuilder.Entity<MilkCustomerDet>(entity =>
			{
				entity.HasKey(e => e.Sno);

				entity.ToTable("milk_customer_det");

				entity.Property(e => e.Sno).HasColumnName("Sno");

				entity.Property(e => e.phone)
					.HasColumnName("phone")
					.HasColumnType("varchar(20)");

				entity.Property(e => e.name)
					.HasColumnName("name")
					.HasColumnType("varchar(50)");

				entity.Property(e => e.address)
					.HasColumnName("address")
					.HasColumnType("varchar(100)");

				entity.Property(e => e.litres)
					.HasColumnName("litres")
					.HasColumnType("smallint(20)");

				entity.Property(e => e.zone_id)
					.HasColumnName("zone_id")
					.HasColumnType("int(11)");

                entity.Property(e => e.Is_Active)
                    .HasColumnName("Is_Active")
                    .HasColumnType("TINYINT(4)");

                entity.Property(e => e.Ref_Sno)
                    .HasColumnName("Ref_Sno")
                    .HasColumnType("int(11)");

                entity.Property(e => e.contact_no)
                    .HasColumnName("contact_no")
                    .HasColumnType("varchar(20)");
            });

			modelBuilder.Entity<MilkHistoryLog>(entity =>
			{
				entity.HasKey(e => e.sno);

				entity.ToTable("milk_history_log");

				entity.Property(e => e.sno).HasColumnName("sno");

				entity.Property(e => e.phone)
					.HasColumnName("phone")
					.HasColumnType("varchar(20)");

				entity.Property(e => e.litres)
					.HasColumnName("litres")
					.HasColumnType("varchar(20)");

				entity.Property(e => e.datetime)
					.HasColumnName("datetime")
					.HasColumnType("datetime");

			});

            modelBuilder.Entity<MilkLitresDet>(entity =>
            {
                entity.HasKey(e => e.phone);

                entity.ToTable("milk_litres_det");

                entity.Property(e => e.phone).HasColumnName("phone");

                entity.Property(e => e.litres)
                    .HasColumnName("litres")
                    .HasColumnType("float");
                
            });


            modelBuilder.Entity<MilkSchedule>(entity =>
            {
                entity.HasKey(e => e._id);

                entity.ToTable("milk_requirement_schedule");

                entity.Property(e => e._id).HasColumnName("_id");

                entity.Property(e => e.date)
                   .HasColumnName("date")
                   .HasColumnType("date");

                entity.Property(e => e.phone)
                   .HasColumnName("phone")
                   .HasColumnType("Varchar(20)");

                entity.Property(e => e.litres)
                    .HasColumnName("litres")
                    .HasColumnType("int(11)");

            });

            modelBuilder.Entity<MilkBill>(entity =>
            {
                entity.HasKey(e => e.id);

                entity.ToTable("milk_bill");

                entity.Property(e => e.id).HasColumnName("id");

                entity.Property(e => e.phone)
                    .HasColumnName("phone")
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.litres)
                    .HasColumnName("litres")
                    .HasColumnType("smallint(20)");

                entity.Property(e => e.date)
                    .HasColumnName("date")
                    .HasColumnType("date");

                entity.Property(e => e.price)
                   .HasColumnName("price")
                   .HasColumnType("smallint(20)");

                entity.Property(e => e.date1)
                    .HasColumnName("date1")
                    .HasColumnType("date");
            });

        }
    }
}
