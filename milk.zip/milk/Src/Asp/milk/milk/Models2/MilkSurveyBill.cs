using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace milk.Models2
{
	public partial class MilkSurveyBill
	{
		public int Sno { get; set; }
		public string phone { get; set; }
		public string name { get; set; }
		public string address { get; set; }
		public int litres { get; set; }
		public string zone { get; set; }
		//public string amount_paid { get; set; }
		//public Nullable<DateTime> date_of_pay { get; set; }
        public int? tot_amount { get; set; }
        public int? tot_ltr { get; set; }
        public double balance_amount_to_pay { get; set; }
    }
}
