﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace milk.Models2
{
    public class MilkSchedule
    {
        public int _id { get; set; }
        public string phone { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}",
               ApplyFormatInEditMode = true)]
        public DateTime date { get; set; }
        public int litres { get; set; }
    }
    public class MilkScheduleDetail
    {
        public List<MilkSchedule> MilkScheduleDetails { get; set; }
    }
}
