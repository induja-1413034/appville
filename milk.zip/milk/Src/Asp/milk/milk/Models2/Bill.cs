﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace milk.Models2
{
    public class Bill
    {
        public int litres;
        public int price;
        [DisplayFormat(DataFormatString = "{yyyy\\/MM\\/dd}",
          ApplyFormatInEditMode = true)]
        public DateTime date;
        public int Total;

        public BillPay billPay { get; set; }

        public class BillPay
        {
            [DisplayFormat(DataFormatString = "{yyyy\\/MM\\/dd}",
              ApplyFormatInEditMode = true)]
            public DateTime date_of_pay;
            public string amount_paid;
        }
    }
    public class BillDetail
    {
        public List<Bill> BillDetails { get; set; }
    }
}
