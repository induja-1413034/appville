using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace milk.Models2
{
	public partial class MilkPrice
	{
		public int sno { get; set; }
		public Nullable<DateTime> date_time { get; set; }
		public int price { get; set; }
	}
}
