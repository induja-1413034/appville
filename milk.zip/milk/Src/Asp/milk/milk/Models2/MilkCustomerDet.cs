using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace milk.Models2
{
	public partial class MilkCustomerDet
	{
		public int Sno { get; set; }
		public string phone { get; set; }
		public string name { get; set; }
		public string address { get; set; }
		public int zone_id { get; set; }
		public int litres { get; set; }
        public bool Is_Active { get; set; }
        public int? Ref_Sno { get; set; }
        public string contact_no { get; set; }
        public bool Is_deleted { get; set; }
    }
}
