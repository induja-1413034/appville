import snap7
import json
import requests
import urllib.parse
import datetime
import time
import paho.mqtt.client as paho
import random
import string


while True:
    try:
        plc = snap7.client.Client()
        plc.connect('192.168.1.10',0,1)
        
        broker="broker.hivemq.com"
        #broker="iot.eclipse.org"
        broker="104.214.79.73"
        def on_message(client, userdata, message):
            time.sleep(1)
            print("received message =",str(message.payload.decode("utf-8")))
        def randomString(stringLength=10):
            """Generate a random string of fixed length """
            letters = string.ascii_lowercase
            return ''.join(random.choice(letters) for i in range(stringLength))
        port=1883
        username="appville"
        password="App123Ville"
        client = paho.Client(randomString())
        #client.on_message=on_message
        client.username_pw_set(username, password)
        client.connect(broker,port) #create client object 
        client.loop_start()
        #client.subscribe("braiding/6080")
        iCount = 0
        while True:
        
            #date_time
            currentDT = datetime.datetime.now()
            currentdt = currentDT.strftime("%Y-%m-%d %H:%M:%S")
        
            #Healthy Time
            healthy_sec = plc.db_read(47,380,2)
            healthy_min = plc.db_read(47,382,2)
            healthy_hour = plc.db_read(47,384,2)
            healthy_sec_val = snap7.util.get_int(healthy_sec,0)
            healthy_min_val = snap7.util.get_int(healthy_min,0)
            healthy_hour_val = snap7.util.get_int(healthy_hour,0)
            healthy_time1 = healthy_hour_val*60+healthy_min_val
            healthy_time2 = round(healthy_time1)
            healthy_time = str(healthy_time2)
        
            #Running Time
            running_sec = plc.db_read(47,386,2)
            running_min = plc.db_read(47,388,2)
            running_hour = plc.db_read(47,390,2)
            running_sec_val = snap7.util.get_int(running_sec,0)
            running_min_val = snap7.util.get_int(running_min,0)
            running_hour_val = snap7.util.get_int(running_hour,0)
            up_time1 = running_hour_val*60+running_min_val
            up_time2 = round(up_time1)
            up_time = str(up_time2)
        
        #Shift Time
            shift_sec = plc.db_read(47,74,2)
            shift_min = plc.db_read(47,76,2)
            shift_hour = plc.db_read(47,78,2)
            shift_sec_val = snap7.util.get_int(shift_sec,0)
            shift_min_val = snap7.util.get_int(shift_min,0)
            shift_hour_val = snap7.util.get_int(shift_hour,0)
            shift_time1 = shift_hour_val*60+shift_min_val
            shift_time2 = round(shift_time1)
            shift_time = str(shift_time2)
        
            #Fault Time
            fault_sec = plc.db_read(47,392,2)
            fault_min = plc.db_read(47,394,2)
            fault_hour = plc.db_read(47,396,2)
            fault_sec_val = snap7.util.get_int(fault_sec,0)
            fault_min_val = snap7.util.get_int(fault_min,0)
            fault_hour_val = snap7.util.get_int(fault_hour,0)
            fault_time1 = fault_hour_val*60+fault_min_val
            fault_time2 = round(fault_time1)
            fault_time = str(fault_time2)
        
            #d1_speed
            Raw_d1_spd = plc.db_read(47,400,4)
            Raw_d1_spd_val= snap7.util.get_real(Raw_d1_spd, 0)
            #print(Raw_d1_spd_val)
        
            #d2_speed
            Raw_d2_spd = plc.db_read(47,404,4)
            Raw_d2_spd_val= snap7.util.get_real(Raw_d2_spd, 0)
            #print(Raw_d1_spd_val)
        
            #cat_speed
            Raw_cat_spd = plc.db_read(47,408,4)
            Raw_cat_spd_val= snap7.util.get_real(Raw_cat_spd, 0)
            #print(Raw_cat_spd_val)
        
            #Carrier_Deck1_rpm
            Deck1_Carrier_rpm = plc.db_read(47,0,4)
            Deck1_Carrier_rpm_val= snap7.util.get_real(Deck1_Carrier_rpm, 0)
            #print(Deck1_Carrier_rpm_val)
        
            #Carrier_Deck2_rpm
            Deck2_Carrier_rpm = plc.db_read(47,8,4)
            Deck2_Carrier_rpm_val= snap7.util.get_real(Deck2_Carrier_rpm, 0)
            #print(Deck2_Carrier_rpm_val)
        
            #Deck1_mot_rpm
            Deck1_mot_rpm = plc.db_read(47,16,4)
            Deck1_mot_rpm_val= snap7.util.get_real(Deck1_mot_rpm, 0)
            #print(Deck1_mot_rpm_val)
        
            #Deck2_mot_rpm
            Deck2_mot_rpm = plc.db_read(47,24,4)
            Deck2_mot_rpm_val= snap7.util.get_real(Deck2_mot_rpm, 0)
            #print(Deck2_mot_rpm_val)
        
            #cat_mot_rpm
            cat_mot_rpm = plc.db_read(47,32,4)
            cat_mot_rpm_val= snap7.util.get_real(cat_mot_rpm, 0)
            #print(cat_mot_rpm_val)
        
            #cat_mpm_avg
            cat_mpm_avg = plc.db_read(47,40,4)
            cat_mpm_avg_val= snap7.util.get_real(cat_mpm_avg, 0)
            #print(cat_mpm_avg_val)
        
            #D1_Current
            D1_Current = plc.db_read(47,48,4)
            D1_Current_val= snap7.util.get_real(D1_Current, 0)
            #print(D1_Current_val)
        
            #D2_Current
            D2_Current = plc.db_read(47,56,4)
            D2_Current_val= snap7.util.get_real(D2_Current, 0)
            #print(D2_Current_val)
        
            #D1_Voltage
            D1_Voltage = plc.db_read(47,52,4)
            D1_Voltage_val= snap7.util.get_real(D1_Voltage, 0)
            #print(D1_Voltage_val)
        
            #D2_Voltage
            D2_Voltage = plc.db_read(47,60,4)
            D2_Voltage_val= snap7.util.get_real(D2_Voltage, 0)
            #print(D2_Voltage_val)
        
            #Cat_Current
            Cat_Current = plc.db_read(47,64,4)
            Cat_Current_val= snap7.util.get_real(Cat_Current, 0)
            #print(Cat_Current_val)
        
            #Cat_Voltage
            Cat_Voltage = plc.db_read(47,68,4)
            Cat_Voltage_val= snap7.util.get_real(Cat_Voltage, 0)
            #print(Cat_Voltage_val)
        
           #Production_Length
            Production_Length = plc.db_read(47,80,4)
            Production_Length_val= snap7.util.get_real(Production_Length, 0)
            #print(Production_Length_val)
        
            #Fault_Bit
            Fault_Bit = plc.db_read(47,72,1)
            Fault_Bit_val = snap7.util.get_bool(Fault_Bit,0,0)
            #print(Fault_Bit_val)
        
            #Deck1_Pitch_PLC
            Deck1_Pitch_PLC = plc.db_read(47,92,4)
            Deck1_Pitch_PLC_val= snap7.util.get_real(Deck1_Pitch_PLC, 0)
            #print(Deck1_Pitch_PLC_val)
        
            #Deck2_Pitch_PLC
            Deck2_Pitch_PLC = plc.db_read(47,96,4)
            Deck2_Pitch_PLC_val= snap7.util.get_real(Deck2_Pitch_PLC, 0)
            #print(Deck2_Pitch_PLC_val)
        
            Error_List = []
            #Bobbin_Empty_Deck_1
            Bobbin_Empty_Deck_1 = plc.db_read(47,378,1)
            Bobbin_Empty_Deck_1_val= snap7.util.get_bool(Bobbin_Empty_Deck_1, 0,4)
            if(Bobbin_Empty_Deck_1_val==True):
                Error_List.append(1)
            #print(Bobbin_Empty_Deck_1_val)
        
            #Bobbin_Empty_Deck_2
            Bobbin_Empty_Deck_2 = plc.db_read(47,378,1)
            Bobbin_Empty_Deck_2_val= snap7.util.get_bool(Bobbin_Empty_Deck_2, 0,5)
            if(Bobbin_Empty_Deck_2_val==True):
                Error_List.append(2)
            #print(Bobbin_Empty_Deck_2_val)
        
            #Check_Flap_Sensor
            Check_Flap_Sensor = plc.db_read(47,378,1)
            Check_Flap_Sensor_val= snap7.util.get_bool(Check_Flap_Sensor, 0,6)
            if(Check_Flap_Sensor_val==True):
                Error_List.append(3)
            #print(Check_Flap_Sensor_val)
        
            #Lubrication_Float_Switch
            Lubrication_Float_Switch = plc.db_read(47,378,1)
            Lubrication_Float_Switch_val= snap7.util.get_bool(Lubrication_Float_Switch, 0,7)
            if(Lubrication_Float_Switch_val==True):
                Error_List.append(4)
            #print(Lubrication_Float_Switch_val)
        
            #Deck_1_Overload_Check_Carrier_and_Shoe
            Deck_1_Overload = plc.db_read(47,379,1)
            Deck_1_Overload_val= snap7.util.get_bool(Deck_1_Overload, 0,0)
            if(Deck_1_Overload_val==True):
                Error_List.append(5);
            #print(Deck_1_Overload_val)
        
            #Deck_2_Overload_Check_Carrier_and_Shoe
            Deck_2_Overload = plc.db_read(47,379,1)
            Deck_2_Overload_val= snap7.util.get_bool(Deck_2_Overload, 0,1)
            if(Deck_2_Overload_val==True):
                Error_List.append(6);
            #print(Deck_2_Overload_val)
        
            #Wire_Cut
            Wire_Cut = plc.db_read(47,378,1)
            Wire_Cut_val = snap7.util.get_bool(Wire_Cut,0,0)
            if(Wire_Cut_val==True):
                Error_List.append(7);
            #print(Wire_Cut_val)
        
            #Cat_drive_fault_or_alarm
            Cat_drive_fault_or_alarm = plc.db_read(47,378,1)
            Cat_drive_fault_or_alarm_val = snap7.util.get_bool(Cat_drive_fault_or_alarm,0,1)
            #print(Cat_drive_fault_or_alarm_val)
            if(Cat_drive_fault_or_alarm_val==True):
                Error_List.append(8);
                #CAT_Fault_CODE
                CAT_Fault_CODE = plc.db_read(47,104,4)
                CAT_Fault_CODE_val = str(snap7.util.get_dword(CAT_Fault_CODE,0))
                #print(CAT_Fault_CODE_val)
                #CAT_Alarm_CODE
                CAT_Alarm_CODE = plc.db_read(47,106,4)
                CAT_Alarm_CODE_val = str(snap7.util.get_dword(CAT_Alarm_CODE,0))
            else:
                CAT_Fault_CODE_val="";
                CAT_Alarm_CODE_val="";
        
            #Deck1_fault_or_alarm
            Deck1_fault_or_alarm = plc.db_read(47,378,1)
            Deck1_fault_or_alarm_val = snap7.util.get_bool(Deck1_fault_or_alarm,0,2)
            #print(Deck1_fault_or_alarm_val)
            if(Deck1_fault_or_alarm_val==True):
                Error_List.append(9)
                #D1_Fault
                D1_Fault = plc.db_read(47,108,4)
                D1_Fault_val = str(snap7.util.get_dword(D1_Fault,0))
                #D1_Alarm
                D1_Alarm = plc.db_read(47,110,4)
                D1_Alarm_val = str(snap7.util.get_dword(D1_Alarm,0))
        
            else:
                D1_Fault_val="";
                D1_Alarm_val="";
        
            #Deck2_fault_or_alarm
            Deck2_fault_or_alarm = plc.db_read(47,378,1)
            Deck2_fault_or_alarm_val = snap7.util.get_bool(Deck2_fault_or_alarm,0,3)
            #print(Deck2_fault_or_alarm_val)
            if(Deck2_fault_or_alarm_val==True):
                Error_List.append(10)
                #D2_Fault
                D2_Fault = plc.db_read(47,112,4)
                D2_Fault_val = str(snap7.util.get_dword(D2_Fault,0))
                #D2_Alarm
                D2_Alarm = plc.db_read(47,114,4)
                D2_Alarm_val = str(snap7.util.get_dword(D2_Alarm,0))
            else:
                D2_Fault_val="";
                D2_Alarm_val="";
        
            #Deck_Selection
            Deck_Selection = plc.db_read(47,372,2)
            Deck_Selection_val = snap7.util.get_int(Deck_Selection,0)
            #print(Deck_Selection_val)
        
            #Deck_Speed_Set
            Deck_Speed_Set = plc.db_read(47,374,4)
            Deck_Speed_Set_val = snap7.util.get_real(Deck_Speed_Set,0)
            #print(Deck_Speed_Set_val)
        
            #Machine_Number
            Machine_Number = plc.db_read(47,116,20)
            Machine_Number_val = snap7.util.get_string(Machine_Number,0,20)
            #print(Machine_Number_val)
        
            #Recipe_Name
            Recipe_Name = plc.db_read(47,412,20)
            Recipe_Name_val = snap7.util.get_string(Recipe_Name,0,20)
            #print(Recipe_Name_val)
            #print(Error_List)
            error_string = str(Error_List).strip('[]')
            #Machine_details1={'date_time':currentdt,'healthy_time':healthy_time,'up_time':up_time,'fault_time':fault_time,'shift_time':shift_time,'d1_speed':Raw_d1_spd_val,'d2_speed':Raw_d2_spd_val,'cat_speed':Raw_cat_spd_val,'Carrier1_rpm':Deck1_Carrier_rpm_val,'Carrier2_rpm':Deck2_Carrier_rpm_val,'cat_mot_rpm':cat_mot_rpm_val,'cat_mpm_avg':cat_mpm_avg_val,'D1_Current':D1_Current_val,'D1_Voltage':D1_Voltage_val,'D2_Current':D2_Current_val,'D2_Voltage':D2_Voltage_val,'Cat_Current':Cat_Current_val,'Cat_Voltage':Cat_Voltage_val,'Production_Length':Production_Length_val,'Fault_bit':Fault_Bit_val,'Deck1_Pitch_PLC':Deck1_Pitch_PLC_val,'Deck2_Pitch_PLC':Deck2_Pitch_PLC_val,'Bobbin_Empty_Deck_1':Bobbin_Empty_Deck_1_val,'Bobbin_Empty_Deck_2':Bobbin_Empty_Deck_1_val,'Check_Flap_Sensor':Check_Flap_Sensor_val,'Lubrication_Float_Switch':Lubrication_Float_Switch_val,'Deck_1_Overload':Deck_1_Overload_val,'Deck_2_Overload':Deck_2_Overload_val,'CAT_Fault_CODE':CAT_Fault_CODE_val,'CAT_Alarm_CODE':CAT_Alarm_CODE_val,'D1_Fault':D1_Fault_val,'D2_Fault':D2_Fault_val,'D1_Alarm':D1_Alarm_val,'D2_Alarm':D2_Alarm_val,'Deck_Selection':Deck_Selection_val,'Deck_Speed_Set':Deck_Speed_Set_val,'Wire_Cut':Wire_Cut_val,'Cat_drive_fault_or_alarm':Cat_drive_fault_or_alarm_val,'Deck1_fault_or_alarm':Deck1_fault_or_alarm_val,'Deck2_fault_or_alarm':Deck2_fault_or_alarm_val,'Machine_Number':Machine_Number_val,'Recipe_Name':Recipe_Name_val}
        
            Machine_details={'date_time':currentdt,'healthy_time':healthy_time,'up_time':up_time,'fault_time':fault_time,'shift_time':shift_time,'d1_speed':Raw_d1_spd_val,'d2_speed':Raw_d2_spd_val,'cat_speed':Raw_cat_spd_val,'Carrier1_rpm':Deck1_Carrier_rpm_val,'Carrier2_rpm':Deck2_Carrier_rpm_val,'cat_mot_rpm':cat_mot_rpm_val,'cat_mpm_avg':cat_mpm_avg_val,'D1_Current':D1_Current_val,'D1_Voltage':D1_Voltage_val,'D2_Current':D2_Current_val,'D2_Voltage':D2_Voltage_val,'Cat_Current':Cat_Current_val,'Cat_Voltage':Cat_Voltage_val,'Production_Length':Production_Length_val,'Fault_bit':Fault_Bit_val,'Deck1_Pitch_PLC':Deck1_Pitch_PLC_val,'Deck2_Pitch_PLC':Deck2_Pitch_PLC_val,'Machine_Number':Machine_Number_val,'Recipe_Name':Recipe_Name_val,"Error":error_string,'CAT_Fault_CODE':CAT_Fault_CODE_val,'CAT_Alarm_CODE':CAT_Alarm_CODE_val,'D1_Fault':D1_Fault_val,'D2_Fault':D2_Fault_val,'D1_Alarm':D1_Alarm_val,'D2_Alarm':D2_Alarm_val}
            Machine_details = json.dumps(Machine_details)
            #print(Machine_details)
            #print("json")
            time.sleep(1)
            iCount += 1
            temp = "braiding/"
            topic="6080"
            combine=temp+topic
            #print(combine)
            
            #client.subscribe(combine)
            client.publish(combine,Machine_details)
            if (iCount >15):
                iCount = 0
                try:
                    post_req = Machine_details
                    braiding_url = "http://104.214.79.73/Braiding1/Create?Machine_details="+ urllib.parse.quote(Machine_details)
                    #print(utility_url)
                    braiding_req = requests.post(url=braiding_url)
                    print(braiding_req.text)
                except Exception as ex:
                    print('error:-', ex)
    except Exception as exep:
       print("outer error:-", exep)
        