﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace braidingmachine.Models
{
    public class ShiftTable
    {
        public int _id;
        public string ShiftName;
        public TimeSpan In_time;
        public TimeSpan Out_time;
        public int days;
    }
}
