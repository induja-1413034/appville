using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using braidingmachine.Models;

namespace braidingmachine.Models
{
    public partial class appvilledbContext : DbContext
    {
        public appvilledbContext()
        {
        }

        public appvilledbContext(DbContextOptions<appvilledbContext> options)
            : base(options)
        {
        }

		public virtual DbSet<Shifttime> Shifttime { get; set; }
        public virtual DbSet<Login_Table> Login_Table { get; set; }
        public virtual DbSet<ShiftTable> ShiftTable { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("Server=braiding-new.mysql.database.azure.com; Port=3306; Database=braiding; Uid=braidinguser@braiding-new; Pwd=123Appville!; SslMode=Preferred;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Login_Table>(entity =>
            {
                entity.HasKey(e => e.Username);

                entity.ToTable("login_table");

                entity.Property(e => e.Username).HasColumnName("Username");

                entity.Property(e => e.Password)
                    .HasColumnName("Password")
                    .HasColumnType("varchar(45)");                

            });
            modelBuilder.Entity<ShiftTable>(entity =>
            {
                //entity.HasKey(e => e._id);

                entity.ToTable("shift_table1");

                entity.Property(e => e._id)
                    .HasColumnName("_id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.In_time)
                    .HasColumnName("In_time")
                    .HasColumnType("time");

                entity.Property(e => e.Out_time)
                    .HasColumnName("Out_time")
                    .HasColumnType("time");

                entity.Property(e => e.ShiftName)
                    .HasColumnName("ShiftName")
                    .HasColumnType("time");

                entity.Property(e => e.days)
                    .HasColumnName("days")
                    .HasColumnType("int(11)");

            });
          /*  modelBuilder.Entity<Shifttime>(entity =>
			{
				entity.HasKey(e => e._id);

				entity.ToTable("shift_table1");

                entity.Property(e => e._id)
                    .HasColumnName("_id");                    

                entity.Property(e => e.In_time)
					.HasColumnName("In_time")
					.HasColumnType("time");

				entity.Property(e => e.Out_time)
					.HasColumnName("Out_time")
					.HasColumnType("time");

                entity.Property(e => e.ShiftName)
                    .HasColumnName("ShiftName")
                    .HasColumnType("time");

                entity.Property(e => e.days)
                    .HasColumnName("days")
                    .HasColumnType("int(11)");

            });*/
        }
    }
}
