﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace braidingmachine.Models
{
    public class MachineData
    {
        public DateTime date_time;
        public bool machine_status;
        public double Production_Length;
        public double Deck1_Pitch_PLC;
        public double Deck2_Pitch_PLC;
        public double hose_diameter;
        public int healthy_time;
        public int up_time;
        public int fault_time;
        public double Carrier1_rpm;
        public double Carrier2_rpm;
        public double Deck1_mot_rpm;
        public double Deck2_mot_rpm;
        public double cat_mpm_avg;
        public double cat_mot_rpm;
        public double d1_speed;
        public double d2_speed;
        public double cat_speed;
        public double D1_Current;
        public double D2_Current;
        public double D1_Voltage;
        public double D2_Voltage;
        public double Cat_Current;
        public double Cat_Voltage;
        public bool Fault_Bit;
        public int pitchgrouping1;
        public int pitchgrouping2;
        public double Timedifference;
        public double currentlength;
        public string Recipe_Name;
        public string Machine_Number;
        public string Error;
        public string CAT_Fault_CODE;
        public string CAT_Alarm_CODE;
        public string D2_Alarm;
        public string D2_Fault;
        public string D1_Alarm;
        public string D1_Fault;
    }
    public class Mac_details
    {
        public string Machine_details;
    }
}
