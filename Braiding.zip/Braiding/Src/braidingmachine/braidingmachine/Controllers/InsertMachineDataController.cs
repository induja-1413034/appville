﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using braidingmachine.Controllers;
using braidingmachine.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace InsertMachineData.Controllers
{
    public class InsertMachineDataController : Controller
    {
        public IConfiguration Configuration { get; }
        public InsertMachineDataController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Create(string Machine_details)
        {
            try
            {
                MachineData machine = new MachineData();
                machine = JsonConvert.DeserializeObject<MachineData>(Machine_details);
                List<string> errorcodes_new = new List<string>();
                List<Braiding1Controller.Errorwithgrouping> errorcodes_old = new List<Braiding1Controller.Errorwithgrouping>();
                Braiding1Controller.Errorwithgrouping errorwithgrouping = null;
                List<Error> errorInsertlist = new List<Error>();
                Error errorInsert = null;
                int machinedata_id = 0;
                DateTime PreviousDatetime = new DateTime(1000, 10, 1);
                double Previouspitch1 = 0;
                double Previouspitch2 = 0;
                int Previouspitchgrouping1 = 0;
                int Previouspitchgrouping2 = 0;
                double Previouscumulativelength = 0;
                TimeSpan time = new TimeSpan();

                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    MySqlTransaction transaction;
                    transaction = conn.BeginTransaction();
                    try
                    {
                        StringBuilder sb = new StringBuilder();
                        string sql = "";
                        if (machine.Deck1_Pitch_PLC == 0 & machine.Deck2_Pitch_PLC == 0 & machine.fault_time == 0 &
                            machine.healthy_time == 0 & machine.up_time == 0 & machine.currentlength == 0)
                        {
                            return Ok(new
                            {
                                message = "Skipped because of 0 values"
                            });
                        }
                        else
                        {
                            if (machine.Error != null)
                            {
                                errorcodes_new = machine.Error.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.Trim()).ToList();
                                int Previousmachinedata_id = 0;
                                bool isFoundnull = false;
                                sb.Clear();
                                sb.Append("SELECT _id, errorcode, codegrouping, alarm_code, fault_code FROM machine_data_error_view");
                                sb.Append(string.Format(" where _id=(select max(_id) from braiding.machine_data_error_view)"));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    using (MySqlDataReader reader = command.ExecuteReader())
                                    {
                                        while (reader.Read())
                                        {
                                            errorInsert = new Error();
                                            Previousmachinedata_id = reader.GetInt32(0);
                                            if (reader["errorcode"] != DBNull.Value)
                                            {
                                                errorwithgrouping = new Braiding1Controller.Errorwithgrouping();
                                                errorwithgrouping.Prev_errorcode = reader.GetString(1);
                                                errorwithgrouping.Prev_codegrouping = reader.GetDouble(2);                                              
                                                errorcodes_old.Add(errorwithgrouping);
                                            }
                                            else
                                            {
                                                isFoundnull = true;
                                                break;
                                            }
                                        }
                                        if (isFoundnull == true)
                                        {
                                            foreach (var err in errorcodes_new)
                                            {
                                                errorInsert = new Error();
                                                errorInsert.machinedata_id = machinedata_id;
                                                errorInsert.errorcode = err;
                                                errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                                errorInsertlist.Add(errorInsert);
                                            }
                                        }
                                    }
                                }
                                sb.Clear();
                                sb.Append("SELECT Date,pitch1,pitch2,pitchgrouping1,pitchgrouping2,cumulativelength FROM machinedata");
                                sb.Append(string.Format(" ORDER BY _id DESC LIMIT 1"));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    using (MySqlDataReader reader = command.ExecuteReader())
                                    {
                                        while (reader.Read())
                                        {
                                            PreviousDatetime = reader.GetDateTime(0);
                                            Previouspitch1 = reader.GetDouble(1);
                                            Previouspitch2 = reader.GetDouble(2);
                                            Previouspitchgrouping1 = reader.GetInt32(3);
                                            Previouspitchgrouping2 = reader.GetInt32(4);
                                            Previouscumulativelength = reader.GetInt32(5);
                                        }
                                    }
                                }
                                sb.Clear();
                                sb.Append("INSERT INTO machinedata(Date, cumulativelength, pitch1,pitch2, healthytime, runningtime, faulttime, pitchgrouping1, pitchgrouping2, Timedifference,currentlength,Recipe_Name,Machine_Number,Carrier1_rpm,Carrier2_rpm,d1_speed,d2_speed,D1_Current,D2_Current,Cat_Current)");
                                sb.Append(" VALUES(@Date,@cumulativelength,@pitch1,@pitch2, @healthytime, @runningtime, @faulttime, @pitchgrouping1,@pitchgrouping2, @Timedifference,@currentlength,@Recipe_Name,@Machine_Number,@Carrier1_rpm,@Carrier2_rpm,@d1_speed,@d2_speed,@D1_Current,@D2_Current,@Cat_Current);");
                                sb.Append(" select last_insert_id() as _id");
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    command.Parameters.AddWithValue("@Date", machine.date_time);
                                    command.Parameters.AddWithValue("@cumulativelength", machine.Production_Length);
                                    command.Parameters.AddWithValue("@pitch1", machine.Deck1_Pitch_PLC);
                                    command.Parameters.AddWithValue("@pitch2", machine.Deck2_Pitch_PLC);
                                    command.Parameters.AddWithValue("@healthytime", machine.healthy_time);
                                    command.Parameters.AddWithValue("@faulttime", machine.fault_time);
                                    command.Parameters.AddWithValue("@runningtime", machine.up_time);
                                    if (Previouspitch1 == machine.Deck1_Pitch_PLC)
                                    {
                                        machine.pitchgrouping1 = Previouspitchgrouping1;
                                    }
                                    else
                                    {
                                        machine.pitchgrouping1 = Previouspitchgrouping1 + 1;
                                    }
                                    command.Parameters.AddWithValue("@pitchgrouping1", machine.pitchgrouping1);
                                    if (Previouspitch2 == machine.Deck2_Pitch_PLC)
                                    {
                                        machine.pitchgrouping2 = Previouspitchgrouping2;
                                    }
                                    else
                                    {
                                        machine.pitchgrouping2 = Previouspitchgrouping2 + 1;
                                    }
                                    command.Parameters.AddWithValue("@pitchgrouping2", machine.pitchgrouping2);
                                    if (PreviousDatetime == DateTime.MinValue)
                                    {
                                        time = new TimeSpan(0, 0, 0, 0, 0);
                                    }
                                    else
                                    {
                                        time = machine.date_time - PreviousDatetime;
                                    }
                                    machine.Timedifference = time.TotalSeconds;
                                    command.Parameters.AddWithValue("@Timedifference", machine.Timedifference);
                                    if (machine.Production_Length > Previouscumulativelength)
                                    {
                                        machine.currentlength = machine.Production_Length - Previouscumulativelength;
                                    }
                                    else
                                    {
                                        machine.currentlength = Previouscumulativelength - machine.Production_Length;
                                    }
                                    command.Parameters.AddWithValue("@currentlength", machine.currentlength);
                                    command.Parameters.AddWithValue("@Recipe_Name", machine.Recipe_Name);
                                    command.Parameters.AddWithValue("@Machine_Number", machine.Machine_Number);
                                    command.Parameters.AddWithValue("@Carrier1_rpm", machine.Carrier1_rpm);
                                    command.Parameters.AddWithValue("@Carrier2_rpm", machine.Carrier2_rpm);
                                    command.Parameters.AddWithValue("@d1_speed", machine.d1_speed);
                                    command.Parameters.AddWithValue("@d2_speed", machine.d2_speed);
                                    command.Parameters.AddWithValue("@D1_Current", machine.D1_Current);
                                    command.Parameters.AddWithValue("@D2_Current", machine.D2_Current);
                                    command.Parameters.AddWithValue("@Cat_Current", machine.Cat_Current);
                                    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                                }
                                if (isFoundnull == false)
                                {
                                    List<ErrorComparator.Error_Results> list_Err_With_Status = new List<ErrorComparator.Error_Results>();
                                    list_Err_With_Status = (new ErrorComparator()).PerformComparison(errorcodes_old, errorcodes_new);
                                    foreach (var err in list_Err_With_Status)
                                    {
                                        if (err.status == "SameErrorgrouping")
                                        {
                                            errorInsert = new Error();
                                            errorInsert.machinedata_id = machinedata_id;
                                            errorInsert.errorcode = err.error;
                                            errorInsert.codegrouping = errorcodes_old.Where(y => y.Prev_errorcode == err.error).Select(x => x.Prev_codegrouping).First();
                                            errorInsertlist.Add(errorInsert);
                                        }
                                        else if (err.status == "NewErrorgrouping")
                                        {
                                            errorInsert = new Error();
                                            errorInsert.machinedata_id = machinedata_id;
                                            errorInsert.errorcode = err.error;
                                            errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                            errorInsertlist.Add(errorInsert);
                                        }
                                    }
                                }
                                foreach (var errinsert in errorInsertlist)
                                {
                                    sb.Clear();
                                    sb.Append("INSERT INTO error(machinedata_id, errorcode, alarm_code, fault_code, codegrouping)");
                                    sb.Append(" VALUES(@machinedata_id, @errorcode, @alarm_code, @fault_code, @codegrouping)");
                                    sql = sb.ToString();
                                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                                    {
                                        command.Connection = conn;
                                        command.Transaction = transaction;
                                        command.Parameters.Clear();
                                        command.Parameters.AddWithValue("@machinedata_id", machinedata_id);
                                        if (errinsert.errorcode == "8")
                                        {
                                            command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                            command.Parameters.AddWithValue("@alarm_code", machine.CAT_Alarm_CODE);
                                            command.Parameters.AddWithValue("@fault_code", machine.CAT_Fault_CODE);
                                        }
                                        else if (errinsert.errorcode == "9")
                                        {
                                            command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                            command.Parameters.AddWithValue("@alarm_code", machine.D1_Alarm);
                                            command.Parameters.AddWithValue("@fault_code", machine.D1_Fault);
                                        }
                                        else if (errinsert.errorcode == "10")
                                        {
                                            command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                            command.Parameters.AddWithValue("@alarm_code", machine.D2_Alarm);
                                            command.Parameters.AddWithValue("@fault_code", machine.D2_Fault);
                                        }
                                        else
                                        {
                                            command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                            command.Parameters.AddWithValue("@alarm_code", DBNull.Value);
                                            command.Parameters.AddWithValue("@fault_code", DBNull.Value);
                                        }
                                        command.Parameters.AddWithValue("@codegrouping", errinsert.codegrouping);
                                        int iVal = command.ExecuteNonQuery();
                                    }
                                }
                            }
                            else
                            {
                                sb.Clear();
                                sb.Append("SELECT Date,pitch1,pitch2,pitchgrouping1,pitchgrouping2,cumulativelength FROM machinedata");
                                sb.Append(string.Format(" ORDER BY _id DESC LIMIT 1"));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    using (MySqlDataReader reader = command.ExecuteReader())
                                    {
                                        while (reader.Read())
                                        {
                                            PreviousDatetime = reader.GetDateTime(0);
                                            Previouspitch1 = reader.GetDouble(1);
                                            Previouspitch2 = reader.GetDouble(2);
                                            Previouspitchgrouping1 = reader.GetInt32(3);
                                            Previouspitchgrouping2 = reader.GetInt32(4);
                                            Previouscumulativelength = reader.GetInt32(5);
                                        }
                                    }
                                }
                                sb.Clear();
                                sb.Append("INSERT INTO machinedata(Date, cumulativelength, pitch1,pitch2, healthytime, runningtime, faulttime, pitchgrouping1, pitchgrouping2, Timedifference,currentlength,Recipe_Name,Machine_Number,Carrier1_rpm,Carrier2_rpm,d1_speed,d2_speed,D1_Current,D2_Current,Cat_Current)");
                                sb.Append(" VALUES(@Date,@cumulativelength,@pitch1,@pitch2, @healthytime, @runningtime, @faulttime, @pitchgrouping1,@pitchgrouping2, @Timedifference,@currentlength,@Recipe_Name,@Machine_Number,@Carrier1_rpm,@Carrier2_rpm,@d1_speed,@d2_speed,@D1_Current,@D2_Current,@Cat_Current);");
                                sb.Append(" select last_insert_id() as _id");
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    command.Parameters.AddWithValue("@Date", machine.date_time);
                                    command.Parameters.AddWithValue("@cumulativelength", machine.Production_Length);
                                    command.Parameters.AddWithValue("@pitch1", machine.Deck1_Pitch_PLC);
                                    command.Parameters.AddWithValue("@pitch2", machine.Deck2_Pitch_PLC);
                                    command.Parameters.AddWithValue("@healthytime", machine.healthy_time);
                                    command.Parameters.AddWithValue("@faulttime", machine.fault_time);
                                    command.Parameters.AddWithValue("@runningtime", machine.up_time);
                                    if (Previouspitch1 == machine.Deck1_Pitch_PLC)
                                    {
                                        machine.pitchgrouping1 = Previouspitchgrouping1;
                                    }
                                    else
                                    {
                                        machine.pitchgrouping1 = Previouspitchgrouping1 + 1;
                                    }
                                    command.Parameters.AddWithValue("@pitchgrouping1", machine.pitchgrouping1);
                                    if (Previouspitch2 == machine.Deck2_Pitch_PLC)
                                    {
                                        machine.pitchgrouping2 = Previouspitchgrouping2;
                                    }
                                    else
                                    {
                                        machine.pitchgrouping2 = Previouspitchgrouping2 + 1;
                                    }
                                    command.Parameters.AddWithValue("@pitchgrouping2", machine.pitchgrouping2);
                                    if (PreviousDatetime == DateTime.MinValue)
                                    {
                                        time = new TimeSpan(0, 0, 0, 0, 0);
                                    }
                                    else
                                    {
                                        time = machine.date_time - PreviousDatetime;
                                    }
                                    machine.Timedifference = time.TotalSeconds;
                                    command.Parameters.AddWithValue("@Timedifference", machine.Timedifference);
                                    if (machine.Production_Length > Previouscumulativelength)
                                    {
                                        machine.currentlength = machine.Production_Length - Previouscumulativelength;
                                    }
                                    else
                                    {
                                        machine.currentlength = Previouscumulativelength - machine.Production_Length;
                                    }
                                    command.Parameters.AddWithValue("@currentlength", machine.currentlength);
                                    command.Parameters.AddWithValue("@Recipe_Name", machine.Recipe_Name);
                                    command.Parameters.AddWithValue("@Machine_Number", machine.Machine_Number);
                                    command.Parameters.AddWithValue("@Carrier1_rpm", machine.Carrier1_rpm);
                                    command.Parameters.AddWithValue("@Carrier2_rpm", machine.Carrier2_rpm);
                                    command.Parameters.AddWithValue("@d1_speed", machine.d1_speed);
                                    command.Parameters.AddWithValue("@d2_speed", machine.d2_speed);
                                    command.Parameters.AddWithValue("@D1_Current", machine.D1_Current);
                                    command.Parameters.AddWithValue("@D2_Current", machine.D2_Current);
                                    command.Parameters.AddWithValue("@Cat_Current", machine.Cat_Current);
                                    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                                }
                            }
                            transaction.Commit();
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        return BadRequest(ex.Message);
                    }
                }
                return Ok(new
                {
                    message = "Added Successfully"
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public class Errorwithgrouping
        //{
        //    public string Prev_errorcode { get; internal set; }
        //    public double Prev_codegrouping { get; internal set; }
        //    public string alarm_code { get; set; }
        //    public string fault_code { get; set; }
        //}
    }
}