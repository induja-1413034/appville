﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace braidingmachine.Controllers
{
    
    public class PitchReport1Controller : Controller
    {
        
        public IActionResult PitchReport1(string load_model_data)
        {
            var str = HttpContext.Session.GetString("list");
            var obj = JsonConvert.DeserializeObject<DbType>(str);            
            return Ok(obj);
        }
    }
}