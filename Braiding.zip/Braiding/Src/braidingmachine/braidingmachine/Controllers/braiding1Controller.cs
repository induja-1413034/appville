﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;

namespace braidingmachine.Controllers
{
    public class Braiding1Controller : Controller
    {
        public IConfiguration Configuration { get; }
        public Braiding1Controller(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IActionResult Braiding1()
        {
            Nullable<int> login_session = HttpContext.Session.GetInt32("login");
            if (login_session == 123)
                return View();
            else
                return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public ActionResult<TimingData> TimeData(DateTime From, DateTime To)
        {
            List<TimingData> timingDataslist = new List<TimingData>();
            TimingData timingData = new TimingData();
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
                    string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date>='{0}' and Date between '{0}' and '{1}' order by Date limit 1", FromDate, ToDate));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0);
                                timingData.idle_time = reader.GetInt32(1);
                                timingData.error_time = reader.GetInt32(2);
                            }
                        }
                    }
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date<='{1}' and Date between '{0}' and '{1}' ORDER BY Date DESC LIMIT 1", From.ToString("yyyy-MM-dd HH-mm-s"), To.ToString("yyyy-MM-dd HH-mm-s")));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0) - timingData.up_time;
                                timingData.idle_time = reader.GetInt32(1) - timingData.idle_time;
                                timingData.error_time = reader.GetInt32(2) - timingData.error_time;
                                timingDataslist.Add(timingData);
                            }
                        }
                    }
                    return Ok(timingDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class TimingData
        {
            public int idle_time;
            public int error_time;
            public int up_time;
        }

        private List<tot_length_by_date> length_by_date(string From, string To)
        {
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                List<tot_length_by_date> list_of_tot_length = new List<tot_length_by_date>();
                tot_length_by_date length_by_date_wise = null;
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("SELECT Date,max(cumulativelength)-min(cumulativelength) as length FROM machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}'", From, To));
                    sb.Append("group by cast(Date as date) order by Date");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                length_by_date_wise = new tot_length_by_date();
                                length_by_date_wise.Date = reader.GetDateTime(0).ToString("yyyy-MM-dd");
                                length_by_date_wise.length = reader.GetInt32(1);
                                list_of_tot_length.Add(length_by_date_wise);
                            }
                        }
                    }
                }
                return list_of_tot_length;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public IActionResult Deck1_Report(DateTime From, DateTime To)
        {
            List<tot_length_by_pitch> pitch_length_list = new List<tot_length_by_pitch>();
            tot_length_by_pitch pitchwise_length = null;
            List<Deck_json> Deck1_json = new List<Deck_json>();            
            List<tot_length_by_date> list_of_dates_by_tot_len = new List<tot_length_by_date>();
            string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
            string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    list_of_dates_by_tot_len = length_by_date(FromDate, ToDate);
                    foreach (var list in list_of_dates_by_tot_len)
                    {
                        sb.Clear();
                        sb.Append("SELECT pitch1,max(cumulativelength)-min(cumulativelength) as length FROM machinedata");
                        sb.Append(string.Format(" where cast(Date as date)='{0}' and cumulativelength>1 and pitch1>1", list.Date));
                        sb.Append(" group by pitch1 order by Date");
                        sql = sb.ToString();
                        pitchwise_length = new tot_length_by_pitch();
                        pitchwise_length.Date = list.Date;
                        pitchwise_length.length = list.length;
                        using (MySqlCommand command = new MySqlCommand(sql, conn))
                        {
                            using (MySqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    tot_length_by_pitch.date_pitch obj2 = new tot_length_by_pitch.date_pitch();
                                    double temp = reader.GetDouble(0);
                                    obj2.pitch = temp;
                                    obj2.length = reader.GetInt32(1);
                                    pitchwise_length.datepitches.Add(obj2);
                                }
                            }
                        }
                        pitch_length_list.Add(pitchwise_length);
                    }
                    foreach (var list in pitch_length_list)
                    {
                        Deck_json pitchDatatime1 = new Deck_json();
                        pitchDatatime1.Date_time = list.Date;
                        pitchDatatime1.length = list.length;
                        foreach (var list1 in list.datepitches)
                        {
                            Deck_json.Date_array obj1 = new Deck_json.Date_array();
                            obj1.pitch = list1.pitch;
                            obj1.length = list1.length;
                            sb.Clear();
                            sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), max(cumulativelength)-min(cumulativelength) as length from machinedata");
                            sb.Append(string.Format(" where cast(Date as date)='{0}' and pitch1={1} and cumulativelength>1", list.Date, list1.pitch));
                            sb.Append(" group by pitchgrouping1");                            
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                using (MySqlDataReader reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        Deck_json.Date_array.time_array obj2 = new Deck_json.Date_array.time_array();
                                        obj2.Starttime = reader.GetTimeSpan(0);
                                        obj2.Endtime = reader.GetTimeSpan(1);
                                        obj2.length = reader.GetInt32(2);
                                        obj1.timearray.Add(obj2);
                                    }
                                }
                            }
                            pitchDatatime1.datepitches.Add(obj1);
                        }
                        Deck1_json.Add(pitchDatatime1);
                    }
                    return Ok(new { Deck1_json });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class tot_length_by_pitch
        {
            public string Date;
            public int length;
            public List<date_pitch> datepitches = new List<date_pitch>();
            public date_pitch date_ { get; set; }
            public class date_pitch
            {
                public double pitch { get; set; }
                public int length { get; set; }
            }
        }
        public class Deck_json
        {
            public string Date_time;
            public int length;
            public List<Date_array> datepitches = new List<Date_array>();
            public class Date_array
            {
                public double pitch { get; set; }
                public int length { get; set; }
                public List<time_array> timearray = new List<time_array>();
                public class time_array
                {
                    public TimeSpan Starttime { get; set; }
                    public TimeSpan Endtime { get; set; }
                    public int length { get; set; }
                }
            }
        }
        public class tot_length_by_date
        {
            public string Date;
            public int length;
        }
        public class PitchData
        {
            public string Date;
            public double pitch;
            public int length;
        }
    
       [HttpGet]
        public IActionResult Deck2_Report(DateTime From, DateTime To)
        {
            List<tot_length_by_pitch> pitch_length_list = new List<tot_length_by_pitch>();
            List<Deck_json> Deck2_json = new List<Deck_json>();
            tot_length_by_pitch pitchwise_length = null;
            List<tot_length_by_date> list_of_dates_by_tot_len = new List<tot_length_by_date>();
            string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
            string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    list_of_dates_by_tot_len = length_by_date(FromDate, ToDate);                    
                    foreach (var list in list_of_dates_by_tot_len)
                    {
                        sb.Clear();
                        sb.Append("SELECT pitch2,max(cumulativelength)-min(cumulativelength) as length FROM machinedata");
                        sb.Append(string.Format(" where cast(Date as date)='{0}' and cumulativelength>1 and pitch2>1", list.Date));
                        sb.Append(" group by pitch2 order by Date");
                        sql = sb.ToString();
                        pitchwise_length = new tot_length_by_pitch();
                        pitchwise_length.Date = list.Date;
                        pitchwise_length.length = list.length;
                        using (MySqlCommand command = new MySqlCommand(sql, conn))
                        {
                            using (MySqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    tot_length_by_pitch.date_pitch obj1 = new tot_length_by_pitch.date_pitch();
                                    obj1.pitch = reader.GetDouble(0);
                                    obj1.length = reader.GetInt32(1);
                                    pitchwise_length.datepitches.Add(obj1);
                                }
                            }
                        }
                        pitch_length_list.Add(pitchwise_length);
                    }
                    foreach (var list in pitch_length_list)
                    {
                        Deck_json pitchDatatime = new Deck_json();
                        pitchDatatime.Date_time = list.Date;
                        pitchDatatime.length = list.length;                        
                        foreach (var list1 in list.datepitches)
                        {
                            Deck_json.Date_array obj = new Deck_json.Date_array();
                            obj.pitch = list1.pitch;
                            obj.length = list1.length;
                            sb.Clear();
                            sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), max(cumulativelength)-min(cumulativelength) as length from machinedata");
                            sb.Append(string.Format(" where cast(Date as date)='{0}' and pitch2={1} and cumulativelength>1", list.Date, list1.pitch));
                            sb.Append(" group by pitchgrouping2");
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                using (MySqlDataReader reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        Deck_json.Date_array.time_array obj1 = new Deck_json.Date_array.time_array();
                                        obj1.Starttime = reader.GetTimeSpan(0);
                                        obj1.Endtime = reader.GetTimeSpan(1);
                                        obj1.length = reader.GetInt32(2);
                                        obj.timearray.Add(obj1);
                                    }                                   
                                }
                            }
                            pitchDatatime.datepitches.Add(obj);
                        }
                        Deck2_json.Add(pitchDatatime);
                    }
                    return Ok(new { Deck2_json });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }

        [HttpGet]
        public IActionResult ErrorDetails(DateTime From, DateTime To)
        {
            List<ErrorlistDateWise> errorDataslist = new List<ErrorlistDateWise>();
            List<DateWiseTotalErrorTime> errorDatalist1 = new List<DateWiseTotalErrorTime>();
            List<Error_Report_json> Error_json = new List<Error_Report_json>();
            ErrorlistDateWise errorData = null;
            DateWiseTotalErrorTime datewise_errortime = null;
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
                    string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
                    sb.Clear();
                    sb.Append("SELECT cast(md.Date as date) as Date, err.errorcode, err_des.error_description,sum(md.Timedifference) FROM machinedata md");
                    sb.Append(string.Format(" inner join error err on md._id = err.machinedata_id"));
                    sb.Append(string.Format(" inner join error_description  err_des on err_des.errorcode = err.errorcode where md.Date between '{0}' and '{1}'", FromDate, ToDate));
                    sb.Append("group by cast(Date " +
                        "as date)");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                datewise_errortime = new DateWiseTotalErrorTime();
                                datewise_errortime.Date = reader.GetDateTime(0).Date.ToString("yyyy-MM-dd");
                                datewise_errortime.Time = TimeSpan.FromSeconds(reader.GetDouble(3));
                                errorDatalist1.Add(datewise_errortime);
                            }
                        }
                    }
                    foreach (var list in errorDatalist1)
                    {                                               
                        sb.Clear();
                        string todate = list.Date + " 23:59:59";
                        sb.Append("SELECT err.errorcode, err_des.error_description,sum(md.Timedifference) FROM machinedata md");
                        sb.Append(string.Format(" inner join error err on md._id = err.machinedata_id"));
                        sb.Append(string.Format(" inner join error_description  err_des on err_des.errorcode = err.errorcode where md.Date between '{0}' and '{1}'",list.Date, todate));
                        sb.Append("group by err.errorcode,cast(Date " +
                            "as date)  order by Date");          
                        sql = sb.ToString();
                        errorData = new ErrorlistDateWise();
                        errorData.Date = list.Date;
                        errorData.Time = list.Time;
                        using (MySqlCommand command = new MySqlCommand(sql, conn))
                        {
                            using (MySqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    ErrorlistDateWise.err_list obj = new ErrorlistDateWise.err_list();
                                    obj.errorcode = reader.GetInt32(0);
                                    obj.error_description = reader.GetString(1);
                                    obj.Time = TimeSpan.FromSeconds(reader.GetDouble(2));
                                    errorData.error_list.Add(obj);
                                }
                            }
                        }
                        errorDataslist.Add(errorData);
                    }
                    foreach (var list1 in errorDataslist)
                    {
                        Error_Report_json overall2 = new Error_Report_json();
                         overall2.Date = list1.Date;
                         overall2.Time = list1.Time;
                         
                         foreach (var list2 in list1.error_list)
                         {
                            Error_Report_json.Error_array err_array = new Error_Report_json.Error_array();
                             err_array.errorcode = list2.errorcode;
                             err_array.error_description = list2.error_description;
                             err_array.Time = list2.Time;
                             
                             sb.Clear();
                             sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), sum(Timedifference) from braiding.machinedata");
                             sb.Append(" inner join error on error.machinedata_id=machinedata._id");
                             sb.Append(string.Format(" where cast(Date as date)='{0}' and errorcode={1}", list1.Date, list2.errorcode));
                             sb.Append(" group by error.codegrouping");
                             sql = sb.ToString();
                             using (MySqlCommand command = new MySqlCommand(sql, conn))
                             {
                                 using (MySqlDataReader reader = command.ExecuteReader())
                                 {
                                     while (reader.Read())
                                     {
                                        Error_Report_json.Error_array.time_array obj = new Error_Report_json.Error_array.time_array();                                         
                                         obj.Starttime = reader.GetTimeSpan(0);
                                         obj.Endtime = reader.GetTimeSpan(1);
                                         obj.Time = TimeSpan.FromSeconds(reader.GetDouble(2));
                                         err_array.timearray.Add(obj);
                                     }
                                 }
                             }
                             overall2.error_times.Add(err_array);
                         }
                        Error_json.Add(overall2);
                    }                    
                }
                return Ok(new { Error_json });
            }

            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class DateWiseTotalErrorTime
        {
            public string Date;
            public TimeSpan Time;
        }
        public class ErrorlistDateWise
        {
            public string Date;
            public TimeSpan Time;
            public List<err_list> error_list = new List<err_list>();
            public err_list err_ { get; set; }           
            public class err_list
            {
                public int errorcode { get; set; }
                public string error_description { get; set; }
                public TimeSpan Time { get; set; }
            }

        }
        public class Error_Report_json
        {
            public string Date;
            public TimeSpan Time { get; set; }
            public List<Error_array> error_times = new List<Error_array>();
            public class Error_array
            {
                public int errorcode;
                public string error_description;
                public TimeSpan Time { get; set; }
                public List<time_array> timearray = new List<time_array>();
                public class time_array
                {
                    public TimeSpan Starttime { get; set; }
                    public TimeSpan Endtime { get; set; }
                    public TimeSpan Time { get; set; }
                }
            }        
        }
        
        [HttpGet]
        public IActionResult ShiftsData(DateTime From, DateTime To)
        {
            try
            {
                List<ShiftDetails> shiftwiselist = new List<ShiftDetails>();
                ShiftDetails shiftDetails = null;
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("update machinedata md set shift_name=(select ShiftName from shifttime st where cast(md.Date as time)>=st.In_time and cast(md.Date as time)<st.Out_time),");
                    sb.Append("shift_date = (SELECT DATE_SUB(Cast(md.Date as date), INTERVAL (select days from shifttime st where cast(md.Date as time)>= st.In_time and cast(md.Date as time)< st.Out_time) DAY))");
                    sb.Append("Where md._id > 0;");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int ival = command.ExecuteNonQuery();
                    }
                    sb.Clear();
                    sb.Append("SELECT  max(cumulativelength)-min(cumulativelength) as length,shift_name,shift_date FROM machinedata");
                    sb.Append(string.Format(" where cumulativelength > 1 and shift_date between '{0}' and '{1}'", From.ToString("yyyy-MM-dd"), To.ToString("yyyy-MM-dd")));
                    sb.Append("group by shift_date,shift_name");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                shiftDetails = new ShiftDetails();
                                shiftDetails.length = reader.GetInt32(0);
                                shiftDetails.shiftName = reader.GetString(1);
                                shiftDetails.Date = reader.GetDateTime(2);
                                shiftwiselist.Add(shiftDetails);
                            }
                        }
                    }
                }
                var shift = shiftwiselist.OrderBy(y => y.shiftName).Select(x => x.shiftName).Distinct();
                var datelist = shiftwiselist.Select(x => x.Date).Distinct().ToList();
                var datelist1 = shiftwiselist.Select(x => x.Date.Date.ToString("yyyy-MM-dd")).Distinct().ToList();
                List<string> date_format = new List<string>();
                List<List<int>> listOfList = new List<List<int>>();
                foreach (var shiftname in shift)
                { 
                    List<int> lengthlist = new List<int>();
                    foreach (var date in datelist)
                    {
                        var length = shiftwiselist.Where(x => x.Date == date & x.shiftName == shiftname).Select(x => x.length).FirstOrDefault();
                        if (length != 0)
                        {
                            lengthlist.Add(length);
                        }
                        else
                        {
                            lengthlist.Add(0);
                        }
                    }
                    listOfList.Add(lengthlist);
                }
                foreach(var i in datelist1)
                {
                    date_format.Add(i.Substring(8)+"-"+i.Substring(5,2));
                }
                return Ok(new[] {
                    new
                    {
                                  shift = shift,
                                  date = date_format,
                                  length=listOfList
                    }
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }

        public class ShiftDetails
        {
            public DateTime Date;
            public string shiftName;
            public int length;
        }
        public class Errorwithgrouping
        {
            public string Prev_errorcode { get; internal set; }
            public double Prev_codegrouping { get; internal set; }
            public string alarm_code { get; set; }
            public string fault_code { get; set; }
        }

        [HttpGet]
        public IActionResult SpeedData_Graph(DateTime From, DateTime To)
        {
            try
            {
                List<SpeedData> speed_list = new List<SpeedData>();
                SpeedData speed = null;
                string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
                string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("SELECT Date,d1_speed,d2_speed FROM machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}'", FromDate, ToDate));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                speed = new SpeedData();
                                if (reader["d1_speed"] != DBNull.Value)
                                {
                                    speed.dateTime = reader.GetDateTime(0);
                                    speed.d1_speed = reader.GetDouble(1);
                                    speed.d2_speed = reader.GetDouble(2);
                                    speed_list.Add(speed);
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                    }
                }
                return Ok(new { date_time = speed_list.Select(x => x.dateTime), d1_speed = speed_list.Select(x => x.d1_speed), d2_speed = speed_list.Select(x => x.d2_speed) });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public class SpeedData
        {
            public DateTime dateTime;
            public Double d1_speed;
            public Double d2_speed;
        }

        [HttpGet]
        public IActionResult CurrentData_Graph(DateTime From, DateTime To)
        {
            try
            {
                List<CurrentData> current_list = new List<CurrentData>();
                CurrentData current = null;
                string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
                string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("SELECT Date,D1_Current,D2_Current,Cat_Current FROM machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}'", FromDate, ToDate));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                current = new CurrentData();
                                if (reader["d1_current"] != DBNull.Value)
                                {
                                    current.dateTime = reader.GetDateTime(0);
                                    current.d1_current = reader.GetDouble(1);
                                    current.d2_current = reader.GetDouble(2);
                                    current.cat_current = reader.GetDouble(3);
                                    current_list.Add(current);
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                    }
                }
                return Ok(new { date_time = current_list.Select(x => x.dateTime), d1_current = current_list.Select(x => x.d1_current), d2_current = current_list.Select(x => x.d2_current), cat_current = current_list.Select(x => x.cat_current) });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public class CurrentData
        {
            public DateTime dateTime;
            public Double d1_current;
            public Double d2_current;
            public Double cat_current;
        }
    }
}
