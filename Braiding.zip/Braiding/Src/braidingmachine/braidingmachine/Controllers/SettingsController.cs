﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using braidingmachine.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;

namespace braidingmachine.Controllers
{
    public class SettingsController : Controller
    {
        public IConfiguration Configuration { get; }
        private appvilledbContext _context;
        public SettingsController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public class shift_details
        {
            public TimeSpan intime;
            public TimeSpan outtime;
            public string shiftname;
            public int days;
        }
        public IActionResult Settings()
        {

          /*  string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            List<shift_details> shiftdetails = new List<shift_details>();
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                MySqlTransaction transaction;
                transaction = conn.BeginTransaction();
                try
                {
                    int[] days = new int[3] { 0, 0, 0 };
                    int[] id = new int[4] { 1, 2, 3, 4 };
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", shift1_from, shift1_to, name[0], days[0], id[0]));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                shift_details shift = new shift_details();
                                shift.intime = reader.GetTimeSpan(0);
                                shift.outtime = reader.GetTimeSpan(1);
                                shift.shiftname = reader.GetString(2);
                                shift.days = reader.GetInt32(3);
                                
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return BadRequest(ex.Message);
                }
                */
                return View();
            }
        [HttpGet]
        public IActionResult Settings(string shift1_from, string shift1_to, string shift2_from, string shift2_to, string shift3_from, string shift3_to)
        {
            try
            {
                if (shift1_from == null)
                {
                    return View();
                }
                else
                {
                    string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                    using (MySqlConnection conn = new MySqlConnection(connectionString))
                    {
                        conn.Open();
                        MySqlTransaction transaction;
                        transaction = conn.BeginTransaction();
                        try
                        {
                            int[] days = new int[3] { 0, 0, 0 };
                            int[] id = new int[4] { 1, 2, 3, 4 };
                            StringBuilder sb = new StringBuilder();
                            string sql = "";
                            string[] name = new string[3] { "shift1", "shift2", "shift3" };
                            if (Convert.ToDateTime(shift1_from) < Convert.ToDateTime(shift1_to))
                            {
                                days[0] = 0;
                                sb.Clear();
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", shift1_from, shift1_to, name[0], days[0], id[0]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                var temp_to = TimeSpan.Parse("23:59:59");
                                days[0] = 1;
                                sb.Clear();
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", shift1_from, temp_to, name[0], days[0], id[0]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                                sb.Clear();
                                var temp_from = TimeSpan.Parse("00:00:00");
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", temp_from, shift1_to, name[0], days[0], id[3]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                            }
                            if (Convert.ToDateTime(shift2_from) < Convert.ToDateTime(shift2_to))
                            {
                                days[1] = 0;
                                sb.Clear();
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", shift2_from, shift2_to, name[1], days[1], id[1]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                var temp_to = TimeSpan.Parse("23:59:59");
                                days[1] = 1;
                                sb.Clear();
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", shift2_from, temp_to, name[1], days[1], id[1]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                                sb.Clear();
                                var temp_from = TimeSpan.Parse("00:00:00");
                                sb.Append(string.Format("update shift_table1 SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", temp_from, shift2_to, name[0], days[0], id[3]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                            }
                            if (Convert.ToDateTime(shift3_from) < Convert.ToDateTime(shift3_to))
                            {
                                days[2] = 0;
                                sb.Clear();
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", shift3_from, shift3_to, name[2], days[2], id[2]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                var temp_to = TimeSpan.Parse("23:59:59");
                                days[2] = 1;
                                sb.Clear();
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", shift3_from, temp_to, name[2], days[2], id[2]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                                sb.Clear();
                                var temp_from = TimeSpan.Parse("00:00:00");
                                sb.Append(string.Format("update shifttime SET In_time='{0}',Out_time='{1}',ShiftName='{2}',days='{3}' WHERE _id = {4}", temp_from, shift3_to, name[0], days[0], id[3]));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    int ival = command.ExecuteNonQuery();
                                }
                            }
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                    }

                    return Ok("success");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
/*[HttpGet]
public IActionResult Settings(string shift1_from, string shift1_to, string shift2_from, string shift2_to, string shift3_from, string shift3_to)
{
    try
    {
        if (shift1_from == null)
        {
            return View();
        }
        else
        {
            _context = new appvilledbContext();
            int[] days = new int[3] { 0, 0, 0 };
            string[] name = new string[3] { "shift1", "shift2", "shift3" };
            int[] id = new int[3] { 1, 2, 3 };
            if (Convert.ToDateTime(shift1_from) < Convert.ToDateTime(shift1_to))
            {
                days[0] = 0;
                var a = _context.ShiftTable.Where(x => x._id == 1).FirstOrDefault();
                a.In_time = TimeSpan.Parse(shift1_from);
                a.Out_time = TimeSpan.Parse(shift1_to);
                a.days = 0;
                a.ShiftName = "shift1";
                _context.ShiftTable.Update(a);
            }
            else
            {
                days[0] = 1;
                var a = _context.ShiftTable.Where(x => x._id == 1).FirstOrDefault();
                a.In_time = TimeSpan.Parse(shift1_from);
                a.Out_time = TimeSpan.Parse("23:59:59");
                a.days = 1;
                a.ShiftName = "shift1";
                _context.ShiftTable.Update(a);
                ShiftTable shift1 = new ShiftTable();
                shift1.In_time = TimeSpan.Parse("00:00:00");
                shift1.Out_time = TimeSpan.Parse(shift1_to);
                shift1.ShiftName = "shift1";
                shift1.days = 0;
                _context.ShiftTable.Add(shift1);
                _context.SaveChanges();

            }
            if (Convert.ToDateTime(shift2_from) < Convert.ToDateTime(shift2_to))
            {
                days[1] = 0;
                var a = _context.ShiftTable.Where(x => x._id == 2).FirstOrDefault();
                a.In_time = TimeSpan.Parse(shift2_from);
                a.Out_time = TimeSpan.Parse(shift2_to);
                a.days = 0;
                a.ShiftName = "shift2";
                _context.ShiftTable.Update(a);
            }
            else
            {
                days[1] = 1;
                var a = _context.ShiftTable.Where(x => x._id == 2).FirstOrDefault();
                a.In_time = TimeSpan.Parse(shift2_from);
                a.Out_time = TimeSpan.Parse("23:59:59");
                a.days = 1;
                a.ShiftName = "shift2";
                _context.ShiftTable.Update(a);
                ShiftTable shift2 = new ShiftTable();
                shift2.In_time = TimeSpan.Parse("00:00:00");
                shift2.Out_time = TimeSpan.Parse(shift2_to);
                shift2.ShiftName = "shift2";
                shift2.days = 0;
                _context.ShiftTable.Add(shift2);
                _context.SaveChanges();
            }
            if (Convert.ToDateTime(shift3_from) < Convert.ToDateTime(shift3_to))
            {
                days[2] = 0;
                var a = _context.ShiftTable.Where(x => x._id == 3).FirstOrDefault();
                a.In_time = TimeSpan.Parse(shift3_from);
                a.Out_time = TimeSpan.Parse(shift3_to);
                a.days = 0;
                a.ShiftName = "shift3";
                _context.ShiftTable.Update(a);
            }
            else
            {
                days[2] = 1;
                var a = _context.ShiftTable.Where(x => x._id == 3).FirstOrDefault();
                a.In_time = TimeSpan.Parse(shift3_from);
                a.Out_time = TimeSpan.Parse("23:59:59");
                a.days = 1;
                a.ShiftName = "shift3";
                _context.ShiftTable.Update(a);
                ShiftTable shift3 = new ShiftTable();
                shift3.In_time = TimeSpan.Parse("00:00:00");
                shift3.Out_time = TimeSpan.Parse(shift3_to);
                shift3.ShiftName = "shift3";
                shift3.days = 0;
                _context.ShiftTable.Add(shift3);
                _context.SaveChanges();
            }
            return null;
        }
    }
    catch (Exception ex)
    {
        throw ex;
    }
}*/
