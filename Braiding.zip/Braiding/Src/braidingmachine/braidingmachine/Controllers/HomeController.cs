﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using braidingmachine.Models;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace braidingmachine.Controllers
{
    public class HomeController : Controller
    {
        public IConfiguration Configuration { get; }
        public HomeController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index([Bind("Username,Password")] Login_Table Login_Table)
        {
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();                   
                    try
                    {
                        StringBuilder sb = new StringBuilder();
                        string sql = "";
                        sb.Append("SELECT Username,Password FROM login_table");
                        sb.Append(string.Format(" where Username='{0}' and Password='{1}'", Login_Table.Username, Login_Table.Password));
                        sql = sb.ToString();
                        var username = "";
                        var password = "";

                        using (MySqlCommand command = new MySqlCommand(sql, conn))
                        {
                            using (MySqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    if (reader["username"] != DBNull.Value)
                                    {
                                        username = reader.GetString(0);
                                        password = reader.GetString(1);
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        if (username != "" && password != "")
                        {
                            HttpContext.Session.SetInt32("login", 123);
                            HttpContext.Session.GetInt32("login");                           
                            return RedirectToAction("braiding1", "braiding1");
                        }
                        else
                        {
                            ViewBag.Message = "Incorrect Username or Password";
                            return View("Index");
                        }
                    }
                    catch (Exception ex)
                    {                        
                        return BadRequest(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        public IActionResult Logout()
        {
            // Session.Abandon();
            HttpContext.Session.Clear();
            return View("Index");
        }
    }
}
