import snap7
import json
import requests
import urllib.parse
import datetime
import time
import paho.mqtt.client as paho
import random
import string

while True:
    try:
        plc = snap7.client.Client()
        plc.connect('192.168.1.20',0,1)
        #broker="broker.hivemq.com"
        #broker="iot.eclipse.org"
        broker="m16.cloudmqtt.com"
        #broker="104.214.79.73"
        def on_message(client, userdata, message):
            time.sleep(1)
            print("received message =",str(message.payload.decode("utf-8")))
        def randomString(stringLength=10):
            """Generate a random string of fixed length """
            letters = string.ascii_lowercase
            return ''.join(random.choice(letters) for i in range(stringLength))
        # port=1883
        port=12651
        # username="appville"
        # password="App123Ville"
        username="awebbgpr"
        password="AM8VpNvqgSJA"
        client = paho.Client(randomString())
        print("conneting..")
        client.on_message=on_message
        client.username_pw_set(username, password)
        client.connect(broker,port) #create client object 
        client.loop_start()
        #client.subscribe("braiding/6080")
        iCount = 0
        while True:

            #date_time
            currentDT = datetime.datetime.now()
            currentdt = currentDT.strftime("%Y-%m-%d %H:%M:%S")

            #Healthy Time of PLC1
            healthy_sec = plc.db_read(35,86,2)
            healthy_min = plc.db_read(35,88,2)
            healthy_hour = plc.db_read(35,90,2)
            healthy_sec_val = snap7.util.get_int(healthy_sec,0)
            healthy_min_val = snap7.util.get_int(healthy_min,0)
            healthy_hour_val = snap7.util.get_int(healthy_hour,0)
            healthy_time1 = healthy_hour_val*60+healthy_min_val
            healthy_time2 = round(healthy_time1)
            healthy_time = str(healthy_time2)
            #print("Healthy time of PLC1 "+healthy_time)

            #Healthy Time of PLC2
            # healthy_sec1 = plc2.db_read(35,86,2)
            # healthy_min1 = plc2.db_read(35,88,2)
            # healthy_hour1 = plc2.db_read(35,90,2)
            # healthy_sec_val1 = snap7.util.get_int(healthy_sec1,0)
            # healthy_min_val1 = snap7.util.get_int(healthy_min1,0)
            # healthy_hour_val1 = snap7.util.get_int(healthy_hour1,0)
            # healthy_time11 = healthy_hour_val1*60+healthy_min_val1
            # healthy_time22 = round(healthy_time11)
            # healthy_time1 = str(healthy_time22)
            # print("Healthy time of PLC2 "+healthy_time1)

            #Running Time of PLC1
            running_sec = plc.db_read(35,92,2)
            running_min = plc.db_read(35,94,2)
            running_hour = plc.db_read(35,96,2)
            running_sec_val = snap7.util.get_int(running_sec,0)
            running_min_val = snap7.util.get_int(running_min,0)
            running_hour_val = snap7.util.get_int(running_hour,0)
            up_time1 = running_hour_val*60+running_min_val
            up_time2 = round(up_time1)
            up_time = str(up_time2)
            #print("up time of PLC1 "+up_time)

            #Running Time of PLC2
            # running_sec1 = plc2.db_read(35,92,2)
            # running_min1 = plc2.db_read(35,94,2)
            # running_hour1 = plc2.db_read(35,96,2)
            # running_sec_val1 = snap7.util.get_int(running_sec1,0)
            # running_min_val1 = snap7.util.get_int(running_min1,0)
            # running_hour_val1 = snap7.util.get_int(running_hour1,0)
            # up_time11 = running_hour_val1*60+running_min_val1
            # up_time22 = round(up_time11)
            # up_time1 = str(up_time22)
            # print("up time of PLC2 "+up_time1)

            #Fault Time of PLC1
            fault_sec = plc.db_read(35,98,2)
            fault_min = plc.db_read(35,100,2)
            fault_hour = plc.db_read(35,102,2)
            fault_sec_val = snap7.util.get_int(fault_sec,0)
            fault_min_val = snap7.util.get_int(fault_min,0)
            fault_hour_val = snap7.util.get_int(fault_hour,0)
            fault_time1 = fault_hour_val*60+fault_min_val
            fault_time2 = round(fault_time1)
            fault_time = str(fault_time2)
            #print("fault time of PLC1 "+fault_time)

            #Fault Time of PLC2
            # fault_sec1 = plc2.db_read(35,98,2)
            # fault_min1 = plc2.db_read(35,100,2)
            # fault_hour1 = plc2.db_read(35,102,2)
            # fault_sec_val1 = snap7.util.get_int(fault_sec,0)
            # fault_min_val1 = snap7.util.get_int(fault_min,0)
            # fault_hour_val1 = snap7.util.get_int(fault_hour,0)
            # fault_time11 = fault_hour_val1*60+fault_min_val1
            # fault_time22 = round(fault_time11)
            # fault_time1 = str(fault_time22)
            # print("fault time of PLC2 "+fault_time1)

            #Carrier_rpm
            Carrier_rpm = plc.db_read(35,0,4)
            Carrier_rpm_val= snap7.util.get_real(Carrier_rpm, 0)

            #Cat_rpm
            Cat_rpm = plc.db_read(35,8,4)
            Cat_rpm_val= snap7.util.get_real(Cat_rpm, 0)

            #mot_rpm
            mot_rpm = plc.db_read(35,16,4)
            mot_rpm_val= snap7.util.get_real(mot_rpm, 0)
            #Production_Length
            Production_Length = plc.db_read(35,38,4)
            Production_Length_val= snap7.util.get_real(Production_Length, 0)
            #print(Production_Length_val)

            #Deck1_Pitch_PLC
            Deck1_Pitch_PLC = plc.db_read(35,42,4)
            Deck1_Pitch_PLC_val= snap7.util.get_real(Deck1_Pitch_PLC, 0)
            #print(Deck1_Pitch_PLC_val)

            #Hose_Dia
            Hose_Dia = plc.db_read(35,46,4)
            Hose_Dia_val= snap7.util.get_real(Hose_Dia, 0)
            #print(Hose_Dia_val)

            #Machine Running Status
            Machine_Running_Status = plc.db_read(35,84,1)
            Machine_Running_Status_val = snap7.util.get_bool(Machine_Running_Status,0,6)
            #print(Fault_Bit_val)
            #CAT_Power
            CAT_Power = plc.db_read(35,50,4)
            CAT_Power_val= snap7.util.get_real(CAT_Power, 0)

            #D1_Current
            CAT_Current = plc.db_read(35,54,4)
            CAT_Current_val= snap7.util.get_real(CAT_Current, 0)

            #D1_Power
            D1_Power = plc.db_read(35,50,4)
            D1_Power_val= snap7.util.get_real(D1_Power, 0)

            #D1_Current
            D1_Current = plc.db_read(35,54,4)
            D1_Current_val= snap7.util.get_real(D1_Current, 0)

            Error_List = []
            #Bobbin_Empty
            Bobbin_Empty = plc.db_read(35,84,1)
            Bobbin_Empty_val = snap7.util.get_bool(Bobbin_Empty,0,5)
            if(Bobbin_Empty_val==True):
                Error_List.append(1);
            #print(Bobbin_Empty_val)

            #Check_Flap_Sensor
            Check_Flap_Sensor = plc.db_read(35,75,1)
            Check_Flap_Sensor_val= snap7.util.get_bool(Check_Flap_Sensor, 0,1)
            if(Check_Flap_Sensor_val==True):
                Error_List.append(2);
            #Wire_Cut
            Wire_Cut = plc.db_read(35,84,1)
            Wire_Cut_val = snap7.util.get_bool(Wire_Cut,0,1)
            if(Wire_Cut_val==True):
                Error_List.append(3);

            #Deck1_fault_or_alarm
            Deck1_fault_or_alarm = plc.db_read(35,84,1)
            Deck1_fault_or_alarm_val = snap7.util.get_bool(Deck1_fault_or_alarm,0,3)
            #print(Deck1_fault_or_alarm_val)
            if(Deck1_fault_or_alarm_val==True):
                Error_List.append(4)
                #D1_Fault
                D1_Fault = plc.db_read(35,80,4)
                D1_Fault_val = str(snap7.util.get_dword(D1_Fault,0))
                #D1_Alarm
                D1_Alarm = plc.db_read(35,82,4)
                D1_Alarm_val = str(snap7.util.get_dword(D1_Alarm,0))
            else:
                D1_Fault_val="";
                D1_Alarm_val="";

            #Cat_drive_fault_or_alarm
            Cat_drive_fault_or_alarm = plc.db_read(35,84,1)
            Cat_drive_fault_or_alarm_val = snap7.util.get_bool(Cat_drive_fault_or_alarm,0,2)
            #print(Cat_drive_fault_or_alarm_val)
            if(Cat_drive_fault_or_alarm_val==True):
                Error_List.append(5);
                #CAT_Fault_CODE
                CAT_Fault_CODE = plc.db_read(35,76,4)
                CAT_Fault_CODE_val = str(snap7.util.get_dword(CAT_Fault_CODE,0))
                #CAT_Alarm_CODE
                CAT_Alarm_CODE = plc.db_read(35,78,4)
                CAT_Alarm_CODE_val = str(snap7.util.get_dword(CAT_Alarm_CODE,0))
            else:
                CAT_Fault_CODE_val="";
                CAT_Alarm_CODE_val="";
            error_string = str(Error_List).strip('[]')

            Machine_details={'date_time':currentdt,'healthy_time':healthy_time,'up_time':up_time,'fault_time':fault_time,'Carrier_rpm':Carrier_rpm_val,'cat_rpm':Cat_rpm_val,'cat_mot_rpm':mot_rpm_val,'Production_Length':Production_Length_val,'Deck1_Pitch_PLC':Deck1_Pitch_PLC_val,'Machine_Running_Status_val':Machine_Running_Status_val,'D1_Power':D1_Power_val,'D1_Current':D1_Current_val,"Error":error_string,'CAT_Fault_CODE':CAT_Fault_CODE_val,'CAT_Alarm_CODE':CAT_Alarm_CODE_val,'D1_Fault':D1_Fault_val,'D1_Alarm':D1_Alarm_val,'CAT_Power':CAT_Power_val,'CAT_Current':CAT_Current_val}
            Machine_details = json.dumps(Machine_details)
            print(Machine_details)
            #print("json")
            time.sleep(1)
            iCount += 1
            temp = "single_braiding/"
            topic="6080"
            combine=temp+topic
            #print(combine)
            
            #client.subscribe(combine)
            client.publish(combine,Machine_details)
            if (iCount >15):
                iCount = 0
                try:
                    post_req = Machine_details
                    braiding_url = "https://singlebraiding.azurewebsites.net/InsertMachineData/Create?Machine_details="+ urllib.parse.quote(Machine_details)
                    #print(utility_url)
                    braiding_req = requests.post(url=braiding_url)
                    print(braiding_req.text)
                except Exception as ex:
                    print('error:-', ex)
    except Exception as exep:
        print("outer error:-", exep)
