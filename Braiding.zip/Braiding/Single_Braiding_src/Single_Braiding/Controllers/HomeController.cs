﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Single_Braiding.Models;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System.Text;

namespace braidingmachine.Controllers
{
    public class HomeController : Controller
    {
        public IConfiguration Configuration { get; }
        public HomeController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index([Bind("Username,Password")] LoginTable Login_Table)
        {
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                MySqlTransaction transaction;
                transaction = conn.BeginTransaction();
                int count = 0;
                try
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Append("SELECT Username,Password FROM login_table");
                    sb.Append(string.Format(" where Username='{0}' and Password='{1}'", Login_Table.Username, Login_Table.Password));
                    sql = sb.ToString();
                    var username = "";
                    var password = "";

                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                username = reader.GetString(0);
                                password = reader.GetString(1);
                            }
                        }
                    }
                    if (username != "" && password != "")
                    {
                        count++;
                    }
                    else
                    {
                        count = 0;
                    }
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return BadRequest(ex.Message);
                }
                if (count != 0)
                    return RedirectToAction("braiding1", "braiding1");
                else
                    ViewBag.Message = "Incorrect Username or Password";
                return View("Index");
            }
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
