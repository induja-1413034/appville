﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Single_Braiding.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Single_Braiding.Models;

namespace InsertMachineData.Controllers
{
    public class InsertMachineDataController : Controller
    {
        public IConfiguration Configuration { get; }
        public InsertMachineDataController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Create(string Machine_details)
        {
            try
            {
                MachineData machine = new MachineData();
                machine = JsonConvert.DeserializeObject<MachineData>(Machine_details);
                List<string> errorcodes_new = new List<string>();
                List<braiding1Controller.Errorwithgrouping> errorcodes_old = new List<braiding1Controller.Errorwithgrouping>();
                braiding1Controller.Errorwithgrouping errorwithgrouping = null;
                List<Error> errorInsertlist = new List<Error>();
                Error errorInsert = null;
                int machinedata_id = 0;
                DateTime PreviousDatetime = DateTime.MinValue;
                double Previouspitch = 0;
                double Previouspitchgrouping = 0;
                double Previouscumulativelength = 0;
                TimeSpan time = new TimeSpan();
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    MySqlTransaction transaction;
                    transaction = conn.BeginTransaction();
                    try
                    {
                        StringBuilder sb = new StringBuilder();
                        string sql = "";
                        sb.Clear();
                        if (machine.Deck1_Pitch_PLC == 0 & machine.fault_time == 0 &
                            machine.healthy_time == 0 & machine.up_time == 0 & machine.currentlength == 0)
                        {
                            return Ok(new
                            {
                                message = "Skipped because of 0 values"
                            });
                        }
                        else
                        {
                            if (machine.Error != null)
                            {
                                errorcodes_new = machine.Error.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.Trim()).ToList();
                                int Previousmachinedata_id = 0;
                                bool isFoundnull = false;
                                sb.Clear();
                                sb.Append("SELECT _id, errorcode, codegrouping, alarm_code, fault_code FROM machine_data_error_view");
                                sb.Append(string.Format(" where _id=(select max(_id) from braiding.machine_data_error_view)"));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    using (MySqlDataReader reader = command.ExecuteReader())
                                    {
                                        while (reader.Read())
                                        {
                                            errorInsert = new Error();
                                            Previousmachinedata_id = reader.GetInt32(0);
                                            if (reader["errorcode"] != DBNull.Value)
                                            {
                                                errorwithgrouping = new braiding1Controller.Errorwithgrouping();
                                                errorwithgrouping.Prev_errorcode = reader.GetString(1);
                                                errorwithgrouping.Prev_codegrouping = reader.GetDouble(2);
                                                errorcodes_old.Add(errorwithgrouping);
                                            }
                                            else
                                            {
                                                isFoundnull = true;
                                                break;
                                            }
                                        }
                                        if (isFoundnull == true)
                                        {
                                            foreach (var err in errorcodes_new)
                                            {
                                                errorInsert = new Error();
                                                errorInsert.machinedata_id = machinedata_id;
                                                errorInsert.errorcode = err;
                                                errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                                errorInsertlist.Add(errorInsert);
                                            }
                                        }
                                    }
                                }
                                sb.Clear();
                                sb.Append("SELECT Date, pitch, pitchgrouping,cumulativelength FROM machinedata");
                                sb.Append(string.Format(" ORDER BY _id DESC LIMIT 1"));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    using (MySqlDataReader reader = command.ExecuteReader())
                                    {
                                        while (reader.Read())
                                        {
                                            PreviousDatetime = reader.GetDateTime(0);
                                            Previouspitch = reader.GetDouble(1);
                                            Previouspitchgrouping = reader.GetInt32(2);
                                            Previouscumulativelength = reader.GetInt32(3);
                                        }
                                    }
                                }
                                sb.Clear();
                                sb.Append("INSERT INTO machinedata(Date, cumulativelength, pitch, healthytime, runningtime, faulttime, pitchgrouping, Timedifference, currentlength, Carrier_rpm, cat_rpm, cat_mot_rpm, Machine_Running_Status_val,D1_Current,D1_Power,D1_Fault,D1_Alarm,CAT_Fault_CODE,CAT_Alarm_CODE,CAT_Power,CAT_Current)");
                                sb.Append(" VALUES(@Date,@cumulativelength,@pitch, @healthytime, @runningtime, @faulttime, @pitchgrouping, @Timedifference, @currentlength,@Carrier_rpm, @cat_rpm, @cat_mot_rpm ,@Machine_Running_Status_val,@D1_Current,@D1_Power,@D1_Fault,@D1_Alarm,@CAT_Fault_CODE,@CAT_Alarm_CODE,@CAT_Power,@CAT_Current);");
                                sb.Append(" select last_insert_id() as _id");
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    command.Parameters.AddWithValue("@Date", machine.date_time);
                                    command.Parameters.AddWithValue("@cumulativelength", machine.Production_Length);
                                    command.Parameters.AddWithValue("@pitch", machine.Deck1_Pitch_PLC);
                                    command.Parameters.AddWithValue("@healthytime", machine.healthy_time);
                                    command.Parameters.AddWithValue("@faulttime", machine.fault_time);
                                    command.Parameters.AddWithValue("@runningtime", machine.up_time);
                                    command.Parameters.AddWithValue("@D1_Current", machine.D1_Current);
                                    command.Parameters.AddWithValue("@D1_Power", machine.D1_Power);
                                    command.Parameters.AddWithValue("@D1_Fault", machine.D1_Fault);
                                    command.Parameters.AddWithValue("@D1_Alarm", machine.D1_Alarm);
                                    command.Parameters.AddWithValue("@CAT_Fault_CODE", machine.CAT_Fault_CODE);
                                    command.Parameters.AddWithValue("@CAT_Alarm_CODE", machine.CAT_Alarm_CODE);
                                    command.Parameters.AddWithValue("@CAT_Power", machine.CAT_Power);
                                    command.Parameters.AddWithValue("@CAT_Current", machine.CAT_Current);


                                    if (Previouspitch == machine.Deck1_Pitch_PLC)
                                    {
                                        machine.pitchgrouping = Previouspitchgrouping;
                                    }
                                    else
                                    {
                                        machine.pitchgrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                    }
                                    command.Parameters.AddWithValue("@pitchgrouping", machine.pitchgrouping);
                                    if (PreviousDatetime == DateTime.MinValue)
                                    {
                                        time = new TimeSpan(0, 0, 0, 0, 0);
                                    }
                                    else
                                    {
                                        time = machine.date_time - PreviousDatetime;
                                    }
                                    machine.Timedifference = time.TotalSeconds;
                                    command.Parameters.AddWithValue("@Timedifference", machine.Timedifference);
                                    if (machine.Production_Length > Previouscumulativelength)
                                    {
                                        machine.currentlength = machine.Production_Length - Previouscumulativelength;
                                    }
                                    else
                                    {
                                        machine.currentlength = Previouscumulativelength - machine.Production_Length;
                                    }
                                    command.Parameters.AddWithValue("@currentlength", machine.currentlength);
                                    command.Parameters.AddWithValue("@Carrier_rpm", machine.Carrier_rpm);
                                    command.Parameters.AddWithValue("@cat_rpm", machine.cat_rpm);
                                    command.Parameters.AddWithValue("@cat_mot_rpm", machine.cat_mot_rpm);
                                    command.Parameters.AddWithValue("@Machine_Running_Status_val", machine.Machine_Running_Status_val);
                                    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                                }
                                if (isFoundnull == false)
                                {
                                    List<ErrorComparator.Error_Results> list_Err_With_Status = new List<ErrorComparator.Error_Results>();
                                    list_Err_With_Status = (new ErrorComparator()).PerformComparison(errorcodes_old, errorcodes_new);
                                    foreach (var err in list_Err_With_Status)
                                    {
                                        if (err.status == "SameErrorgrouping")
                                        {
                                            errorInsert = new Error();
                                            errorInsert.machinedata_id = machinedata_id;
                                            errorInsert.errorcode = err.error;
                                            errorInsert.codegrouping = errorcodes_old.Where(y => y.Prev_errorcode == err.error).Select(x => x.Prev_codegrouping).First();
                                            errorInsertlist.Add(errorInsert);
                                        }
                                        else if (err.status == "NewErrorgrouping")
                                        {
                                            errorInsert = new Error();
                                            errorInsert.machinedata_id = machinedata_id;
                                            errorInsert.errorcode = err.error;
                                            errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                            errorInsertlist.Add(errorInsert);
                                        }
                                    }
                                }
                                foreach (var errinsert in errorInsertlist)
                                {
                                    sb.Clear();
                                    sb.Append("INSERT INTO error(machinedata_id, errorcode, alarm_code, fault_code, codegrouping)");
                                    sb.Append(" VALUES(@machinedata_id, @errorcode, @alarm_code, @fault_code, @codegrouping)");
                                    sql = sb.ToString();
                                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                                    {
                                        command.Connection = conn;
                                        command.Transaction = transaction;
                                        command.Parameters.Clear();
                                        command.Parameters.AddWithValue("@machinedata_id", machinedata_id);
                                        if (errinsert.errorcode == "5")
                                        {
                                            command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                            command.Parameters.AddWithValue("@alarm_code", machine.CAT_Alarm_CODE);
                                            command.Parameters.AddWithValue("@fault_code", machine.CAT_Fault_CODE);
                                        }
                                        else if (errinsert.errorcode == "4")
                                        {
                                            command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                            command.Parameters.AddWithValue("@alarm_code", machine.D1_Alarm);
                                            command.Parameters.AddWithValue("@fault_code", machine.D1_Fault);
                                        }

                                        else
                                        {
                                            command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                            command.Parameters.AddWithValue("@alarm_code", DBNull.Value);
                                            command.Parameters.AddWithValue("@fault_code", DBNull.Value);
                                        }
                                        command.Parameters.AddWithValue("@codegrouping", errinsert.codegrouping);
                                        int iVal = command.ExecuteNonQuery();
                                    }
                                }
                            }
                            else
                            {
                                sb.Clear();
                                sb.Append("SELECT Date,pitch,pitchgrouping,cumulativelength FROM machinedata");
                                sb.Append(string.Format(" ORDER BY _id DESC LIMIT 1"));
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    using (MySqlDataReader reader = command.ExecuteReader())
                                    {
                                        while (reader.Read())
                                        {
                                            PreviousDatetime = reader.GetDateTime(0);
                                            Previouspitch = reader.GetDouble(1);
                                            Previouspitchgrouping = reader.GetInt32(2);
                                            Previouscumulativelength = reader.GetInt32(3);
                                        }
                                    }
                                }
                                sb.Clear();
                                sb.Append("INSERT INTO machinedata(Date, cumulativelength, pitch, healthytime, runningtime, faulttime, pitchgrouping, Timedifference,currentlength,Carrier_rpm,D1_Power,D1_Current,CAT_Power,CAT_Current)");
                                sb.Append(" VALUES(@Date,@cumulativelength,@pitch,@healthytime, @runningtime, @faulttime, @pitchgrouping, @Timedifference,@currentlength,@Carrier_rpm,@D1_Current,D1_Power,D1_Current,CAT_Power,CAT_Current);");
                                sb.Append(" select last_insert_id() as _id");
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    command.Parameters.AddWithValue("@Date", machine.date_time);
                                    command.Parameters.AddWithValue("@cumulativelength", machine.Production_Length);
                                    command.Parameters.AddWithValue("@pitch", machine.Deck1_Pitch_PLC);
                                    command.Parameters.AddWithValue("@healthytime", machine.healthy_time);
                                    command.Parameters.AddWithValue("@faulttime", machine.fault_time);
                                    command.Parameters.AddWithValue("@runningtime", machine.up_time);
                                    command.Parameters.AddWithValue("@D1_Current", machine.D1_Current);
                                    command.Parameters.AddWithValue("@D1_Power", machine.D1_Power);
                                    command.Parameters.AddWithValue("@D1_Current", machine.CAT_Power);
                                    command.Parameters.AddWithValue("@D1_Power", machine.CAT_Current);
                                    command.Parameters.AddWithValue("@D1_Fault", machine.D1_Fault);
                                    command.Parameters.AddWithValue("@D1_Alarm", machine.D1_Alarm);
                                    command.Parameters.AddWithValue("@CAT_Fault_CODE", machine.CAT_Fault_CODE);
                                    command.Parameters.AddWithValue("@CAT_Alarm_CODE", machine.CAT_Alarm_CODE);
                                    if (Previouspitch == machine.Deck1_Pitch_PLC)
                                    {
                                        machine.pitchgrouping = Previouspitchgrouping;
                                    }
                                    else
                                    {
                                        machine.pitchgrouping = Previouspitchgrouping + 1;
                                    }
                                    command.Parameters.AddWithValue("@pitchgrouping", machine.pitchgrouping);
                                    if (PreviousDatetime == DateTime.MinValue)
                                    {
                                        time = new TimeSpan(0, 0, 0, 0, 0);
                                    }
                                    else
                                    {
                                        time = machine.date_time - PreviousDatetime;
                                    }
                                    machine.Timedifference = time.TotalSeconds;
                                    command.Parameters.AddWithValue("@Timedifference", machine.Timedifference);
                                    if (machine.Production_Length > Previouscumulativelength)
                                    {
                                        machine.currentlength = machine.Production_Length - Previouscumulativelength;
                                    }
                                    else
                                    {
                                        machine.currentlength = Previouscumulativelength - machine.Production_Length;
                                    }
                                    command.Parameters.AddWithValue("@currentlength", machine.currentlength);
                                    command.Parameters.AddWithValue("@Carrier_rpm", machine.Carrier_rpm);
                                    command.Parameters.AddWithValue("@D1_Current", machine.D1_Current);
                                    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                                }
                            }

                            transaction.Commit();
                        }
                    }

                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        return BadRequest(ex.Message);
                    }
                }
                return Ok(new
                {
                    message = "Added Successfully"
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}