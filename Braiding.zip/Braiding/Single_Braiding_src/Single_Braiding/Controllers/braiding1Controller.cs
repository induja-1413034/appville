﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Single_Braiding.Models;

namespace Single_Braiding.Controllers
{
    public class braiding1Controller : Controller
    {
        public IConfiguration Configuration { get; }
        public braiding1Controller(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult braiding1()
        {
            return View();
        }

        

        /*Performance Pie Chart*/
        [HttpGet]
        public ActionResult<TimingData> TimeData(DateTime From, DateTime To)
        {
            List<TimingData> timingDataslist = new List<TimingData>();
            TimingData timingData = new TimingData();
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
                    string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date>='{0}' and Date between '{0}' and '{1}' order by Date limit 1", FromDate, ToDate));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0);
                                timingData.idle_time = reader.GetInt32(1);
                                timingData.error_time = reader.GetInt32(2);

                            }
                        }
                    }
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date<='{1}' and Date between '{0}' and '{1}' ORDER BY Date DESC LIMIT 1", From.ToString("yyyy-MM-dd HH-mm-s"), To.ToString("yyyy-MM-dd HH-mm-s")));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0) - timingData.up_time;
                                timingData.idle_time = reader.GetInt32(1) - timingData.idle_time;
                                timingData.error_time = reader.GetInt32(2) - timingData.error_time;
                                timingDataslist.Add(timingData);
                            }
                        }
                    }
                    return Ok(timingDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class TimingData
        {
            public int idle_time;
            public int error_time;
            public int up_time;
        }


        [HttpGet]
        public IActionResult ShiftsData(DateTime From, DateTime To)
        {
            try
            {
                List<ShiftDetails> shiftwiselist = new List<ShiftDetails>();
                ShiftDetails shiftDetails = null;
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("update machinedata md set shift_name=(select ShiftName from shifttime st where cast(md.Date as time)>=st.In_time and cast(md.Date as time)<st.Out_time),");
                    sb.Append("shift_date = (SELECT DATE_SUB(Cast(md.Date as date), INTERVAL (select days from shifttime st where cast(md.Date as time)>= st.In_time and cast(md.Date as time)< st.Out_time) DAY))");
                    sb.Append("Where md._id > 0;");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int ival = command.ExecuteNonQuery();
                    }
                    sb.Clear();
                    sb.Append("SELECT  max(cumulativelength)-min(cumulativelength) as length,shift_name,shift_date FROM machinedata");
                    sb.Append(string.Format(" where cumulativelength > 1 and shift_date between '{0}' and '{1}'", From.ToString("yyyy-MM-dd"), To.ToString("yyyy-MM-dd")));
                    sb.Append("group by shift_date,shift_name");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                shiftDetails = new ShiftDetails();
                                shiftDetails.length = reader.GetInt32(0);
                                shiftDetails.shiftName = reader.GetString(1);
                                shiftDetails.Date = reader.GetDateTime(2);
                                shiftwiselist.Add(shiftDetails);
                            }
                        }

                    }
                    Console.WriteLine(shiftwiselist);
                }
                var shift = shiftwiselist.OrderBy(y => y.shiftName).Select(x => x.shiftName).Distinct();
                var datelist = shiftwiselist.Select(x => x.Date).Distinct().ToList();
                var datelist1 = shiftwiselist.Select(x => x.Date.Date.ToString("yyyy-MM-dd")).Distinct().ToList();

                List<List<int>> listOfList = new List<List<int>>();

                foreach (var shiftname in shift)
                {
                    //listOfList.Add(new List<int>());  
                    List<int> lengthlist = new List<int>();
                    foreach (var date in datelist)
                    {
                        var length = shiftwiselist.Where(x => x.Date == date & x.shiftName == shiftname).Select(x => x.length).FirstOrDefault();
                        if (length != 0)
                        {
                            lengthlist.Add(length);
                        }
                        else
                        {
                            lengthlist.Add(0);
                        }
                    }
                    listOfList.Add(lengthlist);
                }
                return Ok(new[] {
                    new
                    {
                         shift = shift,
                         date = datelist1,
                         length=listOfList
                    }
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class ShiftDetails
        {
            public DateTime Date;
            public string shiftName;
            public int length;
        }


        [HttpGet]
        public IActionResult PitchDetails(DateTime From, DateTime To)
        {
            List<PitchData> pitchDataslist = new List<PitchData>();
            PitchData pitchData = null;
            string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");            
            string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("SELECT cast(Date as date) as Date,pitch, max(cumulativelength)-min(cumulativelength) as length FROM machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}' and cumulativelength>1 and pitch>0 ", FromDate, ToDate));
                    sb.Append("group by cast(Date as date), pitch order by Date");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                pitchData = new PitchData();
                                pitchData.Date = reader.GetDateTime(0).ToString("yyyy-MM-dd");
                                pitchData.pitch = reader.GetDouble(1);
                                pitchData.length = reader.GetInt32(2);
                                pitchDataslist.Add(pitchData);
                            }
                        }
                    }
                    return Ok(pitchDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class PitchData
        {
            public string Date;
            public double pitch;
            public int length;
        }

        [HttpGet]
        public IActionResult PitchDetailsWithTime(DateTime date, decimal pitch)
        {
            List<PitchDataWithTime> pitchDatastimelist = new List<PitchDataWithTime>();
            PitchDataWithTime pitchDatatime = null;
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), max(cumulativelength)-min(cumulativelength) as length from machinedata");
                    sb.Append(string.Format(" where cast(Date as date)='{0}' and pitch={1} and cumulativelength>1", date.ToString("yyyy-MM-dd"), pitch));
                    sb.Append(" group by pitchgrouping");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                pitchDatatime = new PitchDataWithTime();
                                pitchDatatime.Starttime = reader.GetTimeSpan(0);
                                pitchDatatime.Endtime = reader.GetTimeSpan(1);
                                pitchDatatime.length = reader.GetInt32(2);
                                pitchDatastimelist.Add(pitchDatatime);
                            }
                        }
                    }

                    /* var key = "list";
                     var str = JsonConvert.SerializeObject(pitchDatastimelist);
                     HttpContext.Session.SetString(key, str);
                     return RedirectToAction("PitchReport1", "PitchReport1");*/
                    return Ok(pitchDatastimelist);

                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class PitchDataWithTime
        {
            public TimeSpan Starttime;
            public TimeSpan Endtime;
            public int length;
        }
        public class Errorwithgrouping
        {
            public string Prev_errorcode { get; internal set; }
            public double Prev_codegrouping { get; internal set; }
            public string alarm_code { get; set; }
            public string fault_code { get; set; }
        }
        [HttpGet]
        public IActionResult ErrorDetails(DateTime From, DateTime To)
        {
            List<ErrorData> errorDataslist = new List<ErrorData>();
            ErrorData errorData = null;
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
                    string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
                    sb.Clear();
                    sb.Append("SELECT cast(md.Date as date) as Date, err.errorcode, err_des.error_description,sum(md.Timedifference) FROM machinedata md");
                    sb.Append(string.Format(" inner join error err on md._id = err.machinedata_id"));
                    sb.Append(string.Format(" inner join error_description  err_des on err_des.errorcode = err.errorcode where md.Date between '{0}' and '{1}'", FromDate, ToDate));
                    sb.Append("group by err.errorcode,cast(Date " +
                        "as date)");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                errorData = new ErrorData();
                                errorData.Date = reader.GetDateTime(0).Date.ToString("yyyy-MM-dd");
                                errorData.errorcode = reader.GetString(1);
                                errorData.error_description = reader.GetString(2);
                                errorData.Time = TimeSpan.FromSeconds(reader.GetInt32(3));
                                errorDataslist.Add(errorData);
                            }
                        }
                    }
                    return Ok(errorDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class ErrorData
        {
            public string Date;
            public string errorcode;
            public string error_description;
            public TimeSpan Time;
        }
        [HttpGet]
        public IActionResult ErrorDetailsWithTime(DateTime date, string errorcode)
        {
            List<ErrorDataWithTime> errorDatastimelist = new List<ErrorDataWithTime>();
            ErrorDataWithTime errorDatastime = null;
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    //sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), sum(Timedifference) from braiding");

                    sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), sum(Timedifference) from single_braiding.machinedata");
                    sb.Append(" inner join error on error.machinedata_id=machinedata._id");
                    sb.Append(string.Format(" where cast(Date as date)='{0}' and errorcode={1}", date.ToString("yyyy-MM-dd"), errorcode));
                    sb.Append(" group by error.codegrouping");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                errorDatastime = new ErrorDataWithTime();
                                errorDatastime.Starttime = reader.GetTimeSpan(0);
                                errorDatastime.Endtime = reader.GetTimeSpan(1);
                                errorDatastime.Time = TimeSpan.FromSeconds(reader.GetInt32(2));
                                errorDatastimelist.Add(errorDatastime);
                            }
                        }
                    }
                    return Ok(errorDatastimelist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class ErrorDataWithTime
        {
            public TimeSpan Starttime;
            public TimeSpan Endtime;
            public TimeSpan Time;
        }
        [HttpGet]
        public IActionResult CurrentData_Graph(DateTime From, DateTime To)
        {
            try
            {
                List<CurrentData> current_list = new List<CurrentData>();
                CurrentData current = null;
                string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
                string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("SELECT Date,D1_Current,CAT_Current FROM machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}'", FromDate, ToDate));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                current = new CurrentData();
                                if (reader["D1_Current"] != DBNull.Value)
                                {
                                    current.dateTime = reader.GetDateTime(0);
                                    current.d1_current = reader.GetDouble(1);
                                    current.cat_current = reader.GetDouble(2);
                                    current_list.Add(current);
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }

                    }
                }
                return Ok(new { date_time = current_list.Select(x => x.dateTime), d1_current = current_list.Select(x => x.d1_current), cat_current = current_list.Select(x => x.cat_current) });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public class CurrentData
        {
            public DateTime dateTime;
            public Double d1_current;
            public Double cat_current;
        }
    }
}