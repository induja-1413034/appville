﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Single_Braiding.Models
{
    public class MachineData
    {
        public DateTime date_time;
        public int healthy_time;
        public int up_time;
        public int fault_time;
        public double Carrier_rpm;
        public double cat_rpm;
        public double cat_mot_rpm;
        public double Production_Length;
        public double Deck1_Pitch_PLC;
        public bool Machine_Running_Status_val;
        public double D1_Current;
        public double D1_Power;
        public double CAT_Power;
        public double CAT_Current;
        public string D1_Fault;
        public string D1_Alarm;
        public string CAT_Alarm_CODE;
        public string CAT_Fault_CODE;
        public double pitchgrouping;
        public double Timedifference;
        public double currentlength;
        public string Error;

        //public double hose_diameter;
        //public double Deck_mot_rpm;
        //public double speed;
        //public double cat_speed;
        //public double Current;
        //public double Voltage;
        //public double Cat_Current;
        //public double Cat_Voltage;
        //public bool Fault_Bit;

        //public string Recipe_Name;
        //public string Machine_Number;
        //public string Alarm;
        //public string Fault;
    }
    public class Mac_details
    {
        public string Machine_details;
    }
}
