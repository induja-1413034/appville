﻿using braidingmachine.Controllers;
using Single_Braiding.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Single_Braiding.Models
{
    public class ErrorComparator
    {
        List<Error_Results> Error_Results_instance = new List<Error_Results>();

        public List<Error_Results> PerformComparison(List<braiding1Controller.Errorwithgrouping> previous_error, List<string> new_error)
        {
            Error_Results errorresult = null;
            List<string> all_errors = new List<string>();
            all_errors.AddRange(previous_error.Select(x => x.Prev_errorcode));
            foreach (var item in new_error)
            {
                if (!all_errors.Contains(item))
                    all_errors.Add(item);
            }
            foreach (string err in all_errors)
            {
                if (!new_error.Contains(err))
                {
                    errorresult = new Error_Results();
                    errorresult.error = err;
                    errorresult.status = "Delete";
                    Error_Results_instance.Add(errorresult);
                }
                else if (!previous_error.Select(x => x.Prev_errorcode).Contains(err))
                {
                    errorresult = new Error_Results();
                    errorresult.error = err;
                    errorresult.status = "NewErrorgrouping";
                    Error_Results_instance.Add(errorresult);
                }
                else
                {
                    errorresult = new Error_Results();
                    //if(err == "8" || err == "9" || err == "10")
                    //{
                    //    previous_error.Select(x=>x.)
                    //}
                    errorresult.error = err;
                    errorresult.status = "SameErrorgrouping";
                    Error_Results_instance.Add(errorresult);
                }


            }
            return Error_Results_instance;
        }
        public class Error_Results
        {
            public string error;
            public string status;
        }
    }
}
