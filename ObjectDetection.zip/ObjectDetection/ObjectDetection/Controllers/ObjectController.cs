﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.CognitiveServices.Vision.CustomVision.Training;

namespace ObjectDetection.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ObjectController : ControllerBase
    {
        // Add your training & prediction key from the settings page of the portal
        string trainingKey = "<your training key here>";
        string predictionKey = "<your prediction key here>";

        // Create the Api, passing in the training key
       CustomVisionTrainingClient trainingApi = new CustomVisionTrainingClient()
        {
           /* ApiKey = trainingKey,
            Endpoint = SouthCentralUsEndpoint*/
        };
    }
}