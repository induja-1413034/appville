﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Mqtt_new.Models;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace Mqtt_new.Controllers
{
    public class GtsController : Controller
    {
        public IConfiguration Configuration { get; }
        public GtsController(IConfiguration configuration)
        {
            Configuration = configuration;
        }


        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Savedata(string gtsdetails)
        {
            try
            {
                //var mqtt = gtsdetails;
                MqttModel mqtt = new MqttModel();
                mqtt = JsonConvert.DeserializeObject<MqttModel>(gtsdetails);
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("INSERT INTO mqtt_new(time, user, device_id, AN1, AN2, AN3, AN4)");
                    sb.Append(" VALUES(@time, @user, @device_id, @AN1, @AN2, @AN3, @AN4)");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        command.Parameters.AddWithValue("@time", mqtt.time);
                        command.Parameters.AddWithValue("@user", mqtt.user);
                        command.Parameters.AddWithValue("@device_id", mqtt.deviceId);
                        command.Parameters.AddWithValue("@AN1", mqtt.AN1);
                        command.Parameters.AddWithValue("@AN2", mqtt.AN2);
                        command.Parameters.AddWithValue("@AN3", mqtt.AN3);
                        command.Parameters.AddWithValue("@AN4", mqtt.AN4);
                        int iVal = command.ExecuteNonQuery();
                    }
                }
                return Ok("Added Successfully");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public IActionResult Load_graph()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Load_graph(string a)
       {            
                Mqtt_graph mqtt = null;
                List<Mqtt_graph> mqtt_list = new List<Mqtt_graph>();
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("select time, AN1, AN2, AN3, AN4 from mqtt_new");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                mqtt = new Mqtt_graph();
                               mqtt.time = reader.GetDateTime(0);
                                mqtt.AN1 = reader.GetString(1);
                                mqtt.AN2 = reader.GetString(2);
                                mqtt.AN3 = reader.GetString(3);
                                mqtt.AN4 = reader.GetString(4);
                                mqtt_list.Add(mqtt);
                            }
                        }
                    }
                }
            return Ok(mqtt_list);
                /*return Ok(new
                {
                    time = mqtt_list.Select(x => x.time),
                    AN1 = mqtt_list.Select(x => x.AN1),
                    AN2 = mqtt_list.Select(x => x.AN2),
                    AN3 = mqtt_list.Select(x => x.AN3),
                    AN4 = mqtt_list.Select(x => x.AN4)
                });*/
        }


        public class Mqtt_graph
        {          
            public DateTime time { get; set; }            
            public string AN1 { get; set; }
            public string AN2 { get; set; }
            public string AN3 { get; set; }
            public string AN4 { get; set; }
        }
    }
}