# [0.5.0]() (2018-11-25)

* Added FixedScaleAxis support
