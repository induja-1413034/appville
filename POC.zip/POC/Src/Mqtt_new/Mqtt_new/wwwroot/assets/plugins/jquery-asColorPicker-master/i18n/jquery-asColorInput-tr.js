// asColorPicker
// Turkish (tr) localization

(function($) {
    var localization = $.asColorPicker.localization["tr"] = {
        cancelText: "Avbryt",
        applyText: "Välj"
    };
    $.extend($.asColorPicker.defaults.buttons, localization);
})(jQuery);