﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mqtt_new.Models
{
    public class MqttModel
    {      
        public int sno { get; set; }
        public DateTime time { get; set; }
        public string user { get; set; }
        public string deviceId { get; set; }
        public string AN1 { get; set; }
        public string AN2 { get; set; }
        public string AN3 { get; set; }
        public string AN4 { get; set; }
    }

}


