using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Float_Spot.Controllers;
using System;
using System.Collections.Generic;
using Moq;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            TextDetectionReportController test = new TextDetectionReportController();
             var file = new Mock<IFormFile>();
           /*  var sourceImg = File.OpenRead(@"https://appvillestorage.blob.core.windows.net/textdetectionhistory/20190704T055009383.jpg");
             var stream = new MemoryStream();
             var writer = new StreamWriter(stream);
             writer.Write(sourceImg);
             writer.Flush();
             stream.Position = 0;
             var fileName = "QQ.png";
             file.Setup(f => f.OpenReadStream()).Returns(stream);
             file.Setup(f => f.FileName).Returns(fileName);
             file.Setup(f => f.Length).Returns(stream.Length);

             var controller = new TextDetectionReportController();
             var inputFile = file.Object;
             test.AddBackup_details(inputFile);
             var result =  controller.AddBackup_details(inputFile);*/
            string inputFile = null;
           Assert.IsTrue(inputFile == null);

        }
    }
}
