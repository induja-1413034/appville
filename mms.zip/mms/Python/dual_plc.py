import snap7
import json
import requests
import urllib.parse
import datetime
import time
import paho.mqtt.client as paho
import random
import string

while True:
    try:
        FeederStation = snap7.client.Client()
        FeederStation.connect('192.168.14.215',0,1) #DB - 14
        InspectionStation = snap7.client.Client()
        InspectionStation.connect('192.168.14.216',0,1) #DB - 18
        BufferStation = snap7.client.Client()
        BufferStation.connect('192.168.14.217',0,1) #DB - 11
        ProcessStation = snap7.client.Client()
        ProcessStation.connect('192.168.14.218',0,1) #DB - 13
        SortingStation = snap7.client.Client()
        SortingStation.connect('192.168.14.230',0,1) #DB - 26

        broker="broker.hivemq.com"
        def on_message(client, userdata, message):
            time.sleep(1)
            print("received message =",str(message.payload.decode("utf-8")))
        def randomString(stringLength=10):
            letters = string.ascii_lowercase
            return ''.join(random.choice(letters) for i in range(stringLength))
        port=1883
        #port=12651
        username="awebbgpr"
        password="AM8VpNvqgSJA"
        client = paho.Client(randomString())
        print("conneting..")
        #client.on_message=on_message
        #client.username_pw_set(username, password)
        client.connect(broker,port) #create client object 
        client.loop_start()
        #client.subscribe("MMS_jana")
        iCount = 0
        while True:
            try:
                #date_time
                currentDT = datetime.datetime.now()
                currentdt = currentDT.strftime("%Y-%m-%d %H:%M:%S")
                time.sleep(1)

                #FeederStation
                Emergency1 = FeederStation.db_read(14,4,2)
                Emergency1_int1 = str(snap7.util.get_int(Emergency1,0))
                if(Emergency1_int1=='1')
                    Emergency1_int = '0'
                elif(Emergency1_int1=='0'):
                    Emergency1_int = '1'
                else:
                    Emergency1_int = '1'

                Pressure1  = FeederStation.db_read(14,0,4)
                Pressure1_real = str(snap7.util.get_real(Pressure1, 0))
                if(snap7.util.get_real(Pressure1, 0)<1)
                    FRL_Valve_Close1_real = '1'
                else:
                    FRL_Valve_Close1_real = '0'

                FeedBack1  = FeederStation.db_read(14,6,2)
                FeedBack1_int1 = str(snap7.util.get_int(FeedBack1, 0))
                if(FeedBack1_int1=='1')
                    FeedBack1_int = '0'
                elif(FeedBack1_int1=='0'):
                    FeedBack1_int = '1'
                else:
                    FeedBack1_int = '1'

                Auto_Manual1  = FeederStation.db_read(14,10,2)
                Auto_Manual1_int1 = str(snap7.util.get_int(Auto_Manual1, 0))
                if(Auto_Manual1_int1=='1')
                    Auto_Manual1_int = 'Auto'
                elif(Auto_Manual1_int1=='0'):
                    Auto_Manual1_int = 'Manual'
                else:
                    Auto_Manual1_int = 'Fault'

                No_Of_Strokes1  = FeederStation.db_read(14,8,4)
                No_Of_Strokes1_real = str(snap7.util.get_dword(No_Of_Strokes1, 0))

                #InspectionStation
                Emergency2 = InspectionStation.db_read(18,4,2)
                Emergency2_int2 = str(snap7.util.get_int(Emergency2,0))
                if(Emergency2_int2=='1')
                    Emergency2_int = '0'
                elif(Emergency2_int2=='0'):
                    Emergency2_int = '1'
                else:
                    Emergency2_int = '1'

                Pressure2  = InspectionStation.db_read(18,0,4)
                Pressure2_real = str(snap7.util.get_real(Pressure2, 0))
                if(snap7.util.get_real(Pressure2, 0)<1)
                    FRL_Valve_Close2_real = '1'
                else:
                    FRL_Valve_Close2_real = '0'

                FeedBack2  = InspectionStation.db_read(18,6,2)
                FeedBack2_int2 = str(snap7.util.get_int(FeedBack2, 0))
                if(FeedBack2_int2=='1')
                    FeedBack2_int = '0'
                elif(FeedBack2_int2=='0'):
                    FeedBack2_int = '1'
                else:
                    FeedBack2_int = '1'

                SlideFull2 = InspectionStation.db_read(18,8,2)
                SlideFull2_int2 = str(snap7.util.get_int(SlideFull2,0))
                if(SlideFull2_int2=='1')
                    SlideFull2_int = '0'
                elif(SlideFull2_int2=='0'):
                    SlideFull2_int = '1'
                else:
                    SlideFull2_int = '1'

                Auto_Manual2  = InspectionStation.db_read(18,10,2)
                Auto_Manual2_int2 = str(snap7.util.get_int(Auto_Manual2, 0))
                if(Auto_Manual2_int2=='1')
                    Auto_Manual2_int = 'Auto'
                elif(Auto_Manual2_int2=='0'):
                    Auto_Manual2_int = 'Manual'
                else:
                    Auto_Manual1_int = 'Fault'

                #Buffer Station
                Emergency3 = BufferStation.db_read(11,4,2)
                Emergency3_int3 = str(snap7.util.get_int(Emergency3,0))
                if(Emergency3_int3=='1')
                    Emergency3_int = '0'
                elif(Emergency3_int3=='0'):
                    Emergency3_int = '1'
                else:
                    Emergency3_int = '1'

                Pressure3  = BufferStation.db_read(11,0,4)
                Pressure3_real = str(snap7.util.get_real(Pressure3, 0))
                if(snap7.util.get_real(Pressure3, 0)<1)
                    FRL_Valve_Close3_real = '1'
                else:
                    FRL_Valve_Close3_real = '0'

                FeedBack3  = BufferStation.db_read(11,6,2)
                FeedBack3_int3 = str(snap7.util.get_int(FeedBack3, 0))
                if(FeedBack3_int3=='1')
                    FeedBack3_int = '0'
                elif(FeedBack3_int3=='0'):
                    FeedBack3_int = '1'
                else:
                    FeedBack3_int = '1'

                BufferFull3 = BufferStation.db_read(11,10,2)
                BufferFull3_int3 = str(snap7.util.get_int(BufferFull3,0))
                if(BufferFull3_int3=='1')
                    BufferFull3_int = '0'
                elif(BufferFull3_int3=='0'):
                    BufferFull3_int = '1'
                else:
                    BufferFull3_int = '1'

                ConveyorSpeed3  = BufferStation.db_read(11,12,4)
                ConveyorSpeed3_real = str(snap7.util.get_real(ConveyorSpeed3, 0))

                Auto_Manual3  = BufferStation.db_read(11,8,2)
                Auto_Manual3_int3 = str(snap7.util.get_int(Auto_Manual3, 0))
                if(Auto_Manual3_int3=='1')
                    Auto_Manual3_int = 'Auto'
                elif(Auto_Manual3_int3=='0'):
                    Auto_Manual3_int = 'Manual'
                else:
                    Auto_Manual3_int = 'Fault'

                #Process Station
                Emergency4 = ProcessStation.db_read(13,4,2)
                Emergency4_int4 = str(snap7.util.get_int(Emergency4,0))
                if(Emergency4_int4=='1')
                    Emergency4_int = '0'
                elif(Emergency4_int4=='0'):
                    Emergency4_int = '1'
                else:
                    Emergency4_int = '1'

                FeedBack4  = ProcessStation.db_read(13,6,2)
                FeedBack4_int4 = str(snap7.util.get_int(FeedBack4, 0))
                if(FeedBack4_int4=='1')
                    FeedBack4_int = '0'
                elif(FeedBack4_int4=='0'):
                    FeedBack4_int = '1'
                else:
                    FeedBack4_int = '1'

                Pressure4  = ProcessStation.db_read(13,0,4)
                Pressure4_real = str(snap7.util.get_real(Pressure4, 0))
                if(snap7.util.get_real(Pressure4, 0)<1)
                    FRL_Valve_Close4_real = '1'
                else:
                    FRL_Valve_Close4_real = '0'

                Auto_Manual4  = ProcessStation.db_read(13,8,2)
                Auto_Manual4_int4 = str(snap7.util.get_int(Auto_Manual4, 0))
                if(Auto_Manual4_int4=='1')
                    Auto_Manual4_int = 'Auto'
                elif(Auto_Manual4_int4=='0'):
                    Auto_Manual4_int = 'Manual'
                else:
                    Auto_Manual4_int = 'Fault'

                Drill_Run_Time4  = ProcessStation.db_read(13,10,2)
                Drill_Run_Time_int4 = str(snap7.util.get_int(Drill_Run_Time4, 0))

                #Sorting Station
                Emergency5 = SortingStation.db_read(26,4,2)
                Emergency5_int5 = str(snap7.util.get_int(Emergency5,0))
                if(Emergency5_int5=='1')
                    Emergency5_int = '0'
                elif(Emergency5_int5=='0'):
                    Emergency5_int = '1'
                else:
                    Emergency5_int = '1'

                Pressure5  = SortingStation.db_read(26,0,4)
                Pressure5_real = str(snap7.util.get_real(Pressure5, 0))
                if(snap7.util.get_real(Pressure5, 0)<1)
                    FRL_Valve_Close5_real = '1'
                else:
                    FRL_Valve_Close5_real = '0'

                FeedBack5 = SortingStation.db_read(26,6,2)
                FeedBack5_int5 = str(snap7.util.get_int(FeedBack5, 0))
                if(FeedBack5_int5=='1')
                    FeedBack5_int = '0'
                elif(FeedBack5_int5=='0'):
                    FeedBack5_int = '1'
                else:
                    FeedBack5_int = '1'

                Auto_Manual5  = SortingStation.db_read(26,14,2)
                Auto_Manual5_int5 = str(snap7.util.get_int(Auto_Manual5, 0))
                if(Auto_Manual5_int5=='1')
                    Auto_Manual5_int = 'Auto'
                elif(Auto_Manual5_int5=='0'):
                    Auto_Manual5_int = 'Manual'
                else:
                    Auto_Manual5_int = 'Fault'

                ConveyorSpeed5  = SortingStation.db_read(26,16,4)
                ConveyorSpeed5_real = str(snap7.util.get_real(ConveyorSpeed5, 0))

                SortingSlide1 = SortingStation.db_read(26,8,2)
                SortingSlide1_int1 = str(snap7.util.get_int(SortingSlide1,0))
                if(SortingSlide1_int1=='1')
                    SortingSlide1_int = '0'
                elif(SortingSlide1_int1=='0'):
                    SortingSlide1_int = '1'
                else:
                    SortingSlide1_int = '1'

                SortingSlide2 = SortingStation.db_read(26,10,2)
                SortingSlide2_int2 = str(snap7.util.get_int(SortingSlide2,0))
                if(SortingSlide2_int2=='1')
                    SortingSlide2_int = '0'
                elif(SortingSlide2_int2=='0'):
                    SortingSlide2_int = '1'
                else:
                    SortingSlide2_int = '1'

                SortingSlide3 = SortingStation.db_read(26,12,2)
                SortingSlide3_int3 = str(snap7.util.get_int(SortingSlide3,0))
                if(SortingSlide3_int3=='1')
                    SortingSlide3_int = '0'
                elif(SortingSlide3_int3=='0'):
                    SortingSlide3_int = '1'
                else:
                    SortingSlide3_int = '1'
                print("\n")

                Machine_details1= {"date":currentdt,"Feed_Emerg":Emergency1_int,"Feed_Pres":Pressure1_real,"Feed_Feedback":FeedBack1_int,"Feed_Auto_Manual":Auto_Manual1_int,"Feed_FRL":FRL_Valve_Close1_real,"Feed_Strokes":No_Of_Strokes1_real,"Insp_Emerg":Emergency2_int,"Insp_Pres":Pressure2_real,"Insp_Feedback":FeedBack2_int,"Insp_SlideFull":SlideFull2_int,"Insp_FRL":FRL_Valve_Close2_real,"Insp_Auto_Manual":Auto_Manual2_int,"Buff_Emerg":Emergency3_int,"Buff_Pres":Pressure3_real,"Buff_Feedback":FeedBack3_int,"Buff_BufferFull":BufferFull3_int,"Buff_FRL":FRL_Valve_Close3_real,"Buff_Convey":ConveyorSpeed3_real,"Buff_Auto_Manual":Auto_Manual3_int,"Proc_Emerg":Emergency4_int,"Proc_Feedback":FeedBack4_int,"Proc_Pres":Pressure4_real,"Proc_FRL":FRL_Valve_Close4_real,"Proc_Auto_Manual":Auto_Manual4_int,"Proc_Drill_Run":Drill_Run_Time_int4,"Sort_Emerg":Emergency5_int,"Sort_Pres":Pressure5_real,"Sort_Feedback":FeedBack5_int,"Sort_FRL":FRL_Valve_Close5_real,"Sort_Auto_Manual":Auto_Manual4_int,"Sort_Conveyor_Speed":ConveyorSpeed5_real,"Sort_Slide1":SortingSlide1_int,"Sort_Slide2":SortingSlide2_int,"Sort_Slide3":SortingSlide3_int}
                Machine_details = json.dumps(Machine_details1)
                print(Machine_details)
                iCount += 1
                topic="MMS_Appville"
                client.publish(topic,Machine_details)
                if (iCount >15):
                    iCount = 0
            except Exception as ex:
                print("Inner error:-", ex)
    except Exception as exep:
        print("outer error:-", exep)