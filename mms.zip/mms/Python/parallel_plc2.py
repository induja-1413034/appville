import snap7
import json
import requests
import urllib.parse
import datetime
import time
import paho.mqtt.client as paho
import random
import string

while True:
    try:
        FeederStation = snap7.client.Client()
        FeederStation.connect('192.168.14.215',0,1) #DB - 14
        InspectionStation = snap7.client.Client()
        InspectionStation.connect('192.168.14.216',0,1) #DB - 18
        BufferStation = snap7.client.Client()
        BufferStation.connect('192.168.14.217',0,1) #DB - 11
        ProcessStation = snap7.client.Client()
        ProcessStation.connect('192.168.14.218',0,1) #DB - 13
        SortingStation = snap7.client.Client()
        SortingStation.connect('192.168.14.230',0,1) #DB - 26
        AssemblyStation = snap7.client.Client()
        AssemblyStation.connect('192.168.14.226',0,1) #DB - 1
        #RobotStation = snap7.client.Client()
        #RobotStation.connect('192.168.14.225',0,1) #DB - 5
        # Utility = snap7.client.Client()
        # Utility.connect('192.168.14.199',0,1) #DB - 26

        broker="157.55.87.172"#"broker.hivemq.com"
        #broker="m16.cloudmqtt.com"
        def on_message(client, userdata, message):
            time.sleep(0.6)
            print("received message =",str(message.payload.decode("utf-8")))
        def randomString(stringLength=10):
            letters = string.ascii_lowercase
            return ''.join(random.choice(letters) for i in range(stringLength))
        port=1883
        #port=12651
        username="appville"#"awebbgpr"
        password="App123Ville"#"AM8VpNvqgSJA"
        client = paho.Client(randomString())
        print("connecting..")
        #client.on_message=on_message
        client.username_pw_set(username, password)
        client.connect(broker,port) #create client object 
        client.loop_start()
        #client.subscribe("MMS_jana")
        iCount = 0
        while True:
            try:
                #date_time
                currentDT = datetime.datetime.now()
                currentdt = currentDT.strftime("%Y-%m-%d %H:%M:%S")
                time.sleep(1)

                #FeederStation
                Emergency1 = FeederStation.db_read(14,4,2)
                Emergency1_int1 = str(snap7.util.get_int(Emergency1,0))
                if(Emergency1_int1=='1'):
                    Emergency1_int = '0'
                elif(Emergency1_int1=='0'):
                    Emergency1_int = '1'
                else:
                    Emergency1_int = '1'

                Pressure1  = FeederStation.db_read(14,0,4)
                Pressure1_real = str(round(snap7.util.get_real(Pressure1, 0),2))
                if(snap7.util.get_real(Pressure1, 0)<1):
                    FRL_Valve_Close1_real = '1'
                else:
                    FRL_Valve_Close1_real = '0'

                FeedBack1  = FeederStation.db_read(14,6,2)
                FeedBack1_int1 = str(snap7.util.get_int(FeedBack1, 0))
                if(FeedBack1_int1=='1'):
                    FeedBack1_int = '0'
                elif(FeedBack1_int1=='0'):
                    FeedBack1_int = '1'
                else:
                    FeedBack1_int = '1'

                Auto_Manual1  = FeederStation.db_read(14,10,2)
                Auto_Manual1_int1 = str(snap7.util.get_int(Auto_Manual1, 0))
                if(Auto_Manual1_int1=='1'):
                    Auto_Manual1_int = 'Auto'
                elif(Auto_Manual1_int1=='0'):
                    Auto_Manual1_int = 'Manual'
                else:
                    Auto_Manual1_int = 'Fault'

                No_Of_Strokes1  = FeederStation.db_read(14,8,4)
                No_Of_Strokes1_real = str(snap7.util.get_dword(No_Of_Strokes1, 0))

                #InspectionStation
                Emergency2 = InspectionStation.db_read(18,4,2)
                Emergency2_int2 = str(snap7.util.get_int(Emergency2,0))
                if(Emergency2_int2=='1'):
                    Emergency2_int = '0'
                elif(Emergency2_int2=='0'):
                    Emergency2_int = '1'
                else:
                    Emergency2_int = '1'

                Pressure2  = InspectionStation.db_read(18,0,4)
                Pressure2_real = str(round(snap7.util.get_real(Pressure2, 0),2))
                if(snap7.util.get_real(Pressure2, 0)<1.5):
                    FRL_Valve_Close2_real = '1'
                else:
                    FRL_Valve_Close2_real = '0'

                FeedBack2  = InspectionStation.db_read(18,6,2)
                FeedBack2_int2 = str(snap7.util.get_int(FeedBack2, 0))
                if(FeedBack2_int2=='1'):
                    FeedBack2_int = '0'
                elif(FeedBack2_int2=='0'):
                    FeedBack2_int = '1'
                else:
                    FeedBack2_int = '1'

                SlideFull2 = InspectionStation.db_read(18,8,2)
                SlideFull2_int2 = str(snap7.util.get_int(SlideFull2,0))
                #print("insp_ slide")
                #print(SlideFull2_int2)
                if(SlideFull2_int2=='1'):
                    SlideFull2_int = '1'
                elif(SlideFull2_int2=='0'):
                    SlideFull2_int = '0'
                else:
                    SlideFull2_int = '0'

                Auto_Manual2  = InspectionStation.db_read(18,10,2)
                Auto_Manual2_int2 = str(snap7.util.get_int(Auto_Manual2, 0))
                if(Auto_Manual2_int2=='1'):
                    Auto_Manual2_int = 'Auto'
                elif(Auto_Manual2_int2=='0'):
                    Auto_Manual2_int = 'Manual'
                else:
                    Auto_Manual1_int = 'Fault'

                #Buffer Station
                Emergency3 = BufferStation.db_read(11,4,2)
                Emergency3_int3 = str(snap7.util.get_int(Emergency3,0))
                if(Emergency3_int3=='1'):
                    Emergency3_int = '0'
                elif(Emergency3_int3=='0'):
                    Emergency3_int = '1'
                else:
                    Emergency3_int = '1'

                Pressure3  = BufferStation.db_read(11,0,4)
                Pressure3_real = str(round(snap7.util.get_real(Pressure3, 0),2))
                if(snap7.util.get_real(Pressure3, 0)<1.5):
                    FRL_Valve_Close3_real = '1'
                else:
                    FRL_Valve_Close3_real = '0'

                FeedBack3  = BufferStation.db_read(11,6,2)
                FeedBack3_int3 = str(snap7.util.get_int(FeedBack3, 0))
                if(FeedBack3_int3=='1'):
                    FeedBack3_int = '0'
                elif(FeedBack3_int3=='0'):
                    FeedBack3_int = '1'
                else:
                    FeedBack3_int = '1'

                BufferFull3 = BufferStation.db_read(11,10,2)
                BufferFull3_int3 = str(snap7.util.get_int(BufferFull3,0))
                if(BufferFull3_int3=='1'):
                    BufferFull3_int = '1'
                elif(BufferFull3_int3=='0'):
                    BufferFull3_int = '0'
                else:
                    BufferFull3_int = '0'

                ConveyorSpeed3  = BufferStation.db_read(11,12,4)
                ConveyorSpeed3_real = str(round(snap7.util.get_real(ConveyorSpeed3, 0),2))

                Auto_Manual3  = BufferStation.db_read(11,8,2)
                Auto_Manual3_int3 = str(snap7.util.get_int(Auto_Manual3, 0))
                if(Auto_Manual3_int3=='1'):
                    Auto_Manual3_int = 'Auto'
                elif(Auto_Manual3_int3=='0'):
                    Auto_Manual3_int = 'Manual'
                else:
                    Auto_Manual3_int = 'Fault'

                #Process Station
                Emergency4 = ProcessStation.db_read(13,4,2)
                Emergency4_int4 = str(snap7.util.get_int(Emergency4,0))
                if(Emergency4_int4=='1'):
                    Emergency4_int = '0'
                elif(Emergency4_int4=='0'):
                    Emergency4_int = '1'
                else:
                    Emergency4_int = '1'

                FeedBack4  = ProcessStation.db_read(13,6,2)
                FeedBack4_int4 = str(snap7.util.get_int(FeedBack4, 0))
                if(FeedBack4_int4=='1'):
                    FeedBack4_int = '0'
                elif(FeedBack4_int4=='0'):
                    FeedBack4_int = '1'
                else:
                    FeedBack4_int = '1'

                Pressure4  = ProcessStation.db_read(13,0,4)
                Pressure4_real = str(round(snap7.util.get_real(Pressure4, 0),2))
                if(snap7.util.get_real(Pressure4, 0)<1.5):
                    FRL_Valve_Close4_real = '1'
                else:
                    FRL_Valve_Close4_real = '0'

                Auto_Manual4  = ProcessStation.db_read(13,8,2)
                Auto_Manual4_int4 = str(snap7.util.get_int(Auto_Manual4, 0))
                if(Auto_Manual4_int4=='1'):
                    Auto_Manual4_int = 'Auto'
                elif(Auto_Manual4_int4=='0'):
                    Auto_Manual4_int = 'Manual'
                else:
                    Auto_Manual4_int = 'Fault'

                Drill_Run_Time4  = ProcessStation.db_read(13,10,2)
                Drill_Run_Time_int4 = str(snap7.util.get_int(Drill_Run_Time4, 0))

                #Sorting Station
                Emergency5 = SortingStation.db_read(26,4,2)
                Emergency5_int5 = str(snap7.util.get_int(Emergency5,0))
                if(Emergency5_int5=='1'):
                    Emergency5_int = '0'
                elif(Emergency5_int5=='0'):
                    Emergency5_int = '1'
                else:
                    Emergency5_int = '1'

                Pressure5  = SortingStation.db_read(26,0,4)
                Pressure5_real = str(round(snap7.util.get_real(Pressure5, 0),2))
                if(snap7.util.get_real(Pressure5, 0)<1.5):
                    FRL_Valve_Close5_real = '1'
                else:
                    FRL_Valve_Close5_real = '0'

                FeedBack5 = SortingStation.db_read(26,6,2)
                FeedBack5_int5 = str(snap7.util.get_int(FeedBack5, 0))
                if(FeedBack5_int5=='1'):
                    FeedBack5_int = '0'
                elif(FeedBack5_int5=='0'):
                    FeedBack5_int = '1'
                else:
                    FeedBack5_int = '1'

                Auto_Manual5  = SortingStation.db_read(26,14,2)
                Auto_Manual5_int5 = str(snap7.util.get_int(Auto_Manual5, 0))
                #print("sort auto manual")
                #print(Auto_Manual5_int5)
                if(Auto_Manual5_int5=='1'):
                    Auto_Manual5_int = 'Auto'
                elif(Auto_Manual5_int5=='0'):
                    Auto_Manual5_int = 'Manual'
                else:
                    Auto_Manual5_int = 'Auto'

                ConveyorSpeed5  = SortingStation.db_read(26,16,4)
                ConveyorSpeed5_real = str(round(snap7.util.get_real(ConveyorSpeed5, 0),2))

                SortingSlide1 = SortingStation.db_read(26,8,2)
                SortingSlide1_int1 = str(snap7.util.get_int(SortingSlide1,0))
                if(SortingSlide1_int1=='1'):
                    SortingSlide1_int = '1'
                elif(SortingSlide1_int1=='0'):
                    SortingSlide1_int = '0'
                else:
                    SortingSlide1_int = '0'

                SortingSlide2 = SortingStation.db_read(26,10,2)
                SortingSlide2_int2 = str(snap7.util.get_int(SortingSlide2,0))
                if(SortingSlide2_int2=='1'):
                    SortingSlide2_int = '1'
                elif(SortingSlide2_int2=='0'):
                    SortingSlide2_int = '0'
                else:
                    SortingSlide2_int = '0'

                SortingSlide3 = SortingStation.db_read(26,12,2)
                SortingSlide3_int3 = str(snap7.util.get_int(SortingSlide3,0))
                if(SortingSlide3_int3=='1'):
                    SortingSlide3_int = '1'
                elif(SortingSlide3_int3=='0'):
                    SortingSlide3_int = '0'
                else:
                    SortingSlide3_int = '0'
                #print("\n before assembly")
    
                #Assembly Station                
                Pressure6  = AssemblyStation.db_read(1,0,4)
                Pressure6_real = str(round(snap7.util.get_real(Pressure6, 0),2))
                if(snap7.util.get_real(Pressure6, 0)<1.5):
                    FRL_Valve_Close6_real = '1'
                else:
                    FRL_Valve_Close6_real = '0'
                #print("valve close:", FRL_Valve_Close6_real)
                
                Auto_Manual6  = AssemblyStation.db_read(1,8,2)
                Auto_Manual6_int6 = str(snap7.util.get_int(Auto_Manual6, 0))
                if(Auto_Manual6_int6=='1'):
                    Auto_Manual6_int = 'Auto'
                elif(Auto_Manual6_int6=='0'):
                    Auto_Manual6_int = 'Manual'
                else:
                    Auto_Manual6_int = 'Fault'

                Emergency6 = AssemblyStation.db_read(1,4,2)
                Emergency6_int6 = str(snap7.util.get_int(Emergency6,0))
                if(Emergency6_int6=='1'):
                    Emergency6_int = '0'
                elif(Emergency6_int6=='0'):
                    Emergency6_int = '0' #assembly emergency and mode should not be shown
                else:
                    Emergency6_int = '0'

                FeedBack6 = AssemblyStation.db_read(1,6,2)
                FeedBack6_int6 = str(snap7.util.get_int(FeedBack6, 0))
                if(FeedBack6_int6=='1'):
                    FeedBack6_int = '0'
                elif(FeedBack6_int6=='0'):
                    FeedBack6_int = '1'
                else:
                    FeedBack6_int = '1'

                Spring_NA6 = AssemblyStation.db_read(1,10,2)
                Spring_NA6_int6 = str(snap7.util.get_int(Spring_NA6, 0))
                if(Spring_NA6_int6=='1'):
                    Spring_NA6_int = '1'
                elif(Spring_NA6_int6=='0'):
                    Spring_NA6_int = '0'
                else:
                    Spring_NA6_int = '1'

                CAP_NA6 = AssemblyStation.db_read(1,12,2)
                CAP_NA6_int6 = str(snap7.util.get_int(CAP_NA6, 0))
                if(CAP_NA6_int6=='1'):
                    CAP_NA6_int = '0'
                elif(CAP_NA6_int6=='0'):
                    CAP_NA6_int = '1'
                else:
                    CAP_NA6_int = '1'

                Product_Struck6 = AssemblyStation.db_read(1,14,2)
                Product_Struck6_int6 = str(snap7.util.get_int(Product_Struck6, 0))
                if(Product_Struck6_int6=='1'):
                    Product_Struck6_int = '0' #conveyor struck need not be shown now
                elif(Product_Struck6_int6=='0'):
                    Product_Struck6_int = '0'
                else:
                    Product_Struck6_int = '0'
             
                #Robot Station -real to int
                #0-error
                Pressure7  = AssemblyStation.db_read(5,0,2)
                Pressure7_real1 = str(snap7.util.get_int(Pressure7, 0))
                if(Pressure7_real1=="0"):
                    Pressure7_real = "1"
                    FRL_Valve_Close7_real = '0'
                else:
                    Pressure7_real = "0"
                    FRL_Valve_Close7_real = '1'
                    
                # if(snap7.util.get_int(Pressure7, 0)=="0"):
                    # FRL_Valve_Close7_real = '1'
                # else:
                    # FRL_Valve_Close7_real = '0'

                Auto_Manual7  = AssemblyStation.db_read(5,6,2)
                Auto_Manual7_int7 = str(snap7.util.get_int(Auto_Manual7, 0))
                if(Auto_Manual7_int7=='1'):
                    Auto_Manual7_int = 'Auto'
                elif(Auto_Manual7_int7=='0'):
                    Auto_Manual7_int = 'Manual'
                else:
                    Auto_Manual7_int = 'Fault'

                Emergency7 = AssemblyStation.db_read(5,8,2)
                Emergency7_int7 = str(snap7.util.get_int(Emergency7,0))
                if(Emergency7_int7=='1'):
                    Emergency7_int = '0'
                elif(Emergency7_int7=='0'):
                    Emergency7_int = '1'
                else:
                    Emergency7_int = '1'

                FeedBack7 = AssemblyStation.db_read(5,2,2)
                FeedBack7_int7 = str(snap7.util.get_int(FeedBack7, 0))
                if(FeedBack7_int7=='1'):
                    FeedBack7_int = '1'
                elif(FeedBack7_int7=='0'):
                    FeedBack7_int = '0'
                else:
                    FeedBack7_int = '0'

                Inward_Slope_Full7 = AssemblyStation.db_read(5,4,2)
                Inward_Slope_Full7_int7 = str(snap7.util.get_int(Inward_Slope_Full7, 0))
                if(Inward_Slope_Full7_int7=='1'):
                    Inward_Slope_Full7_int = '1'
                elif(Inward_Slope_Full7_int7=='0'):
                    Inward_Slope_Full7_int = '0'
                else:
                    Inward_Slope_Full7_int = '1'
                #Machine_details1= {"date":currentdt,"Feed_Emerg":Emergency1_int,"Feed_Pres":Pressure1_real,"Feed_Feedback":FeedBack1_int,"Feed_Auto_Manual":Auto_Manual1_int,"Feed_FRL":FRL_Valve_Close1_real,"Feed_Strokes":No_Of_Strokes1_real,"Insp_Emerg":Emergency2_int,"Insp_Pres":Pressure2_real,"Insp_Feedback":FeedBack2_int,"Insp_SlideFull":SlideFull2_int,"Insp_FRL":FRL_Valve_Close2_real,"Insp_Auto_Manual":Auto_Manual2_int,"Buff_Emerg":Emergency3_int,"Buff_Pres":Pressure3_real,"Buff_Feedback":FeedBack3_int,"Buff_BufferFull":BufferFull3_int,"Buff_FRL":FRL_Valve_Close3_real,"Buff_Convey":ConveyorSpeed3_real,"Buff_Auto_Manual":Auto_Manual3_int,"Proc_Emerg":Emergency4_int,"Proc_Feedback":FeedBack4_int,"Proc_Pres":Pressure4_real,"Proc_FRL":FRL_Valve_Close4_real,"Proc_Auto_Manual":Auto_Manual4_int,"Proc_Drill_Run":Drill_Run_Time_int4,"Sort_Emerg":Emergency5_int,"Sort_Pres":Pressure5_real,"Sort_Feedback":FeedBack5_int,"Sort_FRL":FRL_Valve_Close5_real,"Sort_Auto_Manual":Auto_Manual4_int,"Sort_Conveyor_Speed":ConveyorSpeed5_real,"Sort_Slide1":SortingSlide1_int,"Sort_Slide2":SortingSlide2_int,"Sort_Slide3":SortingSlide3_int}
                Machine_details1= {"curr_date":currentdt,"Feed_Emerg":Emergency1_int,"Feed_Pres":Pressure1_real,"Feed_Feedback":FeedBack1_int,"Feed_Auto_Manual":Auto_Manual1_int,"Feed_FRL":FRL_Valve_Close1_real,"Feed_Strokes":No_Of_Strokes1_real,"Insp_Emerg":Emergency2_int,"Insp_Pres":Pressure2_real,"Insp_Feedback":FeedBack2_int,"Insp_SlideFull":SlideFull2_int,"Insp_FRL":FRL_Valve_Close2_real,"Insp_Auto_Manual":Auto_Manual2_int,"Buff_Emerg":Emergency3_int,"Buff_Pres":Pressure3_real,"Buff_Feedback":FeedBack3_int,"Buff_BufferFull":BufferFull3_int,"Buff_FRL":FRL_Valve_Close3_real,"Buff_Convey":ConveyorSpeed3_real,"Buff_Auto_Manual":Auto_Manual3_int,"Proc_Emerg":Emergency4_int,"Proc_Feedback":FeedBack4_int,"Proc_Pres":Pressure4_real,"Proc_FRL":FRL_Valve_Close4_real,"Proc_Auto_Manual":Auto_Manual4_int,"Proc_Drill_Run":Drill_Run_Time_int4,"Sort_Emerg":Emergency5_int,"Sort_Pres":Pressure5_real,"Sort_Feedback":FeedBack5_int,"Sort_FRL":FRL_Valve_Close5_real,"Sort_Auto_Manual":Auto_Manual5_int,"Sort_Conveyor_Speed":ConveyorSpeed5_real,"Sort_Slide1":SortingSlide1_int,"Sort_Slide2":SortingSlide2_int,"Sort_Slide3":SortingSlide3_int,"Robot_Pres":Pressure7_real,"Robot_FRL":FRL_Valve_Close7_real,"Robot_automanual":Auto_Manual7_int,"Robot_Emerg":Emergency7_int,"Robot_Feedback":FeedBack7_int,"Robot_Inward":Inward_Slope_Full7_int,'Assem_Pres':Pressure6_real,"Assem_FRL":FRL_Valve_Close6_real,"Assem_automanual":Auto_Manual6_int,"Assem_Emerg":Emergency6_int,"Assem_Feedback":FeedBack6_int,"Assem_spring":Spring_NA6_int,"Assem_cap":CAP_NA6_int,"Assem_workpiecestruck":Product_Struck6_int}
                Machine_details = json.dumps(Machine_details1)
                print(Machine_details)
                iCount += 1
                
                #print("buffer_feedback:", FeedBack3_int3)
                topic="MMS_Appville"
                #client.publish(topic,Machine_details)
                client.publish(topic,Machine_details)
                #print(Machine_details)
                
                if (iCount >15):
                    iCount = 0
            except Exception as ex:
                print("Inner error:-", ex)
    except Exception as exep:
        print("outer error:-", exep)
