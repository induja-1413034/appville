HttpPost - KeyValue
Input - 123|45 (From Body)
https://spatialanchorsunity.azurewebsites.net/api/anchors/keyvalue
It will return RowKey

HttpGet 
The Below url Return all key values
https://spatialanchorsunity.azurewebsites.net/api/anchors/GetKeyValue
The Below url Return specfic Key Value
https://spatialanchorsunity.azurewebsites.net/api/anchors/GetKeyValue/2 (2=>RowKey)

HttpGet - Delete all contents
https://spatialanchorsunity.azurewebsites.net/api/anchors/deletekeyValue
