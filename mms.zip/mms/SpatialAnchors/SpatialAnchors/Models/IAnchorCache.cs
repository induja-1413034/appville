﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpatialAnchors.Models
{
    public interface IAnchorIdCache
    {
        Task<string[]> GetAnchorIdsAsync(string groupingKey);
        Task SetAnchorIdAsync(string groupingKey, string anchorId);
    }
}
