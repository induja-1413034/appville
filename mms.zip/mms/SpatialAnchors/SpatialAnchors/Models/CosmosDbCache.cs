﻿using Microsoft.EntityFrameworkCore;
using SpatialAnchors.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SharingService.Data
{
    internal class CosmosDbCache : IAnchorIdCache
    {
        private appvilledbContext _context;
        private const string partitionKey = "UseARealParititionForProductionCode";
        public async Task<string[]> GetAnchorIdsAsync(string groupingKey)
        {
            _context = new appvilledbContext();
            List<CloudTable> details = new List<CloudTable>();
            if (groupingKey == null)
            {
                details = await _context.CloudTable.ToListAsync();
            }
            else
            {
                details = await _context.CloudTable.Where(x => x.GroupingKey == groupingKey).ToListAsync();
            }
            if (details.Count == 0)
            {
                throw new KeyNotFoundException($"No anchors with {nameof(groupingKey)} {groupingKey} could be found.");
            }
            string[] res = new string[details.Count];
            for (var i = 0; i < details.Count; i++)
            {
                res[i] = details[i].AnchorId;
            }
             return res;
                
        }
        public async Task SetAnchorIdAsync(string groupingKey, string anchorId)
        {           			
          _context= new appvilledbContext();
          CloudTable anchorEntity = new CloudTable(groupingKey, anchorId, CosmosDbCache.partitionKey);
            _context.Add(anchorEntity);
            await _context.SaveChangesAsync();  
            return;
        }
    }
}