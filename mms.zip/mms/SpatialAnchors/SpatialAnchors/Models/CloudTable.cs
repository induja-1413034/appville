﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpatialAnchors.Models
{
    public class CloudTable
    {
        public CloudTable() { }

        public CloudTable(string groupingKey, string anchorId, string partitionKey)
        {
            this.PartitionKey = partitionKey;
            this.RowKey = anchorId;
            this.AnchorId = anchorId;
            this.GroupingKey = groupingKey;
        }

        public int _id { get; set; }
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string AnchorId { get; set; }
        public string GroupingKey { get; set; }
    }
}
