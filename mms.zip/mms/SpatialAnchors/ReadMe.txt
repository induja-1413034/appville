POST
https://spatialanchorappville.azurewebsites.net/api/anchors
input format :
From Body
RowKey|GroupingKey
abc|group

GET
https://spatialanchorappville.azurewebsites.net/api/anchors/group

