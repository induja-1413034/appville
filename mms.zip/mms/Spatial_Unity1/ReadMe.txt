HttpPost
https://spatialunitycopy.azurewebsites.net/api/anchors
Eg: 123|45 (groupingKey|anchorKey)

HttpGet
https://spatialunitycopy.azurewebsites.net/api/anchors/GetGroupingKey/123 (123 - Grouping Key))
Sample output: [45] - (retur array of values)

HttpGet
https://spatialunitycopy.azurewebsites.net/api/anchors/delete/123 (123 - Grouping Key)
