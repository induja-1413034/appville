﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Spatial_Unity1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SharingService.Data
{
    internal class CosmosDbCache : IAnchorKeyCache
    {
        private appvilledbContext _context;
        private const int partitionSize = 500;
        private long lastAnchorNumberIndex = -1;
        public  async Task<string[]> GetAnchorKeyAsync(string anchorId)
        {
            _context = new appvilledbContext();
            List<CloudTable> details = new List<CloudTable>();
            if (anchorId==null)
            {
                //details = await _context.CloudTable.ToListAsync();
            }
            else {
                //details = await _context.CloudTable.Where(x => x.PartitionKey == (anchorId/partitionSize).ToString() && x.RowKey==anchorId.ToString()).ToListAsync();
                details = await _context.CloudTable.Where(x => x.GroupingKey.Equals(anchorId)&&x.IsDeleted==false).ToListAsync();
            }
            string[] res = new string[details.Count];
            for (var i = 0; i < details.Count; i++)
            {
                res[i] = details[i].AnchorKey;
            }
            return res;
            throw new KeyNotFoundException($"The {nameof(anchorId)} {anchorId} could not be found.");
            
        }

        public async Task<List<jsonpair>> GetAnchorKeyValueAsync(long anchorId)
        {
            _context = new appvilledbContext();
            List<CloudTableKeyValue1> details = new List<CloudTableKeyValue1>();
            List<jsonpair> a = new List<jsonpair>();
            jsonpair jsonpairinstance = null;
            if (anchorId == 0)
            {
                details = await _context.CloudTableKeyValue1.ToListAsync();
          }
            else
            {
                details = await _context.CloudTableKeyValue1.Where(x => x.PartitionKey == (anchorId / partitionSize).ToString() && x.RowKey == anchorId.ToString()).ToListAsync();

            }
            /*string[] res = new string[details.Count];
            List<jsonpair> a = new List<jsonpair>();
            for (var i = 1; i <= details.Count; i++)
            {
                a.Add(details[i].AnchorKey);
                a[i].value = details[i].AnchorValue;

            }*/
            foreach(var item in details)
           // for (var i = 1; i <= details.Count; i++)
            {
                jsonpairinstance = new jsonpair();
                jsonpairinstance.key = item.AnchorKey;
                jsonpairinstance.value = item.AnchorValue;
                a.Add(jsonpairinstance);

            }
            return a;
            throw new KeyNotFoundException($"The {nameof(anchorId)} {anchorId} could not be found.");

        }
        
        
        public async Task<CloudTable> GetLastAnchorAsync()
        {
       
            var a = await _context.CloudTable.LastOrDefaultAsync();           
            return a;
          
        }


        public async Task<CloudTable> GetLastAnchorKeyValueAsync()
        {

           var a = await _context.CloudTable.LastOrDefaultAsync();
            return a;

        }

        public async Task<string> GetLastAnchorKeyAsync()
        {
            return (await this.GetLastAnchorAsync())?.AnchorKey;
        }

        public async Task<string> GetLastAnchorKeyValue_KeyAsync()
        {
            return (await this.GetLastAnchorKeyValueAsync())?.AnchorKey;
        }

        //POST Method
        public async Task<long> SetAnchorKeyAsync(string anchorKey, string groupingKey, string Tag_name)
        {             
            _context= new appvilledbContext();
            if (lastAnchorNumberIndex == long.MaxValue)
            {
                // Reset the anchor number index.
                lastAnchorNumberIndex = -1;
            }

            if (lastAnchorNumberIndex < 0)
            {
                // Query last row key
                //var rowKey = (await this.GetLastAnchorKeyValueAsync())?.RowKey;
                //long.TryParse(rowKey, out lastAnchorNumberIndex);
            }

            long newAnchorNumberIndex = ++lastAnchorNumberIndex;
            DateTime now = DateTime.Now;
            var del_details = _context.CloudTable.Where(x => x.GroupingKey.Equals(groupingKey) && x.Tag_name.Equals(Tag_name)).ToList();
            if (del_details.Count() == 0) { 
            CloudTable anchorEntity = new CloudTable()
            {
                AnchorKey = anchorKey,
                GroupingKey = groupingKey,
                Tag_name = Tag_name,
                IsDeleted = false,
                date_time = now

            };
            _context.Add(anchorEntity);
            await _context.SaveChangesAsync();  
            return anchorEntity._id;
            }
            else
            {
                var is_del_change = _context.CloudTable.Where(x => x.GroupingKey.Equals(groupingKey) && x.Tag_name.Equals(Tag_name)).LastOrDefault();
                is_del_change.IsDeleted = true;
                _context.CloudTable.Update(is_del_change);
                await _context.SaveChangesAsync();

                CloudTable anchorEntity = new CloudTable()
                {
                    AnchorKey = anchorKey,
                    GroupingKey = groupingKey,
                    Tag_name = Tag_name,
                    IsDeleted = false,
                    date_time = now

                };
                _context.Add(anchorEntity);
                await _context.SaveChangesAsync();
                return anchorEntity._id;
            }
        }      
        
        public async Task<long> SetAnchorKeyValueAsync(string anchorKey, string anchorValue)
        {
            _context = new appvilledbContext();
            if (lastAnchorNumberIndex == long.MaxValue)
            {
                // Reset the anchor number index.
                lastAnchorNumberIndex = -1;
            }

            if (lastAnchorNumberIndex < 0)
            {
                // Query last row key
               // var rowKey = (await this.GetLastAnchorKeyValueAsync())?.RowKey;
                //long.TryParse(rowKey, out lastAnchorNumberIndex);
            }

            long newAnchorNumberIndex = ++lastAnchorNumberIndex;

            CloudTableKeyValue1 anchorEntity = new CloudTableKeyValue1(newAnchorNumberIndex, CosmosDbCache.partitionSize)
            {
                AnchorKey = anchorKey,
                AnchorValue = anchorValue
            };

            _context.Add(anchorEntity);
            await _context.SaveChangesAsync();
            return newAnchorNumberIndex;
        }
    }
}