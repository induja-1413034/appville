﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spatial_Unity1.Models
{
    public class CloudTableKeyValue1
    {
        public CloudTableKeyValue1() { }

        public CloudTableKeyValue1(long anchorId, int partitionSize)
        {
            this.PartitionKey = (anchorId / partitionSize).ToString();
            this.RowKey = anchorId.ToString();
        }
        public int _id { get; set; }
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string AnchorKey { get; set; }
        public string AnchorValue { get; set; }
    }
}
