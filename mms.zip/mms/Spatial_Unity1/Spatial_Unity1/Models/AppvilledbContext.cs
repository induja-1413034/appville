﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Spatial_Unity1.Models;

namespace Spatial_Unity1.Models
{
    public partial class appvilledbContext : DbContext
    {
        public appvilledbContext()
        {
        }

        public appvilledbContext(DbContextOptions<appvilledbContext> options)
            : base(options)
        {
        }

       
        
        public virtual DbSet<CloudTable> CloudTable { get; set; }
        public virtual DbSet<CloudTableKeyValue1> CloudTableKeyValue1 { get; set; }

        // Unable to generate entity type for table 'rem_mac_det'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                // optionsBuilder.UseMySql("Server=appvilledb.c9muxzcuj9fg.us-east-2.rds.amazonaws.com;Database=appvilledb;user=appville_user;pwd=Appvilleiot1;Convert Zero Datetime=True;");
                optionsBuilder.UseMySql("Server=braiding-new.mysql.database.azure.com;Port=3306;Database=spatialanchors;Uid=braidinguser@braiding-new;Pwd=123Appville!;Convert Zero Datetime=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           
            
            modelBuilder.Entity<CloudTable>(entity =>
            {
                entity.HasKey(e => e._id);
                entity.ToTable("cloudtable_unity");

             /*   entity.Property(e => e.PartitionKey)
                    .HasColumnName("PartitionKey")
                    .HasColumnType("varchar(45)");   */            
               
                entity.Property(e => e.AnchorKey)
                    .HasColumnName("AnchorKey")
                    .HasColumnType("varchar(45)");

            
               /* entity.Property(e => e.RowKey)
                    .HasColumnName("RowKey")
                    .HasColumnType("varchar(45)");*/

                entity.Property(e => e.GroupingKey)
                    .HasColumnName("GroupingKey")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Tag_name)
                    .HasColumnName("Tag_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.date_time)
                    .HasColumnName("date_time")
                    .HasColumnType("datetime");

            });
            modelBuilder.Entity<CloudTableKeyValue1>(entity =>
            {
                entity.HasKey(e => e._id);
                entity.ToTable("cloudtable_unitykeyvalue1");

                entity.Property(e => e.PartitionKey)
                    .HasColumnName("PartitionKey")
                    .HasColumnType("varchar(45)");


                entity.Property(e => e.AnchorKey)
                    .HasColumnName("AnchorKey")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.AnchorValue)
                    .HasColumnName("AnchorValue")
                    .HasColumnType("varchar(45)");


                entity.Property(e => e.RowKey)
                    .HasColumnName("RowKey")
                    .HasColumnType("varchar(45)");

            });
        }
    }
}
