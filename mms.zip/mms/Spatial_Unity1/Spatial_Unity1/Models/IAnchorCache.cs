﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spatial_Unity1.Models
{
    public interface IAnchorKeyCache
    {
        Task<string[]> GetAnchorKeyAsync(string anchorId);
        
        Task<List<jsonpair>> GetAnchorKeyValueAsync(long anchorId);
        Task<string> GetLastAnchorKeyAsync();
        Task<string> GetLastAnchorKeyValue_KeyAsync();
        Task<long> SetAnchorKeyAsync(string anchorKey, string groupingKey, string Tag_name);
        Task<long> SetAnchorKeyValueAsync(string anchorKey, string anchorvalue);
    }
}
