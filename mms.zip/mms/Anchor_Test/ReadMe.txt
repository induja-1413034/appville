POST
Input: anchorKey :Guid (From Body)
https://anchortests.azurewebsites.net/api/anchors
It returns a unique id

GET
https://anchortests.azurewebsites.net/anchors/2 (2=>unique id)

DELETE
https://anchortests.azurewebsites.net/api/anchors/delete
It delete all values