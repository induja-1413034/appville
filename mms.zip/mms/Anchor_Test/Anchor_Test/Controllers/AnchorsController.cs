﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Anchor_Test.Models;
using Microsoft.AspNetCore.Mvc;
using SharingService.Data;

namespace Anchor_Test.Controllers
{
    [Route("api/anchors")]
    [ApiController]
    public class AnchorsController : ControllerBase
    {
        private appvilledbContext _context;
        private readonly IAnchorKeyCache anchorIdCache;

        /// <summary>
        /// Initializes a new instance of the <see cref="AnchorsController"/> class.
        /// </summary>
        public AnchorsController()
        {
            this.anchorIdCache = new CosmosDbCache();
        }

        // GET api/anchors/build
        [HttpGet("{anchorNumber?}")]
        public async Task<ActionResult<string[]>> GetAsync(long anchorNumber)
        {
            // Get the last anchor
            try
            {
                return await this.anchorIdCache.GetAnchorKeyAsync(anchorNumber);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("GetKeyValue/{anchorNumber?}")]
        public async Task<IActionResult> GetKeyValueAsync(long anchorNumber)
        {
            // Get the last anchor
            try
            {
                var result= await this.anchorIdCache.GetAnchorKeyValueAsync(anchorNumber);
                return Ok(result); 
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // GET api/anchors/last
        [HttpGet("last")]
        public async Task<ActionResult<string>> GetAsync()
        {
            // Get the last anchor
            string anchorKey = await this.anchorIdCache.GetLastAnchorKeyAsync();

            if (anchorKey == null)
            {
                return "";
            }

            return anchorKey;
        }



        // DELETE api/anchors
        [HttpGet("delete")]
        public async Task<IActionResult> Delete()
        {
            _context = new appvilledbContext();
            _context.CloudTable.RemoveRange(_context.CloudTable);
            await _context.SaveChangesAsync();
            return Ok("Deleted Successfully");
        }

        [HttpGet("deleteKeyValue")]
        public async Task<IActionResult> DeleteKeyValue()
        {
            _context = new appvilledbContext();
            _context.CloudTableKeyValue.RemoveRange(_context.CloudTableKeyValue);
            await _context.SaveChangesAsync();
            return Ok("Deleted Successfully");
        }

        [HttpPost("keyvalue")]
        public async Task<ActionResult<long>> Post()
        {
            try
            {
                string messageBody;
                using (StreamReader reader = new StreamReader(this.Request.Body, Encoding.UTF8))
                {
                    messageBody = await reader.ReadToEndAsync();
                }

                if (string.IsNullOrWhiteSpace(messageBody))
                {
                    return BadRequest("not found");
                }

                string[] splitMessageBody = messageBody.Split("|");
                if (splitMessageBody.Length != 2)
                {
                    return this.BadRequest();
                }
                string anchorKey = splitMessageBody[0];
                string anchorvalue = splitMessageBody[1];

                // Set the key
                return await this.anchorIdCache.SetAnchorKeyValueAsync(anchorKey, anchorvalue);
                //return await this.anchorIdCache.SetAnchorKeyAsync(anchorKey);
            }

            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        // POST api/anchors
        [HttpPost]
        public async Task<ActionResult<long>> PostAsync()
        {
            try
            {
                string anchorKey;
                using (StreamReader reader = new StreamReader(this.Request.Body, Encoding.UTF8))
                {
                    anchorKey = await reader.ReadToEndAsync();
                }

                if (string.IsNullOrWhiteSpace(anchorKey))
                {
                    return BadRequest("not found");
                }

                return await this.anchorIdCache.SetAnchorKeyAsync(anchorKey);                 
            }

            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }

}