﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Anchor_Test.Models
{
    public class CloudTable
    {      
        public CloudTable() { }

        public CloudTable(long anchorId, int partitionSize)
        {
            this.PartitionKey = (anchorId / partitionSize).ToString();
            this.RowKey = anchorId.ToString();
        }
        public int _id { get; set; }
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string AnchorKey { get; set; }
    }

    public class jsonpair
    {
        public string key;
        public string value;
    }
}
