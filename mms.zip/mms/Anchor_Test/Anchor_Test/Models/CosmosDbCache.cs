﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Anchor_Test.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SharingService.Data
{
    internal class CosmosDbCache : IAnchorKeyCache
    {
        private appvilledbContext _context;
        private const int partitionSize = 500;
        private long lastAnchorNumberIndex = -1;
        public  async Task<string[]> GetAnchorKeyAsync(long anchorId)
        {
            _context = new appvilledbContext();
            List<CloudTable> details = new List<CloudTable>();
            if (anchorId==0)
            {
                details = await _context.CloudTable.ToListAsync();
            }
            else { 
            details = await _context.CloudTable.Where(x => x.PartitionKey == (anchorId/partitionSize).ToString() && x.RowKey==anchorId.ToString()).ToListAsync();
             
            }
            string[] res = new string[details.Count];
            for (var i = 0; i < details.Count; i++)
            {
                res[i] = details[i].AnchorKey;
            }
            return res;
            throw new KeyNotFoundException($"The {nameof(anchorId)} {anchorId} could not be found.");
            
        }

        public async Task<List<jsonpair>> GetAnchorKeyValueAsync(long anchorId)
        {
            _context = new appvilledbContext();
            List<CloudTableKeyValue> details = new List<CloudTableKeyValue>();
            List<jsonpair> a = new List<jsonpair>();
            jsonpair jsonpairinstance = null;
            if (anchorId == 0)
            {
                details = await _context.CloudTableKeyValue.ToListAsync();
          }
            else
            {
                details = await _context.CloudTableKeyValue.Where(x => x.PartitionKey == (anchorId / partitionSize).ToString() && x.RowKey == anchorId.ToString()).ToListAsync();

            }
            /*string[] res = new string[details.Count];
            List<jsonpair> a = new List<jsonpair>();
            for (var i = 1; i <= details.Count; i++)
            {
                a.Add(details[i].AnchorKey);
                a[i].value = details[i].AnchorValue;

            }*/
            foreach(var item in details)
           // for (var i = 1; i <= details.Count; i++)
            {
                jsonpairinstance = new jsonpair();
                jsonpairinstance.key = item.AnchorKey;
                jsonpairinstance.value = item.AnchorValue;
                a.Add(jsonpairinstance);

            }
            return a;
            throw new KeyNotFoundException($"The {nameof(anchorId)} {anchorId} could not be found.");

        }
        
        
        public async Task<CloudTable> GetLastAnchorAsync()
        {
       
            var a = await _context.CloudTable.LastOrDefaultAsync();           
            return a;
          
        }


        public async Task<CloudTableKeyValue> GetLastAnchorKeyValueAsync()
        {

            var a = await _context.CloudTableKeyValue.LastOrDefaultAsync();
            return a;

        }

        public async Task<string> GetLastAnchorKeyAsync()
        {
            return (await this.GetLastAnchorAsync())?.AnchorKey;
        }

        public async Task<string> GetLastAnchorKeyValue_KeyAsync()
        {
            return (await this.GetLastAnchorAsync())?.AnchorKey;
        }


        public async Task<long> SetAnchorKeyAsync(string anchorKey)
        {             
            _context= new appvilledbContext();
            if (lastAnchorNumberIndex == long.MaxValue)
            {
                // Reset the anchor number index.
                lastAnchorNumberIndex = -1;
            }

            if (lastAnchorNumberIndex < 0)
            {
                // Query last row key
                var rowKey = (await this.GetLastAnchorAsync())?.RowKey;
                long.TryParse(rowKey, out lastAnchorNumberIndex);
            }

            long newAnchorNumberIndex = ++lastAnchorNumberIndex;

            CloudTable anchorEntity = new CloudTable(newAnchorNumberIndex, CosmosDbCache.partitionSize)
            {
                AnchorKey = anchorKey
            };

            _context.Add(anchorEntity);
            await _context.SaveChangesAsync();  
            return newAnchorNumberIndex;
        }

        public async Task<long> SetAnchorKeyValueAsync(string anchorKey, string anchorValue)
        {
            _context = new appvilledbContext();
            if (lastAnchorNumberIndex == long.MaxValue)
            {
                // Reset the anchor number index.
                lastAnchorNumberIndex = -1;
            }

            if (lastAnchorNumberIndex < 0)
            {
                // Query last row key
                var rowKey = (await this.GetLastAnchorKeyValueAsync())?.RowKey;
                long.TryParse(rowKey, out lastAnchorNumberIndex);
            }

            long newAnchorNumberIndex = ++lastAnchorNumberIndex;

            CloudTableKeyValue anchorEntity = new CloudTableKeyValue(newAnchorNumberIndex, CosmosDbCache.partitionSize)
            {
                AnchorKey = anchorKey,
                AnchorValue = anchorValue
            };

            _context.Add(anchorEntity);
            await _context.SaveChangesAsync();
            return newAnchorNumberIndex;
        }
    }
}