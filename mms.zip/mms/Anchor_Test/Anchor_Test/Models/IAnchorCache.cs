﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Anchor_Test.Models
{
    public interface IAnchorKeyCache
    {
        Task<string[]> GetAnchorKeyAsync(long anchorId);
        
        Task<List<jsonpair>> GetAnchorKeyValueAsync(long anchorId);
        Task<string> GetLastAnchorKeyAsync();
        Task<string> GetLastAnchorKeyValue_KeyAsync();
        Task<long> SetAnchorKeyAsync(string anchorKey);
        Task<long> SetAnchorKeyValueAsync(string anchorKey, string anchorvalue);
    }
}
