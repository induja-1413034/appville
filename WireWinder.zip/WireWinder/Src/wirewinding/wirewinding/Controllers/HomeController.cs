﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using wirewinding.Models;
using Microsoft.Extensions.Configuration;
using System.Text;
using MySql.Data.MySqlClient;

namespace braidingmachine.Controllers
{
    public class HomeController : Controller
    {      
        private appvilledbContext _context;        
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index([Bind("Username,Password")] LoginTable Login_Table)
        {
            try
            {
                _context = new appvilledbContext();
                var role = _context.LoginTable.Where(x => x.Username.Equals(Login_Table.Username) && x.Password.Equals(Login_Table.Password)).Select(x => x.Role).FirstOrDefault();
                if (role.Equals("admin"))
                {
                    return RedirectToAction("AdminDashboard", "AdminDashboard");
                }
                else if (role.Equals("user"))
                {
                    return RedirectToAction("LiveStatus", "LiveStatus");
                }
                else if (role.Equals("guest"))
                {
                    return RedirectToAction("GuestDashboard", "GuestDashboard");
                }
                else
                {
                    ViewBag.Message = "Incorrect Username or Password";
                    return View("Index");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }            
        }
    }
}
