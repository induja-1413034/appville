﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using wirewinding.Models;

namespace wirewinding.Controllers
{
    public class ChangePasswordController : Controller
    {
        public IConfiguration Configuration { get; }
        public ChangePasswordController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public IActionResult ChangePassword(string old, string new_pw)
        {
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            //int count = 0;
            int iVal = 0;
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                MySqlTransaction transaction;
                transaction = conn.BeginTransaction();

                try
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Append("update login_table set Password=@Password");
                    sb.Append(string.Format(" where Password='{0}'", old));
                    sql = sb.ToString();

                    LoginTable login = new LoginTable();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        command.Connection = conn;
                        command.Transaction = transaction;
                        command.Parameters.AddWithValue("@Password", new_pw);
                        iVal = command.ExecuteNonQuery();
                    }
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return BadRequest(ex.Message);
                }

            }
            var a = "";
            if (iVal != 0)
            {
                a = "Password Changed Successfully";
                //return RedirectToAction("ChangePassword", "ChangePassword");
            }
            else
            {
                a = "Your Current Password is Wrong!!";
                //  return RedirectToAction("ChangePassword", "ChangePassword");
            }
            return Ok(a);
        }
    }
}
