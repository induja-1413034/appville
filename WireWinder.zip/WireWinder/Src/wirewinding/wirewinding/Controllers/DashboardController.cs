﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using wirewinding.Models;
namespace wirewinding.Controllers
{
    public class DashboardController : Controller
    {
        public IConfiguration Configuration { get; }
        public DashboardController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult test()
        {
            return View();
        }
            public IActionResult Dashboard()
        {
            List<string> seriallist = new List<string>();
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                StringBuilder sb = new StringBuilder();
                string sql = "";
                sb.Clear();
                sb.Append("SELECT DISTINCT machine_serial_no from machinedata");
                sql = sb.ToString();
                using (MySqlCommand command = new MySqlCommand(sql, conn))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            seriallist.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewBag.Serial = seriallist;
            return View();
        }



        [HttpPost]
        public IActionResult Create(string Machine_details)
        {
            try
            {
                var machine = JsonConvert.DeserializeObject<List<Mac_array.MachineData>>(Machine_details);
                for (int i=0;i<machine.Count;i++) { 
                List<string> errorcodes_new = new List<string>();
                List<string> errorcodes_new_servo = new List<string>();
                List<Errorwithgrouping> errorcodes_old = new List<Errorwithgrouping>();
                Errorwithgrouping errorwithgrouping = null;
                List<Error> errorInsertlist = new List<Error>();
                Error errorInsert = null;
                int machinedata_id = 0;
                DateTime PreviousDatetime = new DateTime();
                int PreviousBobbin_count = 0;
                double Previouscumulative_length = 0;
                string PreviousRecipe_Name = null;
                double PreviousRecipe_grouping = 0;
                TimeSpan time = new TimeSpan();
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    MySqlTransaction transaction;
                    transaction = conn.BeginTransaction();
                    try
                    {
                        StringBuilder sb = new StringBuilder();
                        string sql = "";
                        if (machine[i].mac_alarms != null)
                        {
                            errorcodes_new = machine[i].mac_alarms.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.Trim()).ToList();
                            if (machine[i].servo_errs != null)
                            {
                                errorcodes_new_servo = machine[i].servo_errs.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.Trim()).ToList();
                            }
                            foreach (var err_servo in errorcodes_new_servo)
                            {
                                errorcodes_new.Add(string.Format("100{0}", err_servo));
                            }
                            int Previousmachinedata_id = 0;
                            bool isFoundnull = false;
                            sb.Clear();
                            sb.Append("SELECT _id, errorcode, codegrouping FROM machine_data_error_view");
                            sb.Append(string.Format(" where _id=(select max(_id) from machine_data_error_view where machine_serial='{0}')", machine[i].mac_number));
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                using (MySqlDataReader reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        errorInsert = new Error();
                                        Previousmachinedata_id = reader.GetInt32(0);
                                        if (reader["errorcode"] != DBNull.Value)
                                        {
                                            errorwithgrouping = new Errorwithgrouping();
                                            errorwithgrouping.Prev_errorcode = Convert.ToString(reader.GetInt32(1));
                                            errorwithgrouping.Prev_codegrouping = reader.GetDouble(2);
                                            errorcodes_old.Add(errorwithgrouping);
                                        }
                                        else
                                        {
                                            isFoundnull = true;
                                            break;
                                        }
                                    }
                                    if (isFoundnull == true)
                                    {
                                        foreach (var err in errorcodes_new)
                                        {
                                            errorInsert = new Error();
                                            errorInsert.machinedata_id = machinedata_id;
                                            errorInsert.errorcode = err;
                                            errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                            errorInsertlist.Add(errorInsert);
                                        }
                                    }
                                }
                            }
                            sb.Clear();
                            sb.Append("SELECT Date, Bobbin_count, cumulativelength, Recipe_Name,Recipe_grouping FROM machinedata");
                            sb.Append(string.Format(" where machine_serial_no='{0}' ORDER BY _id DESC LIMIT 1", machine[i].mac_number));
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                using (MySqlDataReader reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        PreviousDatetime = reader.GetDateTime(0);
                                        PreviousBobbin_count = reader.GetInt32(1);
                                        Previouscumulative_length = reader.GetDouble(2);
                                        PreviousRecipe_Name = reader.GetString(3);
                                        PreviousRecipe_grouping = reader.GetDouble(4);
                                    }
                                }
                            }

                            sb.Clear();
                            sb.Append("INSERT INTO machinedata(Date, Bobbin_count, cumulativelength, currentlength, Recipe_Name, Recipe_grouping, machine_serial_no, healthytime, runningtime, faulttime, Timedifference,current_count, trav_volt, spin_volt, spin_curr, trav_curr,machine_speed,mac_id,tot_wire_length)");
                            sb.Append(" VALUES(@Date, @Bobbin_count, @cumulativelength, @currentlength, @Recipe_Name, @Recipe_grouping, @machine_serial_no, @healthytime, @runningtime, @faulttime, @Timedifference,@current_count,@trav_volt,@spin_volt,@spin_curr,@trav_curr,@machine_speed,@mac_id,@tot_wire_length);");
                            sb.Append(" select last_insert_id() as _id");
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                command.Parameters.AddWithValue("@Date", machine[i].date_time);
                                command.Parameters.AddWithValue("@Bobbin_count", machine[i].tot_bobbin_count);
                                command.Parameters.AddWithValue("@cumulativelength", machine[i].tot_length);
                                command.Parameters.AddWithValue("@Recipe_Name", machine[i].recipe_name);
                                command.Parameters.AddWithValue("@machine_serial_no", machine[i].mac_number);
                                command.Parameters.AddWithValue("@healthytime", machine[i].idle_time);
                                command.Parameters.AddWithValue("@faulttime", machine[i].fault_time);
                                command.Parameters.AddWithValue("@runningtime", machine[i].run_time);
                                if (PreviousDatetime == DateTime.MinValue)
                                {
                                    time = new TimeSpan(0, 0, 0, 0, 0);
                                }
                                else
                                {
                                    time = machine[i].date_time - PreviousDatetime;
                                }
                                machine[i].Timedifference = time.TotalSeconds;
                                command.Parameters.AddWithValue("@Timedifference", machine[i].Timedifference);
                                machine[i].current_count = machine[i].tot_bobbin_count - PreviousBobbin_count;
                                command.Parameters.AddWithValue("@current_count", machine[i].current_count);
                                machine[i].currentlength = machine[i].tot_length - Previouscumulative_length;
                                command.Parameters.AddWithValue("@currentlength", machine[i].currentlength);
                                if (PreviousRecipe_Name == machine[i].recipe_name)
                                {
                                    machine[i].Recipe_grouping = PreviousRecipe_grouping;
                                }
                                else
                                {
                                    machine[i].Recipe_grouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                }
                                command.Parameters.AddWithValue("@Recipe_grouping", machine[i].Recipe_grouping);

                                command.Parameters.AddWithValue("@trav_volt", machine[i].trav_volt);
                                command.Parameters.AddWithValue("@spin_volt", machine[i].idle_time);
                                command.Parameters.AddWithValue("@spin_curr", machine[i].fault_time);
                                command.Parameters.AddWithValue("@trav_curr", machine[i].run_time);
                                command.Parameters.AddWithValue("@machine_speed", machine[i].mac_speed);
                                command.Parameters.AddWithValue("@mac_id", machine[i].mac_id);                                
                                command.Parameters.AddWithValue("@tot_wire_length", machine[i].tot_length);

                                    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                            }
                            if (isFoundnull == false)
                            {
                                List<ErrorComparator.Error_Results> list_Err_With_Status = new List<ErrorComparator.Error_Results>();
                                list_Err_With_Status = (new ErrorComparator()).PerformComparison(errorcodes_old, errorcodes_new);
                                foreach (var err in list_Err_With_Status)
                                {
                                    if (err.status == "SameErrorgrouping")
                                    {
                                        errorInsert = new Error();
                                        errorInsert.machinedata_id = machinedata_id;
                                        errorInsert.errorcode = err.error;
                                        errorInsert.codegrouping = errorcodes_old.Where(y => y.Prev_errorcode == err.error).Select(x => x.Prev_codegrouping).First();
                                        errorInsertlist.Add(errorInsert);

                                    }
                                    else if (err.status == "NewErrorgrouping")
                                    {
                                        errorInsert = new Error();
                                        errorInsert.machinedata_id = machinedata_id;
                                        errorInsert.errorcode = err.error;
                                        errorInsert.codegrouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                        errorInsertlist.Add(errorInsert);
                                    }
                                }
                            }
                            foreach (var errinsert in errorInsertlist)
                            {
                                sb.Clear();
                                sb.Append("INSERT INTO error(machinedata_id, errorcode, codegrouping, servo_err_id)");
                                sb.Append(" VALUES(@machinedata_id, @errorcode, @codegrouping, @servo_err_id)");
                                sql = sb.ToString();
                                using (MySqlCommand command = new MySqlCommand(sql, conn))
                                {
                                    command.Connection = conn;
                                    command.Transaction = transaction;
                                    command.Parameters.Clear();
                                    command.Parameters.AddWithValue("@machinedata_id", machinedata_id);
                                    if (errinsert.errorcode == "1002")
                                    {
                                        command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                        command.Parameters.AddWithValue("@servo_err_id", machine[i].traverse_err_id);
                                    }
                                    else if (errinsert.errorcode == "10017")
                                    {
                                        command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                        command.Parameters.AddWithValue("@servo_err_id", machine[i].servo_spindle_err_id);
                                    }
                                    else
                                    {
                                        command.Parameters.AddWithValue("@errorcode", errinsert.errorcode);
                                        command.Parameters.AddWithValue("@servo_err_id", DBNull.Value);
                                    }
                                    command.Parameters.AddWithValue("@codegrouping", errinsert.codegrouping);
                                    int iVal = command.ExecuteNonQuery();
                                }
                            }
                        }
                        else
                        {
                            sb.Clear();
                            sb.Append("SELECT Date,Bobbin_count,cumulativelength,Recipe_Name FROM machinedata");
                            sb.Append(string.Format("where machine_serial_no='{0}' ORDER BY _id DESC LIMIT 1", machine[i].mac_number));
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                using (MySqlDataReader reader = command.ExecuteReader())
                                {
                                    while (reader.Read())
                                    {
                                        PreviousDatetime = reader.GetDateTime(0);
                                        PreviousBobbin_count = reader.GetInt32(1);
                                        Previouscumulative_length = reader.GetInt32(2);
                                        PreviousRecipe_Name = reader.GetString(3);
                                    }
                                }
                            }

                            sb.Clear();
                            sb.Append("INSERT INTO machinedata(Date, Bobbin_count, cumulativelength, currentlength, Recipe_Name, Recipe_grouping, machine_serial_no, healthytime, runningtime, faulttime, Timedifference,current_count, trav_volt, spin_volt, spin_curr, trav_curr,machine_speed,mac_id,tot_wire_length)");
                            sb.Append(" VALUES(@Date, @Bobbin_count, @cumulativelength, @currentlength, @Recipe_Name, @Recipe_grouping, @machine_serial_no, @healthytime, @runningtime, @faulttime, @Timedifference,@current_count,@trav_volt,@spin_volt,@spin_curr,@trav_curr,@machine_speed,mac_id,@tot_wire_length);");
                            sb.Append(" select last_insert_id() as _id");
                            sql = sb.ToString();
                            using (MySqlCommand command = new MySqlCommand(sql, conn))
                            {
                                command.Connection = conn;
                                command.Transaction = transaction;
                                command.Parameters.AddWithValue("@Date", machine[i].date_time);
                                command.Parameters.AddWithValue("@Bobbin_count", machine[i].tot_bobbin_count);
                                command.Parameters.AddWithValue("@cumulativelength", machine[i].tot_length);
                                command.Parameters.AddWithValue("@Recipe_Name", machine[i].recipe_name);
                                command.Parameters.AddWithValue("@machine_serial_no", machine[i].mac_number);
                                command.Parameters.AddWithValue("@healthytime", machine[i].idle_time);
                                command.Parameters.AddWithValue("@faulttime", machine[i].fault_time);
                                command.Parameters.AddWithValue("@runningtime", machine[i].run_time);
                                if (PreviousDatetime == DateTime.MinValue)
                                {
                                    time = new TimeSpan(0, 0, 0, 0, 0);
                                }
                                else
                                {
                                    time = machine[i].date_time - PreviousDatetime;
                                }
                                machine[i].Timedifference = time.TotalSeconds;
                                command.Parameters.AddWithValue("@Timedifference", machine[i].Timedifference);
                                machine[i].current_count = machine[i].tot_bobbin_count - PreviousBobbin_count;
                                command.Parameters.AddWithValue("@current_count", machine[i].current_count);
                                machine[i].currentlength = machine[i].tot_length - Previouscumulative_length;
                                command.Parameters.AddWithValue("@currentlength", machine[i].currentlength);
                                if (PreviousRecipe_Name == machine[i].recipe_name)
                                {
                                    machine[i].Recipe_grouping = PreviousRecipe_grouping;
                                }
                                else
                                {
                                    machine[i].Recipe_grouping = DateTime.Now.TimeOfDay.TotalMilliseconds;
                                }
                                command.Parameters.AddWithValue("@Recipe_grouping", machine[i].Recipe_grouping);

                                command.Parameters.AddWithValue("@trav_volt", machine[i].trav_volt);
                                command.Parameters.AddWithValue("@spin_volt", machine[i].idle_time);
                                command.Parameters.AddWithValue("@spin_curr", machine[i].fault_time);
                                command.Parameters.AddWithValue("@trav_curr", machine[i].run_time);
                                command.Parameters.AddWithValue("@machine_speed", machine[i].mac_speed);
                                command.Parameters.AddWithValue("@mac_id", machine[i].mac_id);
                                command.Parameters.AddWithValue("@tot_wire_length", machine[i].tot_length);

                                    machinedata_id = Convert.ToInt32(command.ExecuteScalar());
                            }
                        }
                        transaction.Commit();
                            
                        }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                }
               
                }
                return Ok(new
                {
                    message = "Added Successfully"
                });
            }
         
         catch (Exception ex)
         {
             throw ex;
         }
               
            }
        public class JsonStringResult : ContentResult
        {
            public JsonStringResult(string json)
            {
                Content = json;
                ContentType = "application/json";
            }
        }

        [HttpGet]
        public ActionResult<TimingData> TimeData(DateTime From, DateTime To, string machine_serial)
        {
            List<TimingData> timingDataslist = new List<TimingData>();
            TimingData timingData = new TimingData();
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    string FromDate = From.ToString("yyyy-MM-dd HH:mm:ss");                    
                    string ToDate = To.ToString("yyyy-MM-dd HH:mm:ss");
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date>='{0}' and Date between '{0}' and '{1}' and machine_serial_no='{2}' order by Date limit 1", FromDate, ToDate,machine_serial));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0);
                                timingData.idle_time = reader.GetInt32(1);
                                timingData.error_time = reader.GetInt32(2);
                            }
                        }
                    }
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date<='{1}' and Date between '{0}' and '{1}' and machine_serial_no='{2}' ORDER BY Date DESC LIMIT 1", FromDate, ToDate, machine_serial));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0) - timingData.up_time;
                                timingData.idle_time = reader.GetInt32(1) - timingData.idle_time;
                                timingData.error_time = reader.GetInt32(2) - timingData.error_time;
                                timingDataslist.Add(timingData);
                            }
                        }
                    }
                   
                    return Ok(timingDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class TimingData
        {
            public int idle_time;
            public int error_time;
            public int up_time;
        }


        [HttpGet]
        public IActionResult ErrorDetails(DateTime From, DateTime To,string machine_serial)
        {
            List<ErrorData> errorDataslist = new List<ErrorData>();
            ErrorData errorData = null;
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    string FromDate = From.ToString("yyyy-MM-dd HH:mm:ss");                   
                    string ToDate = To.ToString("yyyy-MM-dd HH:mm:ss");
                    sb.Clear();
                    sb.Append("SELECT cast(md.Date as date) as Date, err.errorcode, sum(md.Timedifference) FROM machinedata md");
                    sb.Append(string.Format(" inner join error err on md._id = err.machinedata_id"));
                    sb.Append(string.Format(" where md.Date between '{0}' and '{1}' and md.machine_serial_no='{2}'", FromDate, ToDate,machine_serial));
                    sb.Append("group by err.errorcode,cast(Date as date)");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                errorData = new ErrorData();
                                errorData.Date = reader.GetDateTime(0).Date.ToString("yyyy-MM-dd");
                                errorData.errorcode = reader.GetString(1);
                                //errorData.error_description = reader.GetString(2);
                                errorData.Time = TimeSpan.FromSeconds(reader.GetInt32(2));
                                errorDataslist.Add(errorData);
                            }
                        }
                        //conn.Close();
                    }
                    return Ok(errorDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class ErrorData
        {
            public string Date;
            public string errorcode;
            //public string error_description;
            public TimeSpan Time;
        }


        [HttpGet]
        public IActionResult ErrorDetailsWithTime(DateTime date, string errorcode,string machine_serial)
        {
            List<ErrorDataWithTime> errorDatastimelist = new List<ErrorDataWithTime>();
            ErrorDataWithTime errorDatastime = null;
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), sum(Timedifference) from machinedata");
                    sb.Append(" inner join error on error.machinedata_id=machinedata._id");
                    sb.Append(string.Format(" where cast(Date as date)='{0}' and errorcode={1} and machine_serial_no='{2}'", date.ToString("yyyy-MM-dd"), errorcode,machine_serial));
                    sb.Append(" group by error.codegrouping");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                errorDatastime = new ErrorDataWithTime();
                                errorDatastime.Starttime = reader.GetTimeSpan(0);
                                errorDatastime.Endtime = reader.GetTimeSpan(1);
                                errorDatastime.Time = TimeSpan.FromSeconds(reader.GetInt32(2));
                                errorDatastimelist.Add(errorDatastime);
                            }
                        }
                    }
                    return Ok(errorDatastimelist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class ErrorDataWithTime
        {
            public TimeSpan Starttime;
            public TimeSpan Endtime;
            public TimeSpan Time;
        }

        [HttpGet]
        public IActionResult ShiftsData(DateTime From, DateTime To, string machine_serial)
        {
            try
            {
                List<ShiftDetails> shiftwiselist = new List<ShiftDetails>();
                ShiftDetails shiftDetails = null;
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("update machinedata md set shift_name=(select ShiftName from shifttime st where cast(md.Date as time)>=st.In_time and cast(md.Date as time)<st.Out_time),");
                    sb.Append("shift_date = (SELECT DATE_SUB(Cast(md.Date as date), INTERVAL (select days from shifttime st where cast(md.Date as time)>= st.In_time and cast(md.Date as time)< st.Out_time) DAY))");
                    sb.Append(string.Format(" Where md.machine_serial_no='{0}' and md._id > 0;",machine_serial));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int ival = command.ExecuteNonQuery();
                    }
                    sb.Clear();
                    sb.Append("SELECT max(Bobbin_count)-min(Bobbin_count) as Bobbin_Count,shift_name,shift_date FROM machinedata");
                    sb.Append(string.Format(" where shift_date between '{0}' and '{1}' and machine_serial_no='{2}'", From.ToString("yyyy-MM-dd"), To.ToString("yyyy-MM-dd"),machine_serial));
                    sb.Append("group by shift_date,shift_name");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                shiftDetails = new ShiftDetails();
                                shiftDetails.Bobbin_count = reader.GetInt32(0);
                                shiftDetails.shiftName = reader.GetString(1);
                                shiftDetails.Date = reader.GetDateTime(2);
                                shiftwiselist.Add(shiftDetails);
                            }
                        }
                    }
                }
                var shift = shiftwiselist.OrderBy(y => y.shiftName).Select(x => x.shiftName).Distinct();
                var datelist = shiftwiselist.Select(x => x.Date).Distinct().ToList();
                var datelist1 = shiftwiselist.Select(x => x.Date.Date.ToString("yyyy-MM-dd")).Distinct().ToList();

                List<List<int>> listOfList = new List<List<int>>();

                foreach (var shiftname in shift)
                {                  
                    List<int> countlist = new List<int>();
                    foreach (var date in datelist)
                    {
                        var count = shiftwiselist.Where(x => x.Date == date & x.shiftName == shiftname).Select(x => x.Bobbin_count).FirstOrDefault();
                        if (count != 0)
                        {
                            countlist.Add(count);
                        }
                        else
                        {
                            countlist.Add(0);
                        }
                    }
                    listOfList.Add(countlist);
                }
                return Ok(new[] {
                    new
                    {
                                  shift = shift,
                                  date = datelist1,
                                  Bobbincount=listOfList
                    }
                });            
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }

        public class ShiftDetails
        {
            public DateTime Date;
            public string shiftName;
            public int Bobbin_count;
        }
        public class Errorwithgrouping
        {
            public string Prev_errorcode { get; internal set; }
            public double Prev_codegrouping { get; internal set; }
        }

        [HttpGet]
        public IActionResult RecipeDetails(DateTime From, DateTime To, string machine_serial)
        {
            List<RecipeData> recipeDataslist = new List<RecipeData>();
            RecipeData recipeData = null;
            string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");            
            string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("SELECT cast(Date as date) as Date, Recipe_Name, max(Bobbin_count)-min(Bobbin_count) as Bobbin_count FROM machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}' and machine_serial_no='{2}'", FromDate, ToDate,machine_serial));
                    sb.Append("group by cast(Date as date), Recipe_Name order by Date");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                recipeData = new RecipeData();
                                recipeData.date = reader.GetDateTime(0).ToString("yyyy-MM-dd");
                                recipeData.Recipe_name = reader.GetString(1);
                                recipeData.Bobbin_count = reader.GetInt32(2);
                                recipeDataslist.Add(recipeData);
                            }
                        }
                    }
                    return Ok(recipeDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class RecipeData
        {
            public string date;
            public string Recipe_name;
            public int Bobbin_count;
        }


        [HttpGet]
        public IActionResult RecipeDetailsWithTime(DateTime date, string Recipe_name,string machine_serial)
        {
            List<RecipeDataWithTime> RecipeDatastimelist = new List<RecipeDataWithTime>();
            RecipeDataWithTime recipeDatatime = null;
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("select min(cast(Date as time)), max(cast(Date as Time)), max(Bobbin_count)-min(Bobbin_count) as Bobbin_count from machinedata");
                    sb.Append(string.Format(" where cast(Date as date)='{0}' and Recipe_Name='{1}' and machine_serial_no='{2}'", date.ToString("yyyy-MM-dd"), Recipe_name, machine_serial));
                    sb.Append(" group by Recipe_grouping");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                recipeDatatime = new RecipeDataWithTime();
                                recipeDatatime.Starttime = reader.GetTimeSpan(0);
                                recipeDatatime.Endtime = reader.GetTimeSpan(1);
                                recipeDatatime.Bobbin_count = reader.GetInt32(2);
                                RecipeDatastimelist.Add(recipeDatatime);
                            }
                        }
                    }
                    return Ok(RecipeDatastimelist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class RecipeDataWithTime
        {
            public TimeSpan Starttime;
            public TimeSpan Endtime;
            public int Bobbin_count;
        }
    }
}
    
