﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;

namespace wirewinding.Controllers
{
    public class Machine2_ReportController : Controller
    {
        public IConfiguration Configuration { get; }
        public Machine2_ReportController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult Machine2_Report()
        {
            List<string> seriallist = new List<string>();
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                StringBuilder sb = new StringBuilder();
                string sql = "";
                sb.Clear();
                sb.Append("SELECT DISTINCT machine_serial_no from machinedata where mac_id=2");
                sql = sb.ToString();
                using (MySqlCommand command = new MySqlCommand(sql, conn))
                {
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            seriallist.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewBag.Serial = seriallist;
            return View();
        }


        [HttpGet]
        public ActionResult<TimingData> TimeData(DateTime From, DateTime To, string machine_serial)
        {
            List<TimingData> timingDataslist = new List<TimingData>();
            TimingData timingData = new TimingData();
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    string FromDate = From.ToString("yyyy-MM-dd HH:mm:ss");
                    string ToDate = To.ToString("yyyy-MM-dd HH:mm:ss");
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date>='{0}' and Date between '{0}' and '{1}' and machine_serial_no='{2}' and mac_id='{3}' order by Date limit 1", FromDate, ToDate, machine_serial,2));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0);
                                timingData.idle_time = reader.GetInt32(1);
                                timingData.error_time = reader.GetInt32(2);
                            }
                        }
                    }
                    sb.Clear();
                    sb.Append("SELECT runningtime,healthytime,faulttime from machinedata");
                    sb.Append(string.Format(" where Date<='{1}' and Date between '{0}' and '{1}' and machine_serial_no='{2}' and mac_id='{3}' ORDER BY Date DESC LIMIT 1", FromDate, ToDate, machine_serial,2));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timingData.up_time = reader.GetInt32(0) - timingData.up_time;
                                timingData.idle_time = reader.GetInt32(1) - timingData.idle_time;
                                timingData.error_time = reader.GetInt32(2) - timingData.error_time;
                                timingDataslist.Add(timingData);
                            }
                        }
                    }

                    return Ok(timingDataslist);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
        public class TimingData
        {
            public int idle_time;
            public int error_time;
            public int up_time;
        }

        [HttpGet]
        public IActionResult ShiftsData(DateTime From, DateTime To, string machine_serial)
        {
            try
            {
                List<ShiftDetails> shiftwiselist = new List<ShiftDetails>();
                ShiftDetails shiftDetails = null;
                List<string> date_format = new List<string>();
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("update machinedata md set shift_name=(select ShiftName from shifttime st where cast(md.Date as time)>=st.In_time and cast(md.Date as time)<st.Out_time),");
                    sb.Append("shift_date = (SELECT DATE_SUB(Cast(md.Date as date), INTERVAL (select days from shifttime st where cast(md.Date as time)>= st.In_time and cast(md.Date as time)< st.Out_time) DAY))");
                    sb.Append(string.Format(" Where md.machine_serial_no='{0}' and mac_id='{1}' and md._id > 0;", machine_serial,2));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int ival = command.ExecuteNonQuery();
                    }
                    sb.Clear();
                    sb.Append("SELECT max(Bobbin_count)-min(Bobbin_count) as Bobbin_Count,shift_name,shift_date FROM machinedata");
                    sb.Append(string.Format(" where shift_date between '{0}' and '{1}' and machine_serial_no='{2}' and mac_id='{3}'", From.ToString("yyyy-MM-dd"), To.ToString("yyyy-MM-dd"), machine_serial,2));
                    sb.Append("group by shift_date,shift_name");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                shiftDetails = new ShiftDetails();
                                shiftDetails.Bobbin_count = reader.GetInt32(0);
                                shiftDetails.shiftName = reader.GetString(1);
                                shiftDetails.Date = reader.GetDateTime(2);
                                shiftwiselist.Add(shiftDetails);
                            }
                        }
                    }
                }
                var shift = shiftwiselist.OrderBy(y => y.shiftName).Select(x => x.shiftName).Distinct();
                var datelist = shiftwiselist.Select(x => x.Date).Distinct().ToList();
                var datelist1 = shiftwiselist.Select(x => x.Date.Date.ToString("yyyy-MM-dd")).Distinct().ToList();

                List<List<int>> listOfList = new List<List<int>>();

                foreach (var shiftname in shift)
                {
                    List<int> countlist = new List<int>();
                    foreach (var date in datelist)
                    {
                        var count = shiftwiselist.Where(x => x.Date == date & x.shiftName == shiftname).Select(x => x.Bobbin_count).FirstOrDefault();
                        if (count != 0)
                        {
                            countlist.Add(count);
                        }
                        else
                        {
                            countlist.Add(0);
                        }
                    }
                    listOfList.Add(countlist);
                }
                foreach (var i in datelist1)
                {
                    date_format.Add(i.Substring(8) + "-" + i.Substring(5, 2));
                }
                return Ok(new[] {
                    new
                    {
                         shift = shift,
                         date = date_format,
                         Bobbincount=listOfList
                    }
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }

        public class ShiftDetails
        {
            public DateTime Date;
            public string shiftName;
            public int Bobbin_count;
        }

        public class ShiftDetailsWire
        {
            public DateTime Date;
            public string shiftName;
            public double wire;
        }

        [HttpGet]
        public IActionResult ShiftsData_wire(DateTime From, DateTime To, string machine_serial)
        {
            try
            {
                List<ShiftDetailsWire> shiftwiselist = new List<ShiftDetailsWire>();
                List<string> date_format = new List<string>();
                ShiftDetailsWire shiftDetails = null;
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    conn.Open();
                    sb.Clear();
                    sb.Append("update machinedata md set shift_name=(select ShiftName from shifttime st where cast(md.Date as time)>=st.In_time and cast(md.Date as time)<st.Out_time),");
                    sb.Append("shift_date = (SELECT DATE_SUB(Cast(md.Date as date), INTERVAL (select days from shifttime st where cast(md.Date as time)>= st.In_time and cast(md.Date as time)< st.Out_time) DAY))");
                    sb.Append(string.Format(" Where md.machine_serial_no='{0}' and mac_id='{1}' and md._id > 0;", machine_serial,2));
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        int ival = command.ExecuteNonQuery();
                    }
                    sb.Clear();
                    sb.Append("SELECT max(tot_wire_length)-min(tot_wire_length) as tot_wire_length,shift_name,shift_date FROM machinedata");
                    sb.Append(string.Format(" where shift_date between '{0}' and '{1}' and machine_serial_no='{2}' and mac_id='{3}' and tot_wire_length IS NOT NULL ", From.ToString("yyyy-MM-dd"), To.ToString("yyyy-MM-dd"), machine_serial,2));
                    sb.Append("group by shift_date,shift_name");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                shiftDetails = new ShiftDetailsWire();
                                shiftDetails.wire = reader.GetDouble(0);
                                shiftDetails.shiftName = reader.GetString(1);
                                shiftDetails.Date = reader.GetDateTime(2);
                                shiftwiselist.Add(shiftDetails);
                            }
                        }
                    }
                }
                var shift = shiftwiselist.OrderBy(y => y.shiftName).Select(x => x.shiftName).Distinct();
                var datelist = shiftwiselist.Select(x => x.Date).Distinct().ToList();
                var datelist1 = shiftwiselist.Select(x => x.Date.Date.ToString("yyyy-MM-dd")).Distinct().ToList();

                List<List<double>> listOfList = new List<List<double>>();

                foreach (var shiftname in shift)
                {
                    List<double> countlist = new List<double>();
                    foreach (var date in datelist)
                    {
                        var count = shiftwiselist.Where(x => x.Date == date & x.shiftName == shiftname).Select(x => x.wire).FirstOrDefault();
                        if (count != 0)
                        {
                            countlist.Add(count);
                        }
                        else
                        {
                            countlist.Add(0);
                        }
                    }
                    listOfList.Add(countlist);
                }
                foreach (var i in datelist1)
                {
                    date_format.Add(i.Substring(8) + "-" + i.Substring(5, 2));
                }
                return Ok(new[] {
                    new
                    {
                         shift = shift,
                         date = date_format,
                         wire=listOfList
                    }
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }

        public class Bobbin_Production
        {
            public DateTime date;
            public int total_bobbin;
            public string shift_name;
        }
        public class Bobbin_Production_shift
        {
            public string date;
            public int total_bobbin;
            public int shift1_bobbin;
            public int shift2_bobbin;
            public int shift3_bobbin;
        }

        [HttpGet]
        public IActionResult Production_Bobbinwise(DateTime From, DateTime To, string machine_serial)
        {
            List<Bobbin_Production> bobbin = new List<Bobbin_Production>();
            Bobbin_Production Bobbin_Production = null;
            string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
            string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
            try
            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("select Date, sum(Bobbin_count), shift_name FROM wirewinding.machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}' and machine_serial_no = '{2}' and mac_id='{3}' and shift_name IS NOT NULL", FromDate, ToDate, machine_serial,2));
                    sb.Append(" group by cast(Date as date),shift_name order by Date");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Bobbin_Production = new Bobbin_Production();
                                Bobbin_Production.date = reader.GetDateTime(0);
                                Bobbin_Production.total_bobbin = reader.GetInt32(1);
                                Bobbin_Production.shift_name = reader.GetString(2);
                                bobbin.Add(Bobbin_Production);
                            }
                        }
                    }
                    var total_bobbin = bobbin.Select(x => x.total_bobbin).ToList();
                    var shift = bobbin.OrderBy(y => y.shift_name).Select(x => x.shift_name).Distinct();
                    var datelist = bobbin.Select(x => x.date).Distinct().ToList();
                    var datelist1 = bobbin.Select(x => x.date.Date.ToString("yyyy-MM-dd")).Distinct().ToList();

                    List<List<int>> listOfList = new List<List<int>>();
                    string[] shift2 = new string[3] { "shift1", "shift2", "shift3" };
                    foreach (var shiftname in shift2)
                    {
                        List<int> countlist = new List<int>();
                        foreach (var date in datelist1)
                        {
                            var count = bobbin.Where(x => x.date.ToString("yyyy-MM-dd") == date & x.shift_name == shiftname).Select(x => x.total_bobbin).FirstOrDefault();
                            countlist.Add(count);
                        }
                        listOfList.Add(countlist);
                    }
                    Bobbin_Production_shift bobb = new Bobbin_Production_shift();
                    Bobbin_Production_shift bob = null;
                    List<Bobbin_Production_shift> final = new List<Bobbin_Production_shift>();
                    for (int i = 0; i < listOfList.Count; i++)
                    {
                        for (int j = 0; j < listOfList[0].Count; j++)
                        {
                            bob = new Bobbin_Production_shift();
                            bob.date = datelist1[j];
                            bob.shift1_bobbin = listOfList[i][j];
                            bob.shift2_bobbin = listOfList[i + 1][j];
                            bob.shift3_bobbin = listOfList[i + 2][j];
                            bob.total_bobbin = bob.shift1_bobbin + bob.shift2_bobbin + bob.shift3_bobbin;
                            final.Add(bob);
                        }
                        break;
                    }
                    return Ok(final);
                }

            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }

        public class Production_recipe
        {
            public DateTime date;
            public string recipe;
            public string shift_name;
            public int total_bobbin;
        }
        public class Bobbin_Production_recipe
        {
            public string date;
            public string recipe;
            public int total_bobbin;
            public int shift1_bobbin;
            public int shift2_bobbin;
            public int shift3_bobbin;
        }

        [HttpGet]
        public IActionResult Production_recipewise(DateTime From, DateTime To, string machine_serial)
        {
            List<Production_recipe> bobbin = new List<Production_recipe>();
            Production_recipe Production_recipe = null;
            string FromDate = From.ToString("yyyy-MM-dd HH-mm-ss");
            string ToDate = To.ToString("yyyy-MM-dd HH-mm-ss");
            try

            {
                string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    StringBuilder sb = new StringBuilder();
                    string sql = "";
                    sb.Clear();
                    sb.Append("select Date,  sum(Bobbin_count),Recipe_Name, shift_name FROM wirewinding.machinedata");
                    sb.Append(string.Format(" where Date between '{0}' and '{1}' and machine_serial_no = '{2}' and mac_id='{3}' and shift_name IS NOT NULL", FromDate, ToDate, machine_serial,2));
                    sb.Append(" group by cast(Date as date),shift_name order by Date");
                    sql = sb.ToString();
                    using (MySqlCommand command = new MySqlCommand(sql, conn))
                    {
                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Production_recipe = new Production_recipe();
                                Production_recipe.date = reader.GetDateTime(0);
                                Production_recipe.total_bobbin = reader.GetInt32(1);
                                Production_recipe.recipe = reader.GetString(2);
                                Production_recipe.shift_name = reader.GetString(3);
                                bobbin.Add(Production_recipe);
                            }
                        }
                    }
                    var total_bobbin = bobbin.Select(x => x.total_bobbin).ToList();
                    var recipe = bobbin.Select(x => x.recipe).ToList();
                    var shift = bobbin.OrderBy(y => y.shift_name).Select(x => x.shift_name).Distinct();
                    var datelist = bobbin.Select(x => x.date).Distinct().ToList();
                    var datelist1 = bobbin.Select(x => x.date.Date.ToString("yyyy-MM-dd")).Distinct().ToList();

                    List<List<int>> listOfList = new List<List<int>>();
                    List<List<string>> listOfList1 = new List<List<string>>();
                    string[] shift2 = new string[3] { "shift1", "shift2", "shift3" };
                    foreach (var shiftname in shift2)
                    {
                        List<int> countlist = new List<int>();
                        List<string> countlist1 = new List<string>();
                        foreach (var date in datelist1)
                        {
                            var count = bobbin.Where(x => x.date.ToString("yyyy-MM-dd") == date & x.shift_name == shiftname).Select(x => x.total_bobbin).FirstOrDefault();
                            var count1 = bobbin.Where(x => x.date.ToString("yyyy-MM-dd") == date & x.shift_name == shiftname).Select(x => x.recipe).FirstOrDefault();
                            countlist.Add(count);
                            countlist1.Add(count1);
                        }
                        listOfList.Add(countlist);
                        listOfList1.Add(countlist1);
                    }
                    Bobbin_Production_recipe bobb = new Bobbin_Production_recipe();
                    Bobbin_Production_recipe bob = null;
                    List<Bobbin_Production_recipe> final = new List<Bobbin_Production_recipe>();
                    for (int i = 0; i < listOfList.Count; i++)
                    {
                        for (int j = 0; j < listOfList[0].Count; j++)
                        {
                            bob = new Bobbin_Production_recipe();
                            bob.date = datelist1[j];
                            bob.recipe = recipe[j];
                            bob.shift1_bobbin = listOfList[i][j];
                            bob.shift2_bobbin = listOfList[i + 1][j];
                            bob.shift3_bobbin = listOfList[i + 2][j];
                            bob.total_bobbin = bob.shift1_bobbin + bob.shift2_bobbin + bob.shift3_bobbin;
                            final.Add(bob);
                        }
                        break;
                    }
                    return Ok(final);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "" + ex.Message });
            }
        }
    }
}