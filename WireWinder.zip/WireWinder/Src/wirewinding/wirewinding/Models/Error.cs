﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace wirewinding.Models
{
    public class Error
    {
        public int machinedata_id;
        public string errorcode;
        public double codegrouping;
        public double servo_err_id;
    }
}

