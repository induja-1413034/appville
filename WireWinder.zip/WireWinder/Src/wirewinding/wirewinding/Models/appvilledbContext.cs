using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using wirewinding.Models;

namespace wirewinding.Models
{
    public partial class appvilledbContext : DbContext
    {
        public appvilledbContext()
        {
        }

        public appvilledbContext(DbContextOptions<appvilledbContext> options)
            : base(options)
        {
        }

		public virtual DbSet<LoginTable> LoginTable { get; set; }
		


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("Server=braiding-new.mysql.database.azure.com; Port=3306; Database=wirewinding; Uid=braidinguser@braiding-new; Pwd=123Appville!; SslMode=Preferred;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
			modelBuilder.Entity<LoginTable>(entity =>
			{
				entity.HasKey(e => e.Username);

				entity.ToTable("login_table");

				entity.Property(e => e.Username).HasColumnName("Username");

				entity.Property(e => e.Password)
					.HasColumnName("Password")
					.HasColumnType("varchar(45)");

				entity.Property(e => e.Role)
					.HasColumnName("Role")
					.HasColumnType("varchar(45)");
				
          });
        }
    }
}
