﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace wirewinding.Models
{
    public class Mac_array
    {
        public MachineData[] mac;
        public class MachineData
    {
        public DateTime date_time;
        public int tot_bobbin_count;
        public double tot_length;        
        public int idle_time;
        public int run_time;
        public int fault_time;
        public string mac_number;
        public double mac_speed;
        public string servo_errs;
        public string mac_alarms;
        public string recipe_name;    
        public string traverse_err_id;
        public string servo_spindle_err_id;
        public double trav_volt;
        public double spin_volt;
        public double spin_curr;
        public double trav_curr;
        public double Recipe_grouping;
        public double Timedifference;
        public int current_count;
        public double currentlength;
        public int mac_id;
    }
   
    }
    public class Mac_details
    {
        public string Machine_details;
    }
}



