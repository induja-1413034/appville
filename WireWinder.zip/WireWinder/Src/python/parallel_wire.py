import sys
import json
import requests
import urllib.parse
from datetime import datetime, timedelta
import datetime
import time
import paho.mqtt.client as paho
import random
import string
sys.path.insert(0, "..")
from opcua import Client
while True:
    #try:
    #broker="iot.eclipse.org"
    broker="postman.cloudmqtt.com"
    def on_message(client_Mqtt, userdata, message):
        time.sleep(1)
        #print("received message =",str(message.payload.decode("utf-8")))
    def randomString(stringLength=10):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))
    port=11041
    username="elmxqbbc"
    password="_NYYccA92Cs0"
    client_Mqtt = paho.Client(randomString())
    client_Mqtt.on_message=on_message
    client_Mqtt.username_pw_set(username, password)
    print("conneting..")
    try:
       client_Mqtt.connect(broker,port) #create client object 
       client_Mqtt.loop_start()
    except Exception as ex:
       print("mqtt",ex)
    if __name__ == "__main__":
        iCount = 0
        try:
            client1 = Client("opc.tcp://192.168.1.10:4840/freeopcua/server/")
            client1.connect()
        except Exception as ex:
            client1 = ""
            print("client1:-", ex)
        try:
            client2 = Client("opc.tcp://192.168.1.20:4840/freeopcua/server/")
            client2.connect()
        except Exception as ex:
            client2 = ""
            print("client2:-", ex)
        try:
            client3 = Client("opc.tcp://192.168.1.30:4840/freeopcua/server/")
            client3.connect()
        except Exception as ex:
            client3 = ""
            print("client3:-", ex)
        try:
            client4 = Client("opc.tcp://192.168.1.40:4840/freeopcua/server/")
            client4.connect()
        except Exception as ex:
            client4 = ""
            print("client4:-", ex)
        try:
            client5 = Client("opc.tcp://192.168.1.50:4840/freeopcua/server/")
            client5.connect()
        except Exception as ex:
            client5 = ""
            print("client5:-", ex)
        try:
            client6 = Client("opc.tcp://192.168.1.60:4840/freeopcua/server/")
            client6.connect()
        except Exception as ex:
            client6 = ""
            print("client6:-", ex)
        while True:
            #try:
            count=0;
            def FetchData(client,mac_id):
                global count
                count+=1
                root = client.get_root_node()        
                #date_time
                currentDT = datetime.datetime.now()
                currentdt = currentDT.strftime("%Y-%m-%d %H:%M:%S")
                #print(currentdt)
                #time.sleep(5)
                
                recipe_name1 = client.get_node("ns=6;s=::RecipeCtrl:iMo_Recipe.current.recipeName")
                recipe_name = recipe_name1.get_value()
                #print("recipe_name"+str(recipe_name))
                
                tot_bobbin_count1 = client.get_node("ns=6;s=::AsGlobalPV:gVa_TotalBobbinCount")
                tot_bobbin_count = tot_bobbin_count1.get_value()
                #print("tot_bobbin_count"+str(tot_bobbin_count))
                
                mac_number1 = client.get_node("ns=6;s=::ProdLog:Machine_number")
                mac_number = mac_number1.get_value()
                #print("mac_number"+str(mac_number))
                
                mac_speed1 = client.get_node("ns=6;s=::AsGlobalPV:gHmi.status.machine.actualMpsAvgSigned")
                mac_speed = round(mac_speed1.get_value(),3)
                #print("mac_speed"+str(mac_speed))
                
                tot_length1 = client.get_node("ns=6;s=::AsGlobalPV:gPermanent.status.totalLengthWound")
                tot_length = round(tot_length1.get_value(),3)
                #print("total_length"+str(tot_length))
                
                mac_alarms1 = client.get_node("ns=6;s=::AsGlobalPV:gHmi.status.machine.macAlarms")
                mac_alarms = mac_alarms1.get_value()
                #print("mac_alarms"+str(mac_alarms))
                mac_alarms = mac_alarms
                res1 = [i for i, val in enumerate(mac_alarms) if val]
                res = str(res1).strip('[]')
                #print("mac_alarms"+str(res))
                
                fault_hour1 = client.get_node("ns=6;s=::ProdLog:Fault_hour")
                fault_hour = fault_hour1.get_value()
                fault_min1 = client.get_node("ns=6;s=::ProdLog:Fault_min")
                fault_min = fault_hour1.get_value()
                fault_sec1 = client.get_node("ns=6;s=::ProdLog:Fault_sec")
                fault_sec = fault_sec1.get_value()
                fault_time1 = int(fault_hour)*60+int(fault_min)
                fault_time2 = round(fault_time1)
                fault_time = str(fault_time2)
                #print("fault_time: ", str(fault_time))
                
                idle_hour1 = client.get_node("ns=6;s=::ProdLog:Idel_hour")
                idle_hour = idle_hour1.get_value()
                idle_min1 = client.get_node("ns=6;s=::ProdLog:Idel_min")
                idle_min = idle_min1.get_value()
                idle_sec1 = client.get_node("ns=6;s=::ProdLog:Idel_sec")
                idle_sec = idle_sec1.get_value()
                idle_time1 = int(idle_hour)*60+int(idle_min)
                idle_times = round(idle_time1)
                idle_time = str(idle_times)
                #print("idle_time: ", str(idle_time))
                
                run_hour1 = client.get_node("ns=6;s=::ProdLog:Run_hour")
                run_hour = run_hour1.get_value()
                run_min1 = client.get_node("ns=6;s=::ProdLog:Run_min")
                run_min = run_min1.get_value()
                run_sec1 = client.get_node("ns=6;s=::ProdLog:Run_sec")
                run_sec = run_sec1.get_value()
                run_time1 = int(run_hour)*60+int(run_min)
                run_time2 = round(run_time1)
                run_time = str(run_time2)
                #print("run_time: ", str(run_time))
                
                spin_curr1 = client.get_node("ns=6;s=::Visual:iMo_SpinCurr")
                spin_curr = spin_curr1.get_value()
                #print("spin_curr: ",str(spin_curr))
                
                spin_volt1 = client.get_node("ns=6;s=::Visual:iMo_SpinVolt")
                spin_volt = spin_volt1.get_value()
                #print("spin_volt"+str(spin_volt))
                
                trav_curr1 = client.get_node("ns=6;s=::Visual:iMo_TravCurr")
                trav_curr = trav_curr1.get_value()
                #print("trav_curr"+str(trav_curr))
                
                trav_volt1 = client.get_node("ns=6;s=::Visual:iMo_TravVolt")
                trav_volt = trav_volt1.get_value()
                #print("trav_volt"+str(trav_volt))
                
                servo_errs1 = client.get_node("ns=6;s=::AsGlobalPV:gHmi.status.machine.servoAlarms")
                servo_errs = servo_errs1.get_value()
                #print("servo error"+str(servo_errs))
                servo_errs = servo_errs
                res2 = [i for i, val in enumerate(servo_errs) if val]
                res3 = str(res2).strip('[]')
                #print("servo_errs"+str(res3))
                
                traverse_err_id1 = client.get_node("ns=6;s=::alarms:iMo_TravErrorID")
                traverse_err_id = traverse_err_id1.get_value()
                servo_spindle_err_id1 = client.get_node("ns=6;s=::alarms:iMo_SpinErrorID")
                servo_spindle_err_id = servo_spindle_err_id1.get_value()
                #print("servo_spindle_err_id"+str(servo_spindle_err_id))
                
                spindle_err_txt1 = client.get_node("ns=6;s=::alarms:iSpindleErrorText")
                spindle_err_txt = spindle_err_txt1.get_value()
                res4 = str(spindle_err_txt).strip('[]')
                #print("spindle_err_txt"+str(res4))
                
                #Total wire
                # total_wire1 = client.get_node("ns=6;s=::AsGlobalPV:gHmi.status.machine.lengthWound")
                # total_wire = total_wire1.get_value()
                # print("total_wire"+str(total_wire))
                
                #spindle_speed = client.get_node("ns=6;s=::AsGlobalPV:gMachine.parameter.pitch")
                #print("spindle_speed",spindle_speed.get_value())
                #mac_number = "12"
                Machine_details1={"mac_id":mac_id,"date_time":currentdt,"recipe_name":recipe_name,"tot_bobbin_count":tot_bobbin_count,"mac_number":mac_number,"tot_length":tot_length,"mac_speed":mac_speed,"mac_alarms":res,"fault_time":fault_time,"idle_time":idle_time,"run_time":run_time,"spin_curr":spin_curr,"spin_volt":spin_volt,"trav_curr":trav_curr,"trav_volt":trav_volt,"servo_errs":res3,"servo_spindle_err_id":servo_spindle_err_id,"servo_spindle_err_id":servo_spindle_err_id,"traverse_err_id":traverse_err_id}
                Machine_details = json.dumps(Machine_details1)
                return Machine_details1
            my_list = []
            if(client1!=""):
                mac_id=1
                my_list.append(FetchData(client1,mac_id))
            if(client2!=""):
                mac_id=2
                my_list.append(FetchData(client2,mac_id))
            if(client3!=""):
                mac_id=3
                my_list.append(FetchData(client3,mac_id))
            if(client4!=""):
                mac_id=4
                my_list.append(FetchData(client4,mac_id))
            if(client5!=""):
                mac_id=5
                my_list.append(FetchData(client5,mac_id))
            if(client6!=""):
                mac_id=6
                my_list.append(FetchData(client6,mac_id))
            print(my_list)
            #print(json.dumps(my_list))
            time.sleep(1)
            temp = "ww/"
            topic="6080"
            combine="ww/6080"
            # client1.subscribe(combine)
            client_Mqtt.publish(combine,json.dumps(my_list))
            time.sleep(1)
            iCount += 1
            if (iCount >15):
                #print(iCount)
                iCount = 0
                try:
                    post_req = json.dumps(my_list)
                    wire_winding_url = 'https://wirewinding.azurewebsites.net/Dashboard/Create?Machine_details='+ json.dumps(my_list)
                    wire_winding_req = requests.post(url=wire_winding_url)
                    print(wire_winding_url)
                    print(wire_winding_req.text)
                except Exception as ex:
                    print('error:-', ex)
                    #except Exception as ex:
                    #print(ex)
                   # except Exception as exep:
                   # print("outer error:-", exep)
